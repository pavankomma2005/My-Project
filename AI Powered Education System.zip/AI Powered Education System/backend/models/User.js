import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const preferencesSchema = new mongoose.Schema(
  {
    techInterests: {
      type: [String],
      default: [],
      validate: [(arr) => arr.length <= 40, 'Too many tech tags'],
    },
    bio: { type: String, maxlength: 500, default: '' },
    learningGoals: { type: String, maxlength: 2000, default: '' },
    experienceLevel: {
      type: String,
      enum: ['beginner', 'intermediate', 'advanced'],
      default: 'beginner',
    },
    learningStyles: {
      type: [String],
      default: [],
      validate: [(arr) => arr.length <= 12, 'Too many learning styles'],
    },
    careerFocus: { type: String, maxlength: 200, default: '' },
    customSkills: {
      type: [String],
      default: [],
      validate: [(arr) => arr.length <= 40, 'Too many custom skills'],
    },
  },
  { _id: false }
);

const userSchema = new mongoose.Schema(
  {
    fullName: { type: String, trim: true },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: { type: String, minLength: 6, select: false },
    googleId: { type: String, sparse: true, unique: true },
    avatar: { type: String },
    role: {
      type: String,
      enum: ['student', 'instructor', 'admin'],
      default: 'student',
    },
    lastLoginAt: { type: Date },
    preferences: { type: preferencesSchema, default: () => ({}) },
    /**
     * Cached AI outputs tied to the user's current profile/preferences.
     * This avoids repeated LLM calls and keeps the UI consistent across devices.
     */
    aiGuidanceCache: {
      profileHash: { type: String, default: '' },
      provider: { type: String, default: '' },
      fallbackFrom: { type: String, default: '' },
      guidance: { type: Object, default: null },
      recommendationDetails: { type: [Object], default: [] },
      generatedAt: { type: Date, default: null },
    },
  },
  { timestamps: true }
);

const emptyPreferences = () => ({
  techInterests: [],
  bio: '',
  learningGoals: '',
  experienceLevel: 'beginner',
  learningStyles: [],
  careerFocus: '',
  customSkills: [],
});

userSchema.set('toJSON', {
  virtuals: true,
  transform(_doc, ret) {
    ret.id = ret._id;
    delete ret._id;
    delete ret.__v;
    if (ret.password) delete ret.password;
    ret.preferences = { ...emptyPreferences(), ...(ret.preferences || {}) };
    return ret;
  },
});

userSchema.pre('save', async function (next) {
  if (!this.isModified('password') || !this.password) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.comparePassword = async function (candidate) {
  return bcrypt.compare(candidate, this.password);
};

export default mongoose.model('User', userSchema);
