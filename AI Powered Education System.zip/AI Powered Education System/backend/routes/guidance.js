import express from 'express';
import { protect } from '../middleware/auth.js';
import { generateGuidance } from '../services/guidanceAi.js';
import User from '../models/User.js';
import { computeUserProfileHash } from '../services/profileHash.js';

const router = express.Router();

/**
 * Single call returns:
 * - guidance: { profileHighlights, recommendations[3], shortAdvice } — Personalized Guidance + dashboard
 * - recommendationDetails[3] — full-page content per card (same order as recommendations)
 */
router.post('/generate', protect, async (req, res) => {
  try {
    const force = !!req.body?.force;

    const user = await User.findById(req.user._id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    const profileHash = computeUserProfileHash(user);
    const cached = user.aiGuidanceCache || {};
    const hasCache =
      !force &&
      cached &&
      cached.profileHash &&
      cached.profileHash === profileHash &&
      cached.guidance &&
      Array.isArray(cached.recommendationDetails) &&
      cached.recommendationDetails.length >= 3;

    if (hasCache) {
      return res.json({
        success: true,
        provider: cached.provider || null,
        fallbackFrom: cached.fallbackFrom || null,
        configured: true,
        guidance: cached.guidance,
        recommendationDetails: cached.recommendationDetails,
        cached: true,
        generatedAt: cached.generatedAt,
      });
    }

    const result = await generateGuidance(user);

    // If AI isn't configured, do not overwrite existing cache.
    if (result?.configured === false) {
      return res.json({ success: true, ...result, cached: false });
    }

    // Persist cache when we have a real generation.
    user.aiGuidanceCache = {
      profileHash,
      provider: result.provider || '',
      fallbackFrom: result.fallbackFrom || '',
      guidance: result.guidance || null,
      recommendationDetails: Array.isArray(result.recommendationDetails) ? result.recommendationDetails : [],
      generatedAt: new Date(),
    };
    await user.save({ validateBeforeSave: false });

    return res.json({ success: true, ...result, cached: false, generatedAt: user.aiGuidanceCache.generatedAt });
  } catch (err) {
    console.error('[guidance] generate error:', err);
    res.status(500).json({
      success: false,
      message: err.message || 'Could not generate guidance',
    });
  }
});

export default router;
