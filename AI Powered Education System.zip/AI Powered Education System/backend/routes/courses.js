import express from 'express';
import { readFile } from 'fs/promises';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const router = express.Router();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

let cache = { data: null, loadedAt: 0 };
const CACHE_MS = 60 * 1000;

async function loadCourses() {
  const now = Date.now();
  if (cache.data && now - cache.loadedAt < CACHE_MS) {
    return cache.data;
  }
  const path = join(__dirname, '../data/externalCourses.json');
  const raw = await readFile(path, 'utf8');
  const data = JSON.parse(raw);
  cache = { data, loadedAt: now };
  return data;
}

function normalizeTag(t) {
  return String(t).toLowerCase().trim();
}

const STOPWORDS = new Set([
  'the', 'and', 'for', 'with', 'from', 'that', 'this', 'your', 'into', 'about', 'have', 'will',
  'want', 'learn', 'course', 'using', 'use', 'get', 'how', 'are', 'you', 'can', 'our', 'all', 'any',
]);

function tokenizeExtra(text) {
  if (!text || typeof text !== 'string') return [];
  return text
    .toLowerCase()
    .split(/[\s,.;:/\\[\](){}|"'`~!@#$%^&*+=<>?]+/)
    .map((w) => w.replace(/^[^a-z0-9+#.]+|[^a-z0-9+#.]+$/g, ''))
    .filter((w) => w.length > 2 && !STOPWORDS.has(w))
    .slice(0, 24);
}

function buildInterestTokens(matchParam, focusParam, goalsParam) {
  const interests =
    typeof matchParam === 'string'
      ? matchParam.split(',').map((s) => s.trim()).filter(Boolean)
      : [];
  const fromFocus = tokenizeExtra(typeof focusParam === 'string' ? focusParam : '');
  const fromGoals = tokenizeExtra(typeof goalsParam === 'string' ? goalsParam : '');
  const merged = [...interests, ...fromFocus, ...fromGoals];
  const seen = new Set();
  const out = [];
  for (const m of merged) {
    const n = normalizeTag(m);
    if (!n || seen.has(n)) continue;
    seen.add(n);
    out.push(n);
  }
  return out;
}

function scoreCourse(course, interestTags) {
  if (!interestTags.length) return 0;
  const title = (course.title || '').toLowerCase();
  const blurb = (course.blurb || '').toLowerCase();
  const instructor = (course.instructor || '').toLowerCase();
  const platform = (course.platform || '').toLowerCase();
  const ctags = (course.tags || []).map(normalizeTag);
  let score = 0;
  for (const raw of interestTags) {
    const u = normalizeTag(raw);
    if (!u) continue;
    if (ctags.some((c) => c === u || c.includes(u) || u.includes(c))) score += 4;
    else if (title.includes(u) || blurb.includes(u)) score += 2;
    else if (instructor.includes(u) || platform.includes(u)) score += 1;
  }
  return score;
}

/**
 * Curated external courses. Query:
 * - match=comma,tags — tech interests
 * - focus= — career focus (optional)
 * - goals= — learning goals text (optional)
 */
router.get('/external', async (req, res) => {
  try {
    const courses = await loadCourses();
    const interests = buildInterestTokens(req.query.match, req.query.focus, req.query.goals);

    const ranked = courses
      .map((c) => ({
        ...c,
        relevanceScore: scoreCourse(c, interests),
      }))
      .sort((a, b) => {
        if (b.relevanceScore !== a.relevanceScore) return b.relevanceScore - a.relevanceScore;
        return a.title.localeCompare(b.title);
      });

    res.json({
      success: true,
      personalized: interests.length > 0,
      courses: ranked.map(({ relevanceScore, ...rest }) => ({
        ...rest,
        matched: interests.length > 0 && relevanceScore > 0,
      })),
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Failed to load courses' });
  }
});

export default router;
