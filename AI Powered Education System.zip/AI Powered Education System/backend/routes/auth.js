import express from 'express';
import passport from 'passport';
import { body, validationResult } from 'express-validator';
import User from '../models/User.js';
import { generateToken, sendTokenCookie, clearTokenCookie, protect } from '../middleware/auth.js';
import { computeUserProfileHash } from '../services/profileHash.js';

const router = express.Router();

// Register
router.post(
  '/register',
  [
    body('fullName').trim().notEmpty().withMessage('Full name is required'),
    body('email').isEmail().normalizeEmail().withMessage('Valid email is required'),
    body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
      }
      const { fullName, email, password } = req.body;
      const existing = await User.findOne({ email });
      if (existing) {
        return res.status(400).json({ success: false, message: 'Email already registered' });
      }
      const user = await User.create({ fullName, email, password });
      const token = generateToken(user._id);
      sendTokenCookie(res, token);
      res.status(201).json({
        success: true,
        user: user.toJSON(),
        token,
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message || 'Registration failed' });
    }
  }
);

// Login
router.post(
  '/login',
  [
    body('email').isEmail().normalizeEmail(),
    body('password').notEmpty(),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
      }
      const { email, password } = req.body;
      const user = await User.findOne({ email }).select('+password');
      if (!user || !user.password) {
        return res.status(401).json({ success: false, message: 'Invalid email or password' });
      }
      const match = await user.comparePassword(password);
      if (!match) {
        return res.status(401).json({ success: false, message: 'Invalid email or password' });
      }
      user.lastLoginAt = new Date();
      await user.save({ validateBeforeSave: false });
      const token = generateToken(user._id);
      sendTokenCookie(res, token);
      res.json({
        success: true,
        user: user.toJSON(),
        token,
      });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message || 'Login failed' });
    }
  }
);

// Google OAuth - initiate
router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

// Google OAuth - callback
router.get(
  '/google/callback',
  passport.authenticate('google', { session: false }),
  (req, res) => {
    const token = generateToken(req.user._id);
    sendTokenCookie(res, token);
    const frontend = process.env.FRONTEND_URL || 'http://localhost:3000';
    res.redirect(`${frontend}/dashboard?token=${token}`);
  }
);

// Logout
router.post('/logout', (req, res) => {
  clearTokenCookie(res);
  res.json({ success: true, message: 'Logged out' });
});

// Get current user (protected)
router.get('/me', protect, (req, res) => {
  res.json({ success: true, user: req.user.toJSON() });
});

const ALLOWED_LEARNING_STYLES = new Set(['video', 'reading', 'hands-on', 'projects', 'live-sessions']);

const sanitizeTechTag = (t) => {
  const s = String(t).trim();
  if (!s || s.length > 48) return null;
  return s.slice(0, 48);
};

const sanitizeCustomSkill = (t) => {
  const s = String(t).trim();
  if (!s || s.length > 48) return null;
  return s.slice(0, 48);
};

// Update profile & preferences (protected)
router.patch('/profile', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const beforeHash = computeUserProfileHash(user);
    const { fullName, preferences } = req.body;

    if (fullName !== undefined) {
      const name = typeof fullName === 'string' ? fullName.trim() : '';
      if (name.length > 120) {
        return res.status(400).json({ success: false, message: 'Display name is too long' });
      }
      user.fullName = name || user.fullName;
    }

    if (preferences !== undefined && preferences !== null && typeof preferences === 'object') {
      if (!user.preferences) user.preferences = {};

      if (preferences.techInterests !== undefined) {
        if (!Array.isArray(preferences.techInterests)) {
          return res.status(400).json({ success: false, message: 'techInterests must be an array' });
        }
        const tags = [...new Set(preferences.techInterests.map(sanitizeTechTag).filter(Boolean))].slice(0, 40);
        user.set('preferences.techInterests', tags);
      }
      if (preferences.bio !== undefined) {
        user.set('preferences.bio', String(preferences.bio).trim().slice(0, 500));
      }
      if (preferences.learningGoals !== undefined) {
        user.set('preferences.learningGoals', String(preferences.learningGoals).trim().slice(0, 2000));
      }
      if (preferences.experienceLevel !== undefined) {
        const level = String(preferences.experienceLevel);
        if (!['beginner', 'intermediate', 'advanced'].includes(level)) {
          return res.status(400).json({ success: false, message: 'Invalid experience level' });
        }
        user.set('preferences.experienceLevel', level);
      }
      if (preferences.learningStyles !== undefined) {
        if (!Array.isArray(preferences.learningStyles)) {
          return res.status(400).json({ success: false, message: 'learningStyles must be an array' });
        }
        const styles = [...new Set(preferences.learningStyles.map((s) => String(s).trim()).filter((s) => ALLOWED_LEARNING_STYLES.has(s)))];
        user.set('preferences.learningStyles', styles);
      }
      if (preferences.careerFocus !== undefined) {
        user.set('preferences.careerFocus', String(preferences.careerFocus).trim().slice(0, 200));
      }
      if (preferences.customSkills !== undefined) {
        if (!Array.isArray(preferences.customSkills)) {
          return res.status(400).json({ success: false, message: 'customSkills must be an array' });
        }
        const customSkills = [...new Set(preferences.customSkills.map(sanitizeCustomSkill).filter(Boolean))].slice(0, 40);
        user.set('preferences.customSkills', customSkills);
      }
    }

    const afterHash = computeUserProfileHash(user);
    // If profile materially changed, invalidate AI cache so next guidance reflects new inputs.
    if (beforeHash !== afterHash) {
      user.aiGuidanceCache = {
        profileHash: '',
        provider: '',
        fallbackFrom: '',
        guidance: null,
        recommendationDetails: [],
        generatedAt: null,
      };
    }

    await user.save();
    res.json({ success: true, user: user.toJSON() });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message || 'Update failed' });
  }
});

export default router;
