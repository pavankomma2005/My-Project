# AI Education System – Backend

Node.js + Express + MongoDB API with JWT auth and Google OAuth.

## Setup

1. **Install dependencies**
   ```bash
   cd backend && npm install
   ```

2. **Environment**
   - Copy `.env.example` to `.env`
   - Set `MONGODB_URI` (e.g. `mongodb://localhost:27017/ai-education`)
   - Set `JWT_SECRET` (long random string for production)
   - For Google login: create a project in [Google Cloud Console](https://console.cloud.google.com/), enable "Google+ API" / "Google Identity", create OAuth 2.0 credentials (Web application), set Authorized redirect URI to `http://localhost:5000/api/auth/google/callback`, then set `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` in `.env`
   - Set `FRONTEND_URL` (e.g. `http://localhost:3000`)

3. **Run**
   ```bash
   npm run dev
   ```
   Server runs at `http://localhost:5000`.

## API

- `POST /api/auth/register` – body: `{ fullName, email, password }`
- `POST /api/auth/login` – body: `{ email, password }`
- `GET /api/auth/google` – redirects to Google sign-in
- `GET /api/auth/google/callback` – OAuth callback (redirects to frontend with token)
- `POST /api/auth/logout` – clears cookie
- `GET /api/auth/me` – current user (Bearer token required)
