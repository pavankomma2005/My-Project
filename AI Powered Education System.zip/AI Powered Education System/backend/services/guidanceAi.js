/**
 * Career guidance via Google Gemini (primary) with Groq fallback.
 * Single response: list + full-page details for all 3 recommendations.
 */

const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.0-flash';
const GROQ_MODEL = process.env.GROQ_MODEL || 'llama-3.3-70b-versatile';
/** Optional: used if primary model hits TPM (e.g. llama-3.1-8b-instant — smaller context, higher free throughput). */
const GROQ_FALLBACK_MODEL = (process.env.GROQ_FALLBACK_MODEL || '').trim();

const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));

/** Gemini JSON retry only helps parse/format issues — not quota, billing, or invalid key. */
function isGeminiNonRetryableError(err) {
  const m = String(err?.message || '');
  return /quota exceeded|exceeded your current quota|limit:\s*0\b|RESOURCE_EXHAUSTED|billing|API key not valid|PERMISSION_DENIED|invalid api key/i.test(
    m
  );
}

/** Groq often says "try again in 8.805s" — parse for backoff. */
function groqRetryAfterSeconds(message) {
  const m = String(message || '');
  const match = m.match(/try again in\s+([\d.]+)\s*s/i);
  if (match) {
    const sec = Number.parseFloat(match[1], 10);
    if (Number.isFinite(sec)) return Math.min(90, Math.max(1, Math.ceil(sec + 0.5)));
  }
  return 12;
}

function isGroqRateLimitError(err) {
  if (err?.status === 429) return true;
  const m = String(err?.message || '');
  return /rate limit|tokens per minute|\bTPM\b/i.test(m);
}

function userToProfilePayload(user) {
  const u = user?.toJSON ? user.toJSON() : user;
  const prefs = u.preferences || {};
  return {
    fullName: u.fullName || '',
    email: u.email || '',
    role: u.role || 'student',
    preferences: {
      techInterests: prefs.techInterests || [],
      bio: prefs.bio || '',
      careerFocus: prefs.careerFocus || '',
      learningGoals: prefs.learningGoals || '',
      experienceLevel: prefs.experienceLevel || 'beginner',
      learningStyles: prefs.learningStyles || [],
    },
  };
}

/**
 * One model call: overview for the Guidance page + deep dives for each recommendation detail page.
 */
export function buildUnifiedGuidancePrompt(profile) {
  return `You are an expert career advisor and learning designer.

Learner profile (use every field; reference specifics where helpful):
${JSON.stringify(profile, null, 2)}

Return ONE JSON object ONLY (valid JSON, no markdown fences, no trailing commas). Shape:

{
  "profileHighlights": ["2-4 short bullets summarizing the learner from their profile"],
  "recommendations": [
    {
      "title": "Career or learning path title",
      "match": "Strong",
      "summary": "2-3 sentences explaining fit",
      "nextSteps": ["Concrete step 1", "Concrete step 2"]
    }
  ],
  "shortAdvice": "One paragraph (80-140 words) with actionable next focus.",
  "recommendationDetails": [
    {
      "executiveSummary": "3-5 sentences: this path, why it matters for them now, what success looks like.",
      "whyThisFits": "One paragraph (120-200 words) tying their profile to THIS path only.",
      "skillBuilding": [
        { "skill": "", "why": "", "howToStart": "" }
      ],
      "timeline": {
        "immediate": ["4-6 actions for next 2 weeks"],
        "shortTerm": ["4-6 milestones for ~1-3 months"],
        "longTerm": ["3-5 directions for 6-12 months"]
      },
      "concreteNextSteps": ["10-14 actionable bullets; do not prefix with numbers"],
      "resources": [
        { "name": "", "kind": "course|community|documentation|tool|book|video", "note": "" }
      ],
      "risksAndMitigations": [
        { "risk": "", "mitigation": "" }
      ],
      "profileAlignment": {
        "strengths": ["3-6 bullets from their profile"],
        "gaps": ["3-6 gaps or unknowns"],
        "learningStyleTip": "one paragraph for their preferred formats"
      },
      "encouragement": "Closing (80-120 words); one action they can do today."
    }
  ]
}

Rules:
- Exactly 3 items in "recommendations" and exactly 3 in "recommendationDetails", same order: details[i] must fully expand recommendations[i].
- Each "match" is exactly: Strong, Good, or Explore (capitalized).
- For EACH recommendationDetails entry: at least 4 skillBuilding, 10 concreteNextSteps, 4 resources; fill all timeline arrays.
- Be specific; avoid generic filler. Escape double quotes inside strings as \\".
`;
}

function extractJsonObjectSlice(str) {
  const start = str.indexOf('{');
  if (start < 0) return null;
  let depth = 0;
  let inString = false;
  let escape = false;
  for (let i = start; i < str.length; i += 1) {
    const c = str[i];
    if (inString) {
      if (escape) {
        escape = false;
      } else if (c === '\\') {
        escape = true;
      } else if (c === '"') {
        inString = false;
      }
      continue;
    }
    if (c === '"') {
      inString = true;
      continue;
    }
    if (c === '{') depth += 1;
    else if (c === '}') {
      depth -= 1;
      if (depth === 0) return str.slice(start, i + 1);
    }
  }
  return null;
}

function repairLooseJson(str) {
  let s = str.replace(/^\uFEFF/, '').trim();
  s = s.replace(/[\u201C\u201D]/g, '"').replace(/[\u2018\u2019]/g, "'");
  let prev;
  do {
    prev = s;
    s = s.replace(/,\s*]/g, ']').replace(/,\s*}/g, '}');
  } while (s !== prev);
  return s;
}

function parseWithAttempts(text, validate) {
  const raw = String(text).trim();
  const fence = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
  let candidate = fence ? fence[1].trim() : raw;
  const extracted = extractJsonObjectSlice(candidate) || extractJsonObjectSlice(raw);
  if (extracted) candidate = extracted;

  const attempts = [
    () => JSON.parse(candidate),
    () => JSON.parse(repairLooseJson(candidate)),
    () => JSON.parse(repairLooseJson(repairLooseJson(candidate))),
  ];

  let lastErr;
  for (const tryParse of attempts) {
    try {
      const parsed = tryParse();
      if (!parsed || typeof parsed !== 'object') throw new Error('Not an object');
      validate(parsed);
      return parsed;
    } catch (e) {
      lastErr = e;
    }
  }

  throw new Error(
    lastErr?.message ? `Could not parse AI JSON: ${lastErr.message}` : 'Could not parse AI JSON output'
  );
}

function normalizeExpandDetail(parsed) {
  const d = { ...(parsed && typeof parsed === 'object' ? parsed : {}) };
  if (!Array.isArray(d.skillBuilding)) d.skillBuilding = [];
  if (!d.timeline || typeof d.timeline !== 'object') d.timeline = { immediate: [], shortTerm: [], longTerm: [] };
  ['immediate', 'shortTerm', 'longTerm'].forEach((k) => {
    if (!Array.isArray(d.timeline[k])) d.timeline[k] = [];
  });
  if (!Array.isArray(d.concreteNextSteps)) d.concreteNextSteps = [];
  if (!Array.isArray(d.resources)) d.resources = [];
  if (!Array.isArray(d.risksAndMitigations)) d.risksAndMitigations = [];
  if (!d.profileAlignment || typeof d.profileAlignment !== 'object') {
    d.profileAlignment = { strengths: [], gaps: [], learningStyleTip: '' };
  }
  if (!Array.isArray(d.profileAlignment.strengths)) d.profileAlignment.strengths = [];
  if (!Array.isArray(d.profileAlignment.gaps)) d.profileAlignment.gaps = [];
  if (typeof d.profileAlignment.learningStyleTip !== 'string') d.profileAlignment.learningStyleTip = '';
  if (typeof d.executiveSummary !== 'string') d.executiveSummary = '';
  if (typeof d.whyThisFits !== 'string') d.whyThisFits = '';
  if (typeof d.encouragement !== 'string') d.encouragement = '';
  return d;
}

function parseUnifiedGuidanceJson(text) {
  const parsed = parseWithAttempts(text, (p) => {
    if (!Array.isArray(p.recommendations) || p.recommendations.length !== 3) {
      throw new Error('Expected exactly 3 recommendations');
    }
    if (!Array.isArray(p.recommendationDetails)) {
      throw new Error('Expected recommendationDetails array');
    }
  });

  const detailsIn = parsed.recommendationDetails || [];
  const recommendationDetails = [0, 1, 2].map((i) => normalizeExpandDetail(detailsIn[i]));

  const guidance = {
    profileHighlights: Array.isArray(parsed.profileHighlights) ? parsed.profileHighlights : [],
    recommendations: parsed.recommendations,
    shortAdvice: typeof parsed.shortAdvice === 'string' ? parsed.shortAdvice : '',
  };

  return { guidance, recommendationDetails };
}

async function geminiGenerateText(prompt, jsonMime) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error('GEMINI_API_KEY not set');

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
    GEMINI_MODEL
  )}:generateContent?key=${encodeURIComponent(key)}`;

  const generationConfig = { temperature: 0.65 };
  if (jsonMime) generationConfig.responseMimeType = 'application/json';

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig,
    }),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.error?.message || JSON.stringify(data) || res.statusText;
    throw new Error(`Gemini API: ${msg}`);
  }

  const text =
    data?.candidates?.[0]?.content?.parts?.map((p) => p.text).join('') ||
    data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('Gemini returned empty content');
  return text;
}

async function groqGenerateText(prompt, jsonObjectMode, modelId = GROQ_MODEL) {
  const key = process.env.GROQ_API_KEY;
  if (!key) throw new Error('GROQ_API_KEY not set');

  const payload = {
    model: modelId,
    messages: [
      {
        role: 'system',
        content:
          'You output only valid JSON. No markdown fences. No trailing commas. Follow the user instructions exactly.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.65,
  };

  const body = jsonObjectMode ? { ...payload, response_format: { type: 'json_object' } } : payload;

  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify(body),
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = data?.error?.message || JSON.stringify(data) || res.statusText;
    const err = new Error(`Groq API: ${msg}`);
    err.status = res.status;
    throw err;
  }

  const text = data?.choices?.[0]?.message?.content;
  if (!text) throw new Error('Groq returned empty content');
  return text;
}

async function groqCallWithRateLimitRetries(fn, label) {
  const maxAttempts = 4;
  let lastErr;
  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    try {
      return await fn();
    } catch (e) {
      lastErr = e;
      if (!isGroqRateLimitError(e) || attempt === maxAttempts - 1) throw e;
      const waitSec = groqRetryAfterSeconds(e.message);
      console.warn(
        `[guidance] Groq rate limited (${label}); waiting ${waitSec}s before retry ${attempt + 2}/${maxAttempts}`
      );
      await sleepMs(waitSec * 1000);
    }
  }
  throw lastErr;
}

async function runGeminiParsed(prompt, parser) {
  try {
    const text = await geminiGenerateText(prompt, true);
    return parser(text);
  } catch (first) {
    if (isGeminiNonRetryableError(first)) {
      throw first;
    }
    console.warn('[guidance] Gemini (JSON mode) failed, retrying without responseMimeType:', first.message || first);
    const text = await geminiGenerateText(prompt, false);
    return parser(text);
  }
}

async function runGroqParsedWithModel(prompt, parser, modelId) {
  try {
    const text = await groqCallWithRateLimitRetries(
      () => groqGenerateText(prompt, true, modelId),
      modelId
    );
    return parser(text);
  } catch (e) {
    if (e.status === 400 || /response_format|json_object/i.test(e.message || '')) {
      console.warn('[guidance] Groq json_object mode rejected, retrying without it');
      const text = await groqCallWithRateLimitRetries(
        () => groqGenerateText(prompt, false, modelId),
        modelId
      );
      return parser(text);
    }
    throw e;
  }
}

async function runGroqParsed(prompt, parser) {
  try {
    return await runGroqParsedWithModel(prompt, parser, GROQ_MODEL);
  } catch (e) {
    if (GROQ_FALLBACK_MODEL && isGroqRateLimitError(e)) {
      console.warn(`[guidance] Groq primary model rate limited; trying GROQ_FALLBACK_MODEL=${GROQ_FALLBACK_MODEL}`);
      return runGroqParsedWithModel(prompt, parser, GROQ_FALLBACK_MODEL);
    }
    throw e;
  }
}

async function runAiWithFallback(prompt, parser) {
  const hasGemini = !!process.env.GEMINI_API_KEY;
  const hasGroq = !!process.env.GROQ_API_KEY;

  if (!hasGemini && !hasGroq) {
    throw new Error('No AI API keys configured');
  }

  if (hasGemini) {
    try {
      const result = await runGeminiParsed(prompt, parser);
      return { provider: 'gemini', result };
    } catch (err) {
      console.error('[guidance] Gemini failed:', err.message || err);
      if (hasGroq) {
        try {
          const result = await runGroqParsed(prompt, parser);
          return { provider: 'groq', result, fallbackFrom: 'gemini' };
        } catch (err2) {
          console.error('[guidance] Groq failed:', err2.message || err2);
          throw new Error(err2.message || 'Both Gemini and Groq failed');
        }
      }
      throw err;
    }
  }

  const result = await runGroqParsed(prompt, parser);
  return { provider: 'groq', result };
}

/**
 * One AI call: guidance list + recommendationDetails[0..2] for full pages.
 */
export async function generateGuidance(user) {
  const profile = userToProfilePayload(user);
  const prompt = buildUnifiedGuidancePrompt(profile);

  const hasGemini = !!process.env.GEMINI_API_KEY;
  const hasGroq = !!process.env.GROQ_API_KEY;

  if (!hasGemini && !hasGroq) {
    return {
      provider: null,
      configured: false,
      guidance: null,
      recommendationDetails: null,
      message: 'Set GEMINI_API_KEY and/or GROQ_API_KEY in the server environment.',
    };
  }

  const { provider, result, fallbackFrom } = await runAiWithFallback(prompt, parseUnifiedGuidanceJson);
  return {
    provider,
    configured: true,
    guidance: result.guidance,
    recommendationDetails: result.recommendationDetails,
    fallbackFrom,
  };
}
