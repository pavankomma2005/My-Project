import crypto from 'crypto';

function normalizeArray(arr, max = 60) {
  if (!Array.isArray(arr)) return [];
  const out = [];
  const seen = new Set();
  for (const raw of arr) {
    const s = String(raw ?? '').trim();
    if (!s) continue;
    const k = s.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(s);
    if (out.length >= max) break;
  }
  return out;
}

export function computeUserProfileHash(user) {
  const u = user?.toJSON ? user.toJSON() : user;
  const p = u?.preferences || {};

  const payload = {
    fullName: String(u?.fullName || '').trim(),
    role: String(u?.role || ''),
    preferences: {
      techInterests: normalizeArray(p.techInterests, 40).map((s) => s.toLowerCase()),
      learningStyles: normalizeArray(p.learningStyles, 12).map((s) => s.toLowerCase()),
      experienceLevel: String(p.experienceLevel || 'beginner'),
      careerFocus: String(p.careerFocus || '').trim().slice(0, 200),
      learningGoals: String(p.learningGoals || '').trim().slice(0, 2000),
      bio: String(p.bio || '').trim().slice(0, 500),
    },
  };

  const json = JSON.stringify(payload);
  return crypto.createHash('sha256').update(json).digest('hex');
}

