import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const path = join(__dirname, '../data/externalCourses.json');

const emojiById = {
  'fcc-responsive': '🎨',
  'fcc-js-algorithms': '⚡',
  'fcc-data-viz': '📈',
  'fcc-backend': '🔧',
  'fcc-frontend-libs': '⚛️',
  'fcc-quality': '✅',
  'fcc-info-sec': '🔐',
  'fcc-python-ml': '🤖',
  'fcc-scientific-py': '🔬',
  'mdn-front-end': '📚',
  'mdn-css': '🎨',
  'mdn-js': '📜',
  'react-learn': '⚛️',
  'ts-handbook': '📘',
  'nodejs-learn': '🟢',
  'vue-guide': '💚',
  'angular-docs': '🅰️',
  'next-learn': '▲',
  'svelte-tutorial': '🔥',
  'rust-book': '🦀',
  'go-tour': '🔷',
  'kotlin-docs': '🟣',
  'swift-org': '🍎',
  'flutter-learn': '💙',
  'android-basics': '🤖',
  'coursera-python': '🐍',
  'coursera-ml': '🧠',
  'coursera-gcp': '☁️',
  'cs50': '🎓',
  'mit-6006': '📐',
  'mit-python': '🏛️',
  'khan-algo': '🔢',
  'khan-cryptography': '🔑',
  'fastai-course': '🚀',
  'google-ml-crash': '🎯',
  'gcp-skills': '☁️',
  'ms-learn-azure': '🔷',
  'ms-learn-dotnet': '🌐',
  'docker-docs': '🐳',
  'k8s-basics': '☸️',
  'terraform-intro': '🏗️',
  'git-scm': '📗',
  'postgres-tutorial': '🐘',
  'mongo-uni': '🍃',
  'django-tutorial': '🎸',
  'flask-quickstart': '🌶️',
  'spring-guides': '🍃',
  'oracle-java': '☕',
  'tailwind-docs': '🌬️',
  'graphql-learn': '◼️',
  'owasp-top10': '🛡️',
  'stripe-dev': '💳',
  'figma-learn': '🎭',
  'unity-learn': '🎮',
  'unreal-docs': '🕹️',
  'ibm-skills': '💼',
  'w3c-web-standards': '🌐',
  'a11y-wai': '♿',
  'linux-foundation': '🐧',
  'stanford-algorithms': '📊',
  'deeplearning-ai-nlp': '💬',
  'cisco-netacad': '📡',
};

const raw = fs.readFileSync(path, 'utf8');
const courses = JSON.parse(raw);

function fixMojibake(s) {
  if (typeof s !== 'string') return s;
  return s
    .replace(/ΓÇö/g, '—')
    .replace(/ΓÇô/g, '–')
    .replace(/NgΓÇôstyle/g, 'Ng-style');
}

for (const c of courses) {
  if (emojiById[c.id]) c.emoji = emojiById[c.id];
  c.title = fixMojibake(c.title);
  c.level = fixMojibake(c.level);
  c.blurb = fixMojibake(c.blurb);
}

fs.writeFileSync(path, `${JSON.stringify(courses, null, 2)}\n`, 'utf8');
console.log('Fixed', courses.length, 'courses');
