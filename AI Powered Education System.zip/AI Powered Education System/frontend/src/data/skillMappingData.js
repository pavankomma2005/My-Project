/**
 * Skill mapping library.
 *
 * This is intentionally heuristic (not “AI”) so it works offline and on rate limits.
 * We score roles by overlap with required + bonus skills, then suggest skills to add.
 */

export const SKILL_ALIASES = {
	"html/css": ["html", "css", "responsive design", "web design"],
	javascript: ["js", "javascript", "ecmascript"],
	typescript: ["ts", "typescript"],
	react: ["react", "reactjs", "react.js"],
	"node.js": ["node", "nodejs", "node.js", "express"],
	python: ["python", "pandas", "numpy"],
	sql: ["sql", "postgres", "mysql", "sqlite", "database"],
	"data visualization": ["data viz", "visualization", "tableau", "power bi", "dashboard"],
	"ui/ux": ["ux", "ui", "user experience", "interaction design", "figma", "wireframe", "prototype"],
	"cloud fundamentals": ["cloud", "aws", "azure", "gcp"],
	devops: ["devops", "ci/cd", "docker", "kubernetes", "terraform"],
	"cybersecurity fundamentals": ["security", "cybersecurity", "iam", "mfa", "network security"],
	testing: ["testing", "qa", "automation", "playwright", "cypress", "unit tests"],
	communication: ["communication", "written communication", "stakeholder", "presentation"],
	collaboration: ["team collaboration", "collaboration", "code review"],
};

export const TRACK_SEED_SKILLS = {
	software: [
		"JavaScript",
		"HTML/CSS",
		"Git",
		"REST APIs",
		"Debugging",
		"Testing",
		"SQL",
		"Problem solving",
	],
	data: [
		"SQL",
		"Spreadsheets",
		"Data visualization",
		"Python",
		"Statistics basics",
		"Storytelling",
	],
	design: ["UI/UX", "Figma", "Wireframing", "Prototyping", "Usability testing", "Accessibility"],
	product: ["Product thinking", "User research", "Prioritization", "Writing specs", "Stakeholder communication"],
	infra: ["Cloud fundamentals", "Networking", "Linux", "Scripting", "Security basics", "Observability"],
	mobile: ["Mobile UI", "State management", "API integration", "Debugging", "Testing"],
	default: ["Communication", "Problem solving", "Learning agility", "Team collaboration"],
};

export const ROLE_PROFILES = [
	{
		id: "junior-web-dev",
		title: "Junior Web Developer",
		track: "software",
		required: ["JavaScript", "HTML/CSS", "Git", "Debugging"],
		bonus: ["React", "Node.js", "REST APIs", "Testing", "SQL"],
		description: "Build user-facing features and ship small end-to-end web projects with clean code and basic tests.",
	},
	{
		id: "backend-dev",
		title: "Backend Developer",
		track: "software",
		required: ["APIs", "Databases", "Git", "Debugging"],
		bonus: ["Node.js", "Python", "SQL", "Testing", "Cloud fundamentals"],
		description: "Design APIs, data models, and reliability basics (validation, errors, logging).",
	},
	{
		id: "data-analyst",
		title: "Data Analyst",
		track: "data",
		required: ["SQL", "Data visualization", "Communication"],
		bonus: ["Spreadsheets", "Statistics basics", "Python", "Dashboards"],
		description: "Turn questions into clear charts and decisions with trustworthy definitions and queries.",
	},
	{
		id: "qa-automation",
		title: "QA / Test Automation Engineer",
		track: "mobile",
		required: ["Testing", "Debugging", "Communication"],
		bonus: ["JavaScript", "APIs", "CI/CD", "Automation"],
		description: "Raise quality with smart test strategy, automation, and stable CI signals.",
	},
	{
		id: "ux-designer",
		title: "UX / Product Designer",
		track: "design",
		required: ["UI/UX", "Communication", "Collaboration"],
		bonus: ["Figma", "Wireframing", "Prototyping", "Usability testing", "Accessibility"],
		description: "Design flows, prototypes, and case studies that connect user needs to product outcomes.",
	},
	{
		id: "product-manager",
		title: "Associate / Junior Product Manager",
		track: "product",
		required: ["Communication", "Prioritization", "Problem solving"],
		bonus: ["User research", "Writing specs", "Analytics basics", "Collaboration"],
		description: "Clarify problems, align teams, and ship outcomes with crisp writing and tradeoffs.",
	},
	{
		id: "devops",
		title: "DevOps / Platform Engineer",
		track: "infra",
		required: ["Cloud fundamentals", "Linux", "Networking"],
		bonus: ["DevOps", "CI/CD", "Docker", "Security basics", "Observability", "Scripting"],
		description: "Automate delivery and reliability so teams ship safely and recover quickly.",
	},
	{
		id: "cyber-analyst",
		title: "Cybersecurity Analyst",
		track: "infra",
		required: ["Cybersecurity fundamentals", "Networking", "Communication"],
		bonus: ["Linux", "Incident response", "Scripting", "Risk management"],
		description: "Monitor signals, triage incidents, and harden systems with clear risk communication.",
	},
	{
		id: "it-support",
		title: "IT Support / Technical Support Specialist",
		track: "infra",
		required: ["Communication", "Troubleshooting", "Networking basics"],
		bonus: ["Windows/Linux", "Ticketing", "Customer support", "Security basics"],
		description: "Solve user issues end-to-end: diagnose, fix, document, and prevent repeats.",
	},
];

export const CERT_LIBRARY = [
	{
		id: "google-it-support",
		name: "Google IT Support Professional Certificate",
		forTracks: ["infra", "default"],
		builds: ["Networking basics", "Linux", "Troubleshooting", "Security basics", "Customer support"],
		reason:
			"Strong starting credential for IT support: troubleshooting, networking, operating systems, system administration, and security basics.",
	},
	{
		id: "comptia-a-plus",
		name: "CompTIA A+ (Core 1 + Core 2)",
		forTracks: ["infra", "default"],
		builds: ["Troubleshooting", "Networking basics", "Operating systems", "Security basics"],
		reason:
			"Industry baseline for IT roles: devices, networking, troubleshooting, OS fundamentals, and security basics.",
	},
	{
		id: "comptia-network-plus",
		name: "CompTIA Network+",
		forTracks: ["infra"],
		builds: ["Networking", "Troubleshooting", "Network security", "Operations"],
		reason: "Solid vendor-neutral networking foundation: concepts, implementation, operations, security, and troubleshooting.",
	},
	{
		id: "isc2-cc",
		name: "ISC2 Certified in Cybersecurity (CC)",
		forTracks: ["infra"],
		builds: ["Security principles", "Access controls", "Network security", "Security operations"],
		reason: "Entry-level security credential covering principles, access controls, network security, and operations.",
	},
	{
		id: "comptia-security-plus",
		name: "CompTIA Security+",
		forTracks: ["infra"],
		builds: ["Threats & mitigations", "IAM basics", "Architecture & design", "Security operations"],
		reason: "Popular baseline for security roles: threats, identity/access, architecture, and risk management practices.",
	},
	{
		id: "aws-ccp",
		name: "AWS Certified Cloud Practitioner (CLF-C02)",
		forTracks: ["infra", "software"],
		builds: ["Cloud concepts", "Security & compliance", "Core services", "Billing basics"],
		reason: "Cloud fundamentals: shared responsibility, services, and cost concepts—useful before deeper cloud certs.",
	},
	{
		id: "ms-az-900",
		name: "Microsoft AZ-900 (Azure Fundamentals)",
		forTracks: ["infra", "software"],
		builds: ["Cloud concepts", "Azure services", "Identity basics", "Governance & monitoring"],
		reason: "Azure fundamentals: compute, networking, storage, identity, and governance basics for cloud beginners.",
	},
	{
		id: "ms-sc-900",
		name: "Microsoft SC-900 (Security, Compliance & Identity Fundamentals)",
		forTracks: ["infra"],
		builds: ["Security concepts", "Identity basics", "SIEM/SOAR concepts", "Compliance basics"],
		reason: "Security and identity fundamentals across Microsoft cloud services; good for early security exposure.",
	},
	{
		id: "google-data-analytics",
		name: "Google Data Analytics Professional Certificate",
		forTracks: ["data"],
		builds: ["SQL", "Spreadsheets", "Python", "Tableau", "Data cleaning", "Storytelling"],
		reason: "Practical entry path into analytics: cleaning, analysis, visualization, and dashboards with common tools.",
	},
	{
		id: "google-ux",
		name: "Google UX Design Professional Certificate",
		forTracks: ["design"],
		builds: ["UI/UX", "Research", "Wireframing", "Prototyping", "Accessibility", "Portfolio"],
		reason: "Structured UX process: research → wireframes → prototypes → testing, plus portfolio-ready projects.",
	},
	{
		id: "istqb-ctfl",
		name: "ISTQB Certified Tester Foundation Level (CTFL)",
		forTracks: ["mobile", "software"],
		builds: ["Testing fundamentals", "Test design", "Static testing", "Test planning", "Tools basics"],
		reason: "Foundation for QA roles: testing vocabulary, design techniques, planning, and tooling concepts.",
	},
];

