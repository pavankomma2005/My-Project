/**
 * Higher-education and credential routes aligned to learning tracks.
 * Generic, region-agnostic framing; users refine in Settings (focus, goals, level).
 */

const baseExams = [
	{
		title: "Standardized admissions",
		detail:
			"Many universities use broad aptitude tests (e.g. SAT/ACT or national equivalents). Start early: diagnostic test → gap plan → timed practice.",
	},
	{
		title: "Subject or portfolio supplements",
		detail:
			"STEM and design programs often value strong math/science scores or portfolios. Build a small but polished project set aligned to the program’s language.",
	},
	{
		title: "English proficiency (if studying abroad)",
		detail: "Plan IELTS/TOEFL with a 8–12 week prep window if required by target schools.",
	},
];

export const EDUCATION_BY_TRACK = {
	software: {
		headline: "Degrees & credentials that pair well with software careers",
		intro:
			"Computer Science, Software Engineering, or Information Systems degrees remain common on-ramps. Many employers also hire strong bootcamp or self-taught candidates with proof—your roadmap and portfolio matter either way.",
		routes: [
			{
				title: "B.S. / B.Sc. Computer Science",
				credential: "Undergraduate degree",
				duration: "Typically 3–4 years",
				description:
					"Deep algorithms, systems, and theory plus math. Best when you want maximum optionality (research, big tech, graduate school).",
				fit: "Strong fit",
			},
			{
				title: "B.Tech / B.E. IT or Computer Engineering",
				credential: "Undergraduate degree",
				duration: "Typically 4 years",
				description:
					"Balanced hardware/software exposure; common path where engineering admissions are centralized.",
				fit: "Strong fit",
			},
			{
				title: "Accelerated bootcamp + degree pathway",
				credential: "Certificate + transfer / online degree",
				duration: "6–24 months (varies)",
				description:
					"Fast skill ramp followed by formal credential completion—useful if you need income quickly then backfill degree.",
				fit: "Flexible",
			},
			{
				title: "Online CS / MIS (while working)",
				credential: "Degree or diploma",
				duration: "Part-time multi-year",
				description:
					"Keeps employability while studying; pair every course module with a repo artifact.",
				fit: "Flexible",
			},
		],
		exams: baseExams,
	},
	design: {
		headline: "Education routes for design & product-adjacent roles",
		intro:
			"HCI, graphic or communication design, architecture (UX), and interdisciplinary product programs all work. Portfolios outweigh transcripts—choose programs that protect studio time.",
		routes: [
			{
				title: "B.Des / BFA interaction or visual design",
				credential: "Undergraduate",
				duration: "3–4 years",
				description: "Studio-heavy; build a disciplined case-study process early.",
				fit: "Strong fit",
			},
			{
				title: "HCI or cognitive science + design minor",
				credential: "Undergraduate",
				duration: "4 years",
				description: "Strong research lens; pair with internships touching product teams.",
				fit: "Strong fit",
			},
			{
				title: "Master’s in HCI / UX (after another degree)",
				credential: "Graduate",
				duration: "1–2 years",
				description: "Common pivot path; costly—justify with target role geography and salary data.",
				fit: "Flexible",
			},
		],
		exams: [
			...baseExams.slice(0, 2),
			{
				title: "Portfolio review readiness",
				detail: "Many programs score process artifacts; document iterations, not only finals.",
			},
		],
	},
	data: {
		headline: "Education paths for analytics & data science",
		intro:
			"Statistics, mathematics, economics, computer science, and business analytics programs all feed the field. Proof of SQL + modeling projects closes gaps if your major is adjacent.",
		routes: [
			{
				title: "Statistics or Mathematics B.S.",
				credential: "Undergraduate",
				duration: "3–4 years",
				description: "Strong theory base; add SQL and visualization courses or projects.",
				fit: "Strong fit",
			},
			{
				title: "Business analytics / MIS",
				credential: "Undergraduate",
				duration: "3–4 years",
				description: "Closer to stakeholders; supplement with rigorous stats and coding.",
				fit: "Strong fit",
			},
			{
				title: "M.S. Data Science / Analytics",
				credential: "Graduate",
				duration: "1–2 years",
				description: "Useful pivot with clear ROI homework on target employers.",
				fit: "Flexible",
			},
		],
		exams: baseExams,
	},
	product: {
		headline: "Backgrounds that feed product management",
		intro:
			"PM is rarely a first undergraduate major—common paths combine CS, business, design, or domain degrees with leadership evidence. Internships and cross-functional projects count heavily.",
		routes: [
			{
				title: "CS / Engineering + business electives",
				credential: "Undergraduate",
				duration: "4 years",
				description: "Technical credibility with econ, strategy, or org behavior courses.",
				fit: "Strong fit",
			},
			{
				title: "Business / Economics + technical minor",
				credential: "Undergraduate",
				duration: "3–4 years",
				description: "Pair with coding literacy and one shipped group project.",
				fit: "Strong fit",
			},
			{
				title: "MBA or specialized product programs (later)",
				credential: "Graduate",
				duration: "1–2 years",
				description: "Often mid-career; weigh cost against internal PM transition options.",
				fit: "Flexible",
			},
		],
		exams: baseExams,
	},
	infra: {
		headline: "Education for cloud, platform, and security careers",
		intro:
			"Computer engineering, CS with systems focus, or IT programs are common. Certifications complement but rarely replace project proof—labs and homelab stories matter.",
		routes: [
			{
				title: "Computer Science (systems track)",
				credential: "Undergraduate",
				duration: "4 years",
				description: "OS, networks, distributed systems—seek courses with hands-on labs.",
				fit: "Strong fit",
			},
			{
				title: "Information Security / Cybersecurity program",
				credential: "Undergraduate or graduate",
				duration: "2–4 years",
				description: "Align with SOC, GRC, or appsec interests early via electives.",
				fit: "Strong fit",
			},
			{
				title: "Cloud certifications + applied projects",
				credential: "Professional certs",
				duration: "3–9 months",
				description: "Use certs to structure learning; document architectures you built.",
				fit: "Flexible",
			},
		],
		exams: [
			...baseExams.slice(0, 2),
			{
				title: "Vendor or security certifications (optional)",
				detail: "Pick one foundational cert with a lab component; avoid collecting without projects.",
			},
		],
	},
	mobile: {
		headline: "Education paths for mobile & quality engineering",
		intro:
			"CS and software engineering degrees are typical; QA paths sometimes start from ISTQB-style foundations plus automation projects. Build store-ready apps regardless of formal track.",
		routes: [
			{
				title: "B.S. Computer Science (mobile electives)",
				credential: "Undergraduate",
				duration: "4 years",
				description: "Add mobile-focused projects every semester; contribute to OSS clients.",
				fit: "Strong fit",
			},
			{
				title: "Vocational diploma + portfolio",
				credential: "Diploma",
				duration: "1–3 years",
				description: "Works when paired with aggressive internship search and GitHub proof.",
				fit: "Flexible",
			},
			{
				title: "Test automation specialization",
				credential: "Certificate / boot module",
				duration: "3–6 months",
				description: "Combine with open-source test contributions and CI demos.",
				fit: "Flexible",
			},
		],
		exams: baseExams,
	},
	default: {
		headline: "Flexible education routes while you explore",
		intro:
			"Until you lock a specialization, favor transferable cores: math, communication, introductory programming, and one domain (science, business, or design). Revisit this page after updating Guidance or Settings.",
		routes: [
			{
				title: "Liberal arts / science + CS minor",
				credential: "Undergraduate",
				duration: "4 years",
				description: "Keeps breadth; require a minor or certificate with graded projects.",
				fit: "Flexible",
			},
			{
				title: "Associate → transfer to B.S.",
				credential: "2+2 pathway",
				duration: "4 years total typical",
				description: "Cost-aware; map transfer credits early to avoid retakes.",
				fit: "Strong fit",
			},
			{
				title: "Stackable online micro-credentials",
				credential: "Certificates",
				duration: "Rolling",
				description: "Use EduPath Expert Courses plus formal certs to build a coherent story.",
				fit: "Flexible",
			},
		],
		exams: baseExams,
	},
};
