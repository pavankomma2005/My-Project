/**
 * Expert-curated paths when live AI is unavailable or returns invalid JSON.
 * Rich shape powers both list cards and full detail sections (no “sample” framing in UI).
 */

/** How many curated cards appear on the main Guidance grid (full library still used for deep links). */
export const CURATED_HOME_LIST_LIMIT = 3;

export const STATIC_GUIDANCE_RECOMMENDATIONS = [
	{
		title: "Software Engineer",
		match: "Strong",
		summary:
			"Design, build, and maintain software that people rely on every day. This path rewards clear thinking about systems, APIs, and quality. You grow fastest by shipping small real projects, reading production-grade code, and learning how teams collaborate in code review and delivery.",
		insight:
			"Most hiring signals today are evidence of craft: readable code, tests where they matter, and a story about something you shipped end-to-end. You do not need every framework—depth in one stack plus transferable habits beats chasing every trend.",
		whyThisPath:
			"If you enjoy breaking problems into steps, debugging until something works, and improving how software behaves over time, engineering is a natural fit. The work stays challenging because technology changes, but fundamentals—data structures, clarity, reliability—compound for decades.",
		nextSteps: [
			"Pick one primary language (e.g. JavaScript, Python, or Go) and use it daily for 30 days.",
			"Build a CLI or script that solves a personal annoyance (file organizer, habit tracker, API poller).",
			"Add automated tests to one project—even a handful proves you care about regressions.",
			"Read one open-source service or library you use; note how it structures modules and errors.",
			"Publish the project with a short README: problem, setup, and what you would improve next.",
			"Practice explaining one technical decision out loud as if to a teammate.",
		],
		timeline: {
			immediate: [
				"Set up Git, a consistent formatter, and a simple CI check (lint or test).",
				"Complete one guided backend or frontend tutorial without copy-pasting blindly.",
				"Pair with a friend or community review on a small PR-style diff.",
			],
			shortTerm: [
				"Ship a CRUD app with auth or roles and basic validation.",
				"Instrument logging and handle at least three edge cases users might hit.",
				"Contribute a docs fix or small bugfix to an OSS repo you respect.",
			],
			longTerm: [
				"Own a feature in a team or internship setting from spec to deploy.",
				"Deepen one specialty: performance, security, distributed systems, or platform.",
				"Build a portfolio narrative: problems, tradeoffs, metrics, and lessons learned.",
			],
		},
		skillThemes: [
			{ skill: "Problem decomposition", why: "Turn vague asks into implementable slices.", howToStart: "Write a one-page spec before coding for your next idea." },
			{ skill: "Testing mindset", why: "Confidence to refactor and ship without fear.", howToStart: "Add one test file next to your hottest code path." },
			{ skill: "APIs & data", why: "Most products are services talking to services.", howToStart: "Build a JSON API with pagination and clear error shapes." },
			{ skill: "Observability", why: "You fix what you can see.", howToStart: "Log request IDs and one business metric on a demo app." },
		],
		resourceIdeas: [
			{ name: "OSS codebase walkthroughs", kind: "documentation", note: "Pick a medium-sized repo and trace one user flow through the code." },
			{ name: "System design primers", kind: "book", note: "Sketch architectures for chat, feed, or checkout—latency, storage, failure modes." },
			{ name: "Interview-style pair practice", kind: "community", note: "Explain aloud while coding; time-box to 45 minutes." },
		],
		encouragement:
			"Consistency beats intensity. One steady project month teaches more than ten abandoned tutorials. Ship small, reflect often, and let your repo tell your story.",
	},
	{
		title: "UX / Product Designer",
		match: "Good",
		summary:
			"Shape how products feel and behave through research, interaction design, and visual craft. Strong designers combine empathy with rigor: they validate assumptions, prototype quickly, and align teams around clear user outcomes.",
		insight:
			"Portfolios that win tell a story per project: who the user is, what you learned, what you tried, and why the final solution is stronger. Screenshots alone rarely carry that weight—process artifacts do.",
		whyThisPath:
			"If you notice friction in everyday apps, enjoy sketching flows, and like collaborating with engineering and product, UX and product design give you leverage over the entire experience—not just pixels.",
		nextSteps: [
			"Pick one app you use weekly and document three usability pain points with screenshots.",
			"Rebuild one flow in Figma with components, variants, and a simple prototype.",
			"Run two informal interviews (15 min) and synthesize findings into three insights.",
			"Create a case study page: problem, research, ideation, decision, outcome—even if hypothetical metrics.",
			"Practice giving critique using goals, users, and constraints—not personal taste alone.",
			"Share work in a community or class and revise once based on feedback.",
		],
		timeline: {
			immediate: [
				"Learn keyboard shortcuts in your design tool; speed unlocks iteration.",
				"Copy a screen you admire to study spacing, type scale, and hierarchy.",
				"Define one persona and one primary scenario for a practice project.",
			],
			shortTerm: [
				"Ship a three-screen mobile flow with accessibility basics (contrast, labels).",
				"Facilitate a mini design critique with two peers using a rubric.",
				"Pair with a developer to implement one component and note handoff gaps.",
			],
			longTerm: [
				"Lead a small redesign with a lightweight research plan and success signals.",
				"Build fluency in design systems: tokens, states, and documentation patterns.",
				"Publish two polished case studies that show thinking, not only visuals.",
			],
		},
		skillThemes: [
			{ skill: "User research", why: "Design without evidence is guessing.", howToStart: "Ask five people the same three open questions about a task." },
			{ skill: "Interaction design", why: "Flows carry cognitive load; good IA reduces it.", howToStart: "Map a happy path and two edge states on paper first." },
			{ skill: "Visual hierarchy", why: "Guides attention and trust.", howToStart: "Audit type scale and spacing on a page you dislike." },
			{ skill: "Collaboration", why: "Design is negotiated with reality.", howToStart: "Write acceptance criteria for one feature alongside a PM/dev." },
		],
		resourceIdeas: [
			{ name: "Design critique groups", kind: "community", note: "Weekly feedback sharpens articulation faster than solo polish." },
			{ name: "Accessibility checklists", kind: "documentation", note: "Bake WCAG-minded habits into early mocks, not late fixes." },
			{ name: "Micro-copy exercises", kind: "tool", note: "Rewrite empty states, errors, and onboarding for clarity and tone." },
		],
		encouragement:
			"Your edge is judgment refined by feedback. Show how you think, ship iterations, and keep users at the center—opportunities follow clarity.",
	},
	{
		title: "Data Analyst",
		match: "Good",
		summary:
			"Answer business questions with data: cleaning, modeling, visualization, and clear narratives. Analysts bridge spreadsheets and decisions—strong SQL, statistics intuition, and storytelling set you apart.",
		insight:
			"Hiring managers look for repeatable workflows: documented assumptions, reproducible queries, and charts that make the takeaway obvious in one glance. A tight memo beats a sprawling dashboard.",
		whyThisPath:
			"If you like structured thinking, spot patterns easily, and enjoy explaining numbers to non-technical partners, analytics is a high-trust role that touches strategy, product, and operations.",
		nextSteps: [
			"Download a public dataset (government, sports, ecommerce) and write a one-page question list.",
			"Write SQL (or equivalent) for joins, filters, aggregates, and window-style rankings.",
			"Build one dashboard with a clear headline metric and two supporting charts.",
			"Document data quality issues you found and how they affect conclusions.",
			"Present findings in five slides: context, method, result, limitation, next step.",
			"Automate a weekly report script or notebook someone else could run.",
		],
		timeline: {
			immediate: [
				"Set up a notebook or BI tool workflow you can repeat.",
				"Practice explaining mean vs median and when each misleads.",
				"Plot the same metric three ways and pick the least misleading view.",
			],
			shortTerm: [
				"Model a funnel or cohort with explicit definitions.",
				"Peer-review someone else’s chart: what question does it actually answer?",
				"Learn basic experimentation vocabulary: control, power, peeking bias.",
			],
			longTerm: [
				"Partner on a cross-team metric definition workshop.",
				"Shadow a stakeholder meeting and practice translating asks into queries.",
				"Publish a portfolio project with code or queries redacted appropriately.",
			],
		},
		skillThemes: [
			{ skill: "SQL & data modeling", why: "Most answers live in joins and grain.", howToStart: "Draw entity relationships before writing queries." },
			{ skill: "Statistics intuition", why: "Avoid false confidence from noisy samples.", howToStart: "Simulate small samples in a notebook to feel variance." },
			{ skill: "Visualization ethics", why: "Scales and baselines change the story.", howToStart: "Red-team your own chart: how could this mislead?" },
			{ skill: "Stakeholder comms", why: "Impact is realized when others act on insight.", howToStart: "Lead with the decision, then the evidence." },
		],
		resourceIdeas: [
			{ name: "Public data portals", kind: "documentation", note: "Pick messy real-world data to practice cleaning narratives." },
			{ name: "Storytelling with data guides", kind: "book", note: "Study titles, annotations, and ordering of reveals." },
			{ name: "Kaggle-style kernels", kind: "community", note: "Read top notebooks for structure, not for copying models blindly." },
		],
		encouragement:
			"Clarity is kindness. When your work makes the next decision obvious, you become indispensable—keep tightening definitions and visuals.",
	},
	{
		title: "DevOps / Platform Engineer",
		match: "Explore",
		summary:
			"Make delivery safe, fast, and observable: pipelines, infrastructure as code, containers, and reliability practices. Platform engineers reduce toil so product teams ship with confidence.",
		insight:
			"Employers notice engineers who can trace a change from commit to production, explain rollback, and define SLOs in plain language. Breadth with one cloud provider beats shallow tours of five tools.",
		whyThisPath:
			"If you like automation, care about security and cost, and enjoy enabling others, platform work scales your impact across many services and teams.",
		nextSteps: [
			"Containerize an app you wrote or forked; document build and run commands.",
			"Create a CI workflow that runs tests and blocks merges on failure.",
			"Deploy the same app to a small cloud project with secrets outside the repo.",
			"Add structured logs and one health check endpoint.",
			"Practice a rollback story: what breaks, how you detect it, how you recover.",
			"Read one postmortem (public or internal) and summarize preventable causes.",
		],
		timeline: {
			immediate: [
				"Version your infra snippets (Terraform, Bicep, or cloud-native YAML).",
				"Run everything locally via compose or equivalent once.",
				"Track monthly cloud spend on a toy project.",
			],
			shortTerm: [
				"Introduce staging with data anonymization rules documented.",
				"Prototype canary or blue-green mentally on paper for your app.",
				"Automate dependency updates with guardrails.",
			],
			longTerm: [
				"Define SLOs and error budgets for a service you own.",
				"Champion developer experience: templates, docs, golden paths.",
				"Participate in incident response drills or game days.",
			],
		},
		skillThemes: [
			{ skill: "CI/CD", why: "Repeatable pipelines reduce fear of release.", howToStart: "Cache dependencies; fail fast on lint." },
			{ skill: "Containers", why: "Portable units for dev and prod parity.", howToStart: "Multi-stage builds to slim images." },
			{ skill: "Observability", why: "Metrics, logs, traces shorten incidents.", howToStart: "One golden signal dashboard per service." },
			{ skill: "Security basics", why: "Secrets and IAM mistakes are expensive.", howToStart: "Least-privilege IAM on a demo bucket." },
		],
		resourceIdeas: [
			{ name: "SRE workbooks", kind: "book", note: "Practice writing error budgets in user-facing terms." },
			{ name: "Cloud well-architected pillars", kind: "documentation", note: "Score a toy architecture and note tradeoffs." },
			{ name: "OpenGitOps examples", kind: "community", note: "Study how teams reconcile desired vs actual state." },
		],
		encouragement:
			"Reliability is a feature. Every script you document and every alert you tune saves future you—and your teammates—real time.",
	},
	{
		title: "Product Manager",
		match: "Explore",
		summary:
			"Own outcomes by aligning user value, business constraints, and engineering feasibility. PMs clarify problems, prioritize ruthlessly, and communicate decisions with evidence and empathy.",
		insight:
			"Strong PM candidates show decision journals: options considered, assumptions, chosen bet, and what would change their mind. Roadmaps as lists of features impress less than narratives tied to metrics.",
		whyThisPath:
			"If you enjoy facilitation, writing crisp briefs, and living in ambiguous spaces between users and builders, product management multiplies impact without owning every line of code.",
		nextSteps: [
			"Rewrite a vague idea into a problem statement with user, pain, and success signal.",
			"Interview five users with a script; affinity-map notes into themes.",
			"Prioritize a backlog using RICE, value vs effort, or a simple impact grid.",
			"Write a one-pager for a hypothetical launch: scope, risks, rollout.",
			"Run a retrospective on a personal project as if it were a product team.",
			"Practice saying no with a clear tradeoff explanation once a week.",
		],
		timeline: {
			immediate: [
				"Track assumptions explicitly in docs you write.",
				"Shadow a standup and note decision debt items.",
				"Create a lightweight competitive scan for a product you admire.",
			],
			shortTerm: [
				"Facilitate a prioritization workshop with sticky notes and timers.",
				"Define a north-star and two guardrail metrics for a practice scenario.",
				"Draft a rollout plan with feature flags or phased release.",
			],
			longTerm: [
				"Partner with design and eng on a discovery cycle end-to-end.",
				"Present a quarterly review: shipped, learned, next bets.",
				"Mentor a junior on writing crisp user stories and acceptance criteria.",
			],
		},
		skillThemes: [
			{ skill: "Discovery", why: "Build the right thing before building it right.", howToStart: "Run solution-free interviews weekly." },
			{ skill: "Prioritization", why: "Time and trust are finite.", howToStart: "Publish a transparent rationale with each cut." },
			{ skill: "Stakeholder management", why: "Alignment reduces thrash.", howToStart: "Send recap notes within 24h of key meetings." },
			{ skill: "Analytics partnership", why: "Decisions need measurable hooks.", howToStart: "Define events with engineering before shipping." },
		],
		resourceIdeas: [
			{ name: "Product teardown blogs", kind: "documentation", note: "Reverse-engineer positioning and onboarding flows." },
			{ name: "OKR primers", kind: "book", note: "Practice writing outcomes, not output lists." },
			{ name: "Communities of practice", kind: "community", note: "Share anonymized decision frameworks for feedback." },
		],
		encouragement:
			"Great PMs radiate calm clarity. Keep tying work to outcomes users feel and numbers leadership trusts.",
	},
	{
		title: "Cybersecurity Analyst",
		match: "Explore",
		summary:
			"Protect organizations by monitoring threats, hardening systems, and responding to incidents. The field blends curiosity, ethics, and technical depth across networks, identity, and applications.",
		insight:
			"Entry paths reward hands-on labs and clear writeups: what you observed, what it means, and what you would recommend. Certifications help, but narrated projects close interviews.",
		whyThisPath:
			"If you like puzzles, care about privacy, and want mission-driven work, security offers constant learning as attackers and defenders evolve together.",
		nextSteps: [
			"Set up a home lab VM and practice reading logs and PCAP basics.",
			"Complete a guided OWASP Top 10 lab and document one finding.",
			"Map the kill chain for a public breach summary in your own words.",
			"Practice writing a non-technical incident summary for executives.",
			"Automate one repetitive check (password policy audit, open port scan on lab).",
			"Join a CTF or blue-team challenge and journal what you learned.",
		],
		timeline: {
			immediate: [
				"Normalize patching and backups on your own devices first.",
				"Learn IAM vocabulary: MFA, least privilege, federation.",
				"Read one CVE writeup end-to-end.",
			],
			shortTerm: [
				"Build a phishing awareness mini-lesson for friends.",
				"Correlate two log sources in a SIEM-style exercise.",
				"Draft a tabletop scenario for ransomware response.",
			],
			longTerm: [
				"Specialize toward SOC, GRC, appsec, or cloud security consciously.",
				"Contribute policy or runbook improvements where you study or work.",
				"Present a lightning talk on one defensive control you implemented.",
			],
		},
		skillThemes: [
			{ skill: "Network fundamentals", why: "Most attacks traverse networks you must read.", howToStart: "Draw your home network and trust boundaries." },
			{ skill: "Threat modeling", why: "Proactive beats purely reactive.", howToStart: "STRIDE a small app you built." },
			{ skill: "Scripting", why: "Scale triage and enrichment.", howToStart: "Parse CSV alerts with a 50-line script." },
			{ skill: "Risk communication", why: "Fixes follow understood impact.", howToStart: "Translate CVSS into business terms once." },
		],
		resourceIdeas: [
			{ name: "Blue team labs", kind: "course", note: "Prefer guided labs with writeups over random tool flailing." },
			{ name: "NIST / CIS references", kind: "documentation", note: "Pick one control family and map to a small org." },
			{ name: "Security podcasts or briefings", kind: "video", note: "Weekly habit to stay current without doomscrolling." },
		],
		encouragement:
			"Defense is a team sport. Document generously, assume good intent in colleagues, and keep ethics at the center of your practice.",
	},
	{
		title: "Machine Learning Engineer",
		match: "Explore",
		summary:
			"Take models from experiments to dependable systems: data pipelines, training, evaluation, deployment, and monitoring. MLE sits between research curiosity and production discipline.",
		insight:
			"Portfolios that stand out show reproducible notebooks, clear metrics with confidence intervals, and a serving story—even a tiny FastAPI + Docker demo. Fancy architectures matter less than measurement honesty.",
		whyThisPath:
			"If you enjoy math-flavored coding, care about data quality, and like closing the gap between prototype and product, MLE channels that energy into measurable user or business impact.",
		nextSteps: [
			"Train a baseline model on a clean tabular dataset; beat it with one thoughtful feature.",
			"Split data properly; document leakage risks you avoided.",
			"Version datasets and code together for one project.",
			"Containerize inference with explicit input/output schema.",
			"Add basic monitoring ideas: drift, latency, error rates.",
			"Read one model card or datasheet and emulate its structure briefly.",
		],
		timeline: {
			immediate: [
				"Practice vectorized pandas or polars operations until comfortable.",
				"Plot residuals or calibration for a classifier you train.",
				"Write a short ethics note: who is harmed if this model fails?",
			],
			shortTerm: [
				"Serve a model behind an API with input validation.",
				"Benchmark latency and batch vs online tradeoffs.",
				"Try a simple AutoML baseline and explain when not to use it.",
			],
			longTerm: [
				"Collaborate with product on success metrics tied to model outputs.",
				"Prototype online learning or periodic retraining strategy on paper.",
				"Publish a reproducible project with Makefile or task runner.",
			],
		},
		skillThemes: [
			{ skill: "Experiment design", why: "Avoid fooling yourself with splits.", howToStart: "Stratify splits on leaky keys checklist." },
			{ skill: "Software engineering", why: "Models are code plus data contracts.", howToStart: "Type hints and schema validation on inputs." },
			{ skill: "Evaluation", why: "Optimize the right metric for the harm model.", howToStart: "Report precision/recall at an operating point." },
			{ skill: "MLOps basics", why: "Reliability beats offline leaderboard scores.", howToStart: "Log predictions with version tags." },
		],
		resourceIdeas: [
			{ name: "Papers with code", kind: "documentation", note: "Implement a tiny slice, not the whole SOTA stack." },
			{ name: "Kaggle discussions", kind: "community", note: "Focus on validation strategy comments." },
			{ name: "ML testing references", kind: "book", note: "Learn invariant and metamorphic test ideas." },
		],
		encouragement:
			"Humility with data beats hubris with models. Keep charts of errors close—your next breakthrough often hides there.",
	},
	{
		title: "Technical Writer",
		match: "Good",
		summary:
			"Make complex systems understandable through documentation, tutorials, and API references. Great technical writers reduce support load, accelerate adoption, and improve product quality by surfacing ambiguity early.",
		insight:
			"Hiring managers want clips that show structure: audience, prerequisites, task-based headings, and tested steps. A single excellent tutorial beats ten shallow blog posts.",
		whyThisPath:
			"If you enjoy teaching, editing for clarity, and collaborating with engineers without needing to own the core codebase, technical writing is a high-leverage craft.",
		nextSteps: [
			"Rewrite a confusing README from an OSS tool you use.",
			"Write a how-to with numbered steps and expected outputs per step.",
			"Add diagrams for one architecture you understand.",
			"Create a glossary for a domain you know (10 terms, plain language).",
			"User-test your doc with one beginner; revise once.",
			"Learn docs-as-code basics: Markdown, linting, and PR reviews for prose.",
		],
		timeline: {
			immediate: [
				"Adopt a style checklist: active voice, second person, short paragraphs.",
				"Annotate one doc with reader questions in the margin.",
				"Keep a swipe file of great error messages and onboarding flows.",
			],
			shortTerm: [
				"Publish a three-part tutorial series with consistent voice.",
				"Partner with an engineer to verify commands and code snippets.",
				"Propose a doc information architecture for a fictional product.",
			],
			longTerm: [
				"Own release notes for a project with user-impact framing.",
				"Lead a doc critique session with a rubric.",
				"Explore API reference generators and OpenAPI workflows.",
			],
		},
		skillThemes: [
			{ skill: "Information architecture", why: "Findability is part of clarity.", howToStart: "Card-sort headings before writing body text." },
			{ skill: "Audience analysis", why: "Experts and newcomers need different paths.", howToStart: "Write two intros for the same doc." },
			{ skill: "Editing", why: "Tight prose respects reader time.", howToStart: "Cut 20% words on a draft without losing steps." },
			{ skill: "Tooling", why: "Docs scale with workflows.", howToStart: "Automate link checking on a sample site." },
		],
		resourceIdeas: [
			{ name: "Google dev docs style guides", kind: "documentation", note: "Internalize patterns, then break them on purpose with reason." },
			{ name: "Write the Docs community", kind: "community", note: "Peer review accelerates growth." },
			{ name: "Diagram tools", kind: "tool", note: "Practice one consistent notation across a series." },
		],
		encouragement:
			"Clarity is a gift. Every sentence that prevents a support ticket is impact—keep testing instructions like code.",
	},
	{
		title: "Mobile Developer",
		match: "Good",
		summary:
			"Build experiences people carry everywhere: performance, offline behavior, notifications, and platform guidelines matter as much as features. Mobile developers balance UX polish with engineering constraints.",
		insight:
			"Strong candidates show apps with thoughtful state handling, accessibility, and crash resilience. A polished pet app beats an unfinished clone of a famous product.",
		whyThisPath:
			"If you enjoy tactile interfaces, motion, and tight resource budgets—and you like seeing friends use what you build—mobile is deeply rewarding.",
		nextSteps: [
			"Ship a two-screen app with navigation and persistent local storage.",
			"Handle loading, empty, and error states explicitly in UI.",
			"Add dark mode or dynamic type support once.",
			"Profile startup time or list scroll jank once with platform tools.",
			"Write a tiny automated UI test for a critical flow.",
			"Read human interface guidelines for your platform; note three applied changes.",
		],
		timeline: {
			immediate: [
				"Master layout constraints or Compose/SwiftUI basics deeply before adding features.",
				"Instrument one analytics event with clear naming.",
				"Practice reading crash stack traces from a test build.",
			],
			shortTerm: [
				"Integrate a REST API with cancellation on navigation away.",
				"Ship a beta via TestFlight or Play internal testing.",
				"Localize one screen as an exercise.",
			],
			longTerm: [
				"Contribute to a popular OSS mobile library.",
				"Own performance budgets for a feature area.",
				"Publish a blog post on one tricky platform bug you solved.",
			],
		},
		skillThemes: [
			{ skill: "UI state", why: "Bugs often live in lifecycle edges.", howToStart: "Diagram state for one screen explicitly." },
			{ skill: "Networking", why: "Mobile networks are hostile.", howToStart: "Retry with backoff; surface offline mode." },
			{ skill: "Accessibility", why: "Reach and compliance.", howToStart: "VoiceOver/TalkBack pass on primary flow." },
			{ skill: "Release hygiene", why: "Shipping safely is a skill.", howToStart: "Changelog discipline and staged rollout notes." },
		],
		resourceIdeas: [
			{ name: "Platform HIG / Material docs", kind: "documentation", note: "Treat as specs, not suggestions." },
			{ name: "Mobile perf talks", kind: "video", note: "Pick one technique to apply per week." },
			{ name: "Design handoff checklists", kind: "tool", note: "Reduce rework between design and code." },
		],
		encouragement:
			"Small polish compounds—animations, haptics, and respectful loading states turn users into fans. Keep one real device in your testing loop.",
	},
	{
		title: "Cloud Solutions Architect",
		match: "Explore",
		summary:
			"Design secure, cost-effective, resilient systems on cloud platforms. Architects translate requirements into diagrams, guardrails, and migration paths that teams can implement without chaos.",
		insight:
			"Interviewers love articulate tradeoffs: when to choose queues vs streams, SQL vs NoSQL, multi-region vs single-region with backups. Diagrams with legends beat buzzword clouds.",
		whyThisPath:
			"If you think in systems, enjoy whiteboarding, and want breadth across security, cost, and scale, architecture roles let you influence many services at once.",
		nextSteps: [
			"Draw current vs target architecture for a fictional SaaS with 10k users.",
			"Estimate monthly cost for your diagram using a pricing calculator.",
			"List failure modes: AZ outage, bad deploy, credential leak—mitigations per scenario.",
			"Implement a tiny multi-tier app behind HTTPS with managed identity for secrets.",
			"Document a decision record (ADR) for one technology choice.",
			"Present your architecture to a friend in five minutes; revise for clarity.",
		],
		timeline: {
			immediate: [
				"Learn one cloud’s core services map by heart for compute, storage, network.",
				"Tag resources in a demo project for cost tracking.",
				"Enable guardrails: MFA, bucket policies, least privilege.",
			],
			shortTerm: [
				"Prototype cross-AZ failover on paper for a stateful service.",
				"Run a tabletop on data residency requirements.",
				"Automate teardown of sandbox resources nightly.",
			],
			longTerm: [
				"Shadow enterprise architecture reviews if available.",
				"Build a reference landing zone pattern for small teams.",
				"Publish a comparison matrix you would trust for a real RFP.",
			],
		},
		skillThemes: [
			{ skill: "Reliability patterns", why: "Users notice uptime.", howToStart: "Redundancy, backoff, idempotency vocabulary." },
			{ skill: "Security architecture", why: "Trust boundaries are design.", howToStart: "Zero trust sketch for one app." },
			{ skill: "FinOps", why: "Architecture without cost awareness ages poorly.", howToStart: "Rightsize one workload with metrics." },
			{ skill: "Migration planning", why: "Risk lives in cutover.", howToStart: "Write a rollback checklist before migrating anything." },
		],
		resourceIdeas: [
			{ name: "Architecture center patterns", kind: "documentation", note: "Redraw them from memory weekly." },
			{ name: "Well-architected reviews", kind: "course", note: "Practice scoring and remediation stories." },
			{ name: "Case studies from cloud providers", kind: "documentation", note: "Note constraints customers actually had." },
		],
		encouragement:
			"Good architects make hard choices explicit. Keep ADRs short, honest, and kind to future readers—including you.",
	},
	{
		title: "QA / Test Automation Engineer",
		match: "Explore",
		summary:
			"Raise quality through thoughtful test strategy, automation, and collaboration. Modern QA partners early—shifting left with fast feedback loops and clear quality signals for release decisions.",
		insight:
			"Strong QA portfolios show a pyramid: lots of fast unit/integration checks, fewer brittle UI tests, and exploratory sessions documented with charters. Flaky test cleanup stories impress hiring managers.",
		whyThisPath:
			"If you enjoy breaking things constructively, designing experiments, and advocating for users before they hit bugs, QA and test automation are high-trust specialties.",
		nextSteps: [
			"Pick an app and write a one-page test plan with risks and priorities.",
			"Automate one API contract test with clear assertions.",
			"Add one stable UI test with explicit waits—not sleeps.",
			"Run an exploratory session with time-box and debrief notes.",
			"Open two bugs with repro steps, expected vs actual, environment.",
			"Measure flake rate on a small suite for a week; fix one root cause.",
		],
		timeline: {
			immediate: [
				"Learn selectors and accessibility-driven queries.",
				"Run tests in CI locally identical to remote.",
				"Pair with dev on a failing test before muting it.",
			],
			shortTerm: [
				"Introduce test data factories or fixtures.",
				"Add visual or snapshot testing where valuable—not everywhere.",
				"Collaborate on definition of done including tests.",
			],
			longTerm: [
				"Own a quality dashboard for a team: coverage where it matters, not vanity.",
				"Champion contract tests between services.",
				"Mentor others on writing minimal reproducible cases.",
			],
		},
		skillThemes: [
			{ skill: "Test design", why: "Coverage of behaviors, not lines.", howToStart: "Equivalence partitions on one form." },
			{ skill: "Automation architecture", why: "Maintainability decides longevity.", howToStart: "Page object or fixture discipline." },
			{ skill: "CI integration", why: "Fast signal wins trust.", howToStart: "Parallelize safely; quarantine flakes." },
			{ skill: "Communication", why: "Quality is negotiated.", howToStart: "Risk-based release notes." },
		],
		resourceIdeas: [
			{ name: "Ministry of Testing resources", kind: "community", note: "Exploratory testing charters as a habit." },
			{ name: "API testing tools", kind: "tool", note: "Learn one tool deeply before collecting ten." },
			{ name: "Flakiness playbooks", kind: "documentation", note: "Treat stability as a feature with owners." },
		],
		encouragement:
			"Every bug you catch early is time returned to users and teams. Stay curious, stay kind in bug reports, and automate thoughtfully.",
	},
	{
		title: "Developer Advocate",
		match: "Explore",
		summary:
			"Grow adoption and empathy between builders and product through talks, docs, samples, and community programs. Devrels translate technical value into narratives developers actually want to follow.",
		insight:
			"Hiring teams look for public artifacts with reach and feedback loops: a well-scaffolded repo, a tight workshop, or a video series with measurable engagement. Authenticity beats hype.",
		whyThisPath:
			"If you love teaching, shipping demos, and listening to developer pain in forums and issues, advocacy lets you scale impact across ecosystems.",
		nextSteps: [
			"Publish a starter repo with README, license, and issues welcome template.",
			"Record a 12-minute tutorial with chapters and a repo link.",
			"Answer five Stack Overflow or forum questions thoughtfully with citations.",
			"Run a live coding session; collect three questions for a follow-up post.",
			"Measure one metric: stars, completion rate, or issue resolution time.",
			"Gather three pieces of product feedback from developers and summarize themes.",
		],
		timeline: {
			immediate: [
				"Define your niche audience in one sentence.",
				"Batch-create content templates: blog, thread, short video.",
				"Engage daily in one community without self-promo spam.",
			],
			shortTerm: [
				"Partner with engineering on a sample aligned with a release.",
				"Host a small meetup or lunch-and-learn with a feedback form.",
				"Iterate content based on comments and drop-off analytics.",
			],
			longTerm: [
				"Speak at a local or virtual event with a practiced CFP pitch.",
				"Build a champion program outline for advanced users.",
				"Publish a quarterly learnings post transparently.",
			],
		},
		skillThemes: [
			{ skill: "Storytelling", why: "Developers remember narratives.", howToStart: "Hook, struggle, resolution in every piece." },
			{ skill: "Code empathy", why: "Meet devs where they copy-paste.", howToStart: "Test your README on a fresh machine." },
			{ skill: "Metrics", why: "Advocacy must prove value.", howToStart: "Pick one north-star per quarter." },
			{ skill: "Feedback loops", why: "Product improves when you carry voices back.", howToStart: "Weekly synthesis note to internal teams." },
		],
		resourceIdeas: [
			{ name: "Talk writing frameworks", kind: "book", note: "Practice outlines before slides." },
			{ name: "OSS maintainer guides", kind: "documentation", note: "Healthy communities scale kindness plus boundaries." },
			{ name: "Analytics for technical content", kind: "tool", note: "Watch completion, not vanity views alone." },
		],
		encouragement:
			"Trust is cumulative. Show up consistently, credit others, and let developers feel heard—your advocacy will compound.",
	},
];

export function mapStaticRecommendation(r) {
	if (!r || typeof r !== "object") return null;
	const timeline =
		r.timeline && typeof r.timeline === "object"
			? {
					immediate: Array.isArray(r.timeline.immediate) ? r.timeline.immediate : [],
					shortTerm: Array.isArray(r.timeline.shortTerm) ? r.timeline.shortTerm : [],
					longTerm: Array.isArray(r.timeline.longTerm) ? r.timeline.longTerm : [],
				}
			: null;
	return {
		title: r.title,
		match: r.match || "Explore",
		summary: r.summary || "",
		nextSteps: Array.isArray(r.nextSteps) ? r.nextSteps : [],
		insight: r.insight || "",
		whyThisPath: r.whyThisPath || "",
		timeline,
		skillThemes: Array.isArray(r.skillThemes) ? r.skillThemes : [],
		resourceIdeas: Array.isArray(r.resourceIdeas) ? r.resourceIdeas : [],
		encouragement: r.encouragement || "",
	};
}
