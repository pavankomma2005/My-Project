/**
 * Career roadmap phases by resolved learning track (see learningPlan.js).
 */

export const ROADMAPS_BY_TRACK = {
	software: {
		title: "Software engineering",
		tagline: "Ship reliable code, grow depth in one stack, and prove craft with real projects.",
		phases: [
			{
				title: "Foundations",
				window: "Months 1–3",
				summary: "Build daily coding fluency, version control habits, and your first small shipped artifact.",
				skills: ["One core language", "Git & PR workflow", "Debugging & reading errors"],
				milestones: [
					"Complete a structured intro course with typed-along projects",
					"Publish one CLI or script that solves a personal problem",
					"Use branches, meaningful commits, and a short README",
				],
				courseFocus: "Programming fundamentals, Git, HTTP basics",
			},
			{
				title: "Core stack & systems",
				window: "Months 4–9",
				summary: "Pick a web or backend stack, learn data modeling, APIs, and testing where they matter.",
				skills: ["REST or GraphQL", "SQL & persistence", "Automated tests on critical paths"],
				milestones: [
					"Ship a CRUD app with auth or roles and validation",
					"Design simple DB schema; explain one indexing tradeoff",
					"Add CI that runs lint or tests on every push",
				],
				courseFocus: "Full-stack or backend specialization, databases, testing",
			},
			{
				title: "Depth & collaboration",
				window: "Months 8–14",
				summary: "Own features end-to-end, read production-style code, and practice code review.",
				skills: ["Refactoring", "Observability basics", "Async & performance intuition"],
				milestones: [
					"Contribute a non-trivial change to an OSS or team repo",
					"Write a short design note before a medium feature",
					"Run a postmortem or retro on one bug you introduced or fixed",
				],
				courseFocus: "System design intro, cloud deploy, logging/metrics",
			},
			{
				title: "Career launch",
				window: "Months 12+",
				summary: "Translate experience into a clear story: impact, tradeoffs, and what you want next.",
				skills: ["Interview practice", "Portfolio narrative", "Stakeholder communication"],
				milestones: [
					"Three portfolio stories with problem → action → outcome",
					"Mock interviews with timed coding and system sketching",
					"Target roles; tailor resume bullets to each posting",
				],
				courseFocus: "Interview prep, system design, specialization electives",
			},
		],
	},
	design: {
		title: "Design & product experience",
		tagline: "Blend research, interaction, and visuals to ship experiences people understand and trust.",
		phases: [
			{
				title: "Foundations",
				window: "Months 1–3",
				summary: "Tool fluency, layout hierarchy, and lightweight research habits.",
				skills: ["Figma components", "Typography & spacing", "Basic usability heuristics"],
				milestones: [
					"Recreate one complex screen to study structure",
					"Run three 15-minute interviews on a single task",
					"Prototype one flow with states: loading, empty, error",
				],
				courseFocus: "UI design, design systems intro, user research basics",
			},
			{
				title: "Product thinking",
				window: "Months 4–8",
				summary: "Connect outcomes to metrics, prioritize, and collaborate with engineering.",
				skills: ["Journey mapping", "Prioritization", "Spec & handoff quality"],
				milestones: [
					"One case study: problem, research, iterations, decision",
					"Facilitate a prioritization session with a rubric",
					"Pair with a dev on one component; document edge cases",
				],
				courseFocus: "Product discovery, UX writing, accessibility",
			},
			{
				title: "Portfolio & craft",
				window: "Months 7–12",
				summary: "Polish process artifacts and show judgment, not only screens.",
				skills: ["Critique", "Motion & micro-interactions", "Design QA"],
				milestones: [
					"Two end-to-end case studies with honest constraints",
					"Accessibility pass on primary flows",
					"Ship one improvement to a real or OSS product",
				],
				courseFocus: "Advanced prototyping, design ops, portfolio review",
			},
			{
				title: "Career launch",
				window: "Months 12+",
				summary: "Present yourself as a partner to product and engineering.",
				skills: ["Presentation", "Stakeholder workshops", "Negotiation basics"],
				milestones: [
					"Curate portfolio site with clear specialization",
					"Practice whiteboard and async critique exercises",
					"Apply with tailored cover angles per company mission",
				],
				courseFocus: "Interview presentations, leadership in design",
			},
		],
	},
	data: {
		title: "Data & analytics",
		tagline: "Move from questions to clean queries, trustworthy metrics, and decisions people act on.",
		phases: [
			{
				title: "Foundations",
				window: "Months 1–3",
				summary: "SQL muscle, spreadsheet discipline, and clear definitions.",
				skills: ["SQL joins & aggregates", "Data types & nulls", "Chart literacy"],
				milestones: [
					"Answer 10 business-style questions on a public dataset",
					"Document grain and definitions for one fact table",
					"Build one dashboard with a headline metric + caveats",
				],
				courseFocus: "SQL, spreadsheets, visualization basics",
			},
			{
				title: "Analysis workflow",
				window: "Months 4–8",
				summary: "Reproducible notebooks, quality checks, and stakeholder-ready narratives.",
				skills: ["Notebook hygiene", "Statistics intuition", "Storytelling with data"],
				milestones: [
					"Version a small analysis repo with README assumptions",
					"Present one analysis with limitations called out explicitly",
					"Automate a weekly KPI email or report",
				],
				courseFocus: "Python/R for analysis, statistics, BI tools",
			},
			{
				title: "Impact & tooling",
				window: "Months 7–14",
				summary: "Partner with teams on metrics definitions and experimentation literacy.",
				skills: ["Metric design", "Experiment basics", "dbt or ELT concepts"],
				milestones: [
					"Lead a metric definition workshop (even mock)",
					"Outline an A/B test with ethics and power caveats",
					"Shadow a data engineer for one pipeline handoff",
				],
				courseFocus: "Analytics engineering intro, experimentation, causal thinking",
			},
			{
				title: "Career launch",
				window: "Months 12+",
				summary: "Show how you drive decisions, not only charts.",
				skills: ["Executive summaries", "Stakeholder management", "Portfolio of memos"],
				milestones: [
					"Portfolio: 2 analyses with code or queries redacted as needed",
					"Practice live SQL or take-home with time limits",
					"Target analytics, BI, or data-science-adjacent roles intentionally",
				],
				courseFocus: "Case interviews, advanced SQL, domain depth",
			},
		],
	},
	product: {
		title: "Product & strategy",
		tagline: "Clarify problems, align teams, and ship outcomes through discovery and execution.",
		phases: [
			{
				title: "Foundations",
				window: "Months 1–3",
				summary: "User conversations, problem framing, and ruthless prioritization literacy.",
				skills: ["Interview scripts", "Opportunity sizing", "Roadmap literacy"],
				milestones: [
					"Run 8+ user conversations; synthesize themes",
					"Rewrite three feature ideas as outcome-based problems",
					"Shadow an engineering planning session and take notes",
				],
				courseFocus: "Product discovery, agile basics, analytics for PMs",
			},
			{
				title: "Execution",
				window: "Months 4–9",
				summary: "Specs, rollouts, and cross-functional rhythm.",
				skills: ["PRDs / one-pagers", "Rollout & comms", "Risk tradeoffs"],
				milestones: [
					"Ship one feature slice with acceptance criteria and metrics",
					"Run a retrospective that changes the next sprint",
					"Write a decision log for a prioritization call",
				],
				courseFocus: "Technical fluency for PMs, experiment design, stakeholder maps",
			},
			{
				title: "Leadership",
				window: "Months 8–16",
				summary: "Own a roadmap theme; connect strategy to quarterly bets.",
				skills: ["Vision narratives", "Stakeholder alignment", "Executive updates"],
				milestones: [
					"Present a quarterly review: shipped, learned, next bets",
					"Facilitate OKR or outcome planning (practice or real)",
					"Mentor a junior on writing crisp user stories",
				],
				courseFocus: "Strategy, pricing/market basics, leadership communication",
			},
			{
				title: "Career launch",
				window: "Months 14+",
				summary: "Show judgment under ambiguity and measurable impact.",
				skills: ["Case practice", "Portfolio of launches", "Reference network"],
				milestones: [
					"Document 3 launches with metrics and what you’d redo",
					"Mock PM interviews with metrics and tradeoff drills",
					"Target APM, PM, or associate PM paths with tailored stories",
				],
				courseFocus: "PM interviews, career narratives, domain expertise",
			},
		],
	},
	infra: {
		title: "Platform, cloud & security",
		tagline: "Automate delivery, harden systems, and make reliability a product for other engineers.",
		phases: [
			{
				title: "Foundations",
				window: "Months 1–3",
				summary: "Linux, networking vocabulary, and safe cloud habits.",
				skills: ["CLI comfort", "Networking basics", "IAM & secrets hygiene"],
				milestones: [
					"Deploy a static + API demo with HTTPS and env-based secrets",
					"Draw your stack with trust boundaries",
					"Complete a guided security or cloud fundamentals lab",
				],
				courseFocus: "Cloud practitioner, networking, Linux",
			},
			{
				title: "Automation & reliability",
				window: "Months 4–10",
				summary: "CI/CD, containers, and observable services.",
				skills: ["Docker", "CI pipelines", "Logs/metrics/traces intro"],
				milestones: [
					"Multi-stage Docker build for an app you own",
					"CI with tests; block merges on failure",
					"Define SLOs and error budget story for one service",
				],
				courseFocus: "Kubernetes intro, Terraform/IaC, observability",
			},
			{
				title: "Security & scale",
				window: "Months 9–18",
				summary: "Threat modeling, incident practice, and cost-aware architecture.",
				skills: ["Threat modeling", "Incident response", "Cost/perf tradeoffs"],
				milestones: [
					"Run STRIDE on an app; file three actionable fixes",
					"Participate in a tabletop or game day",
					"Rightsize one workload with data; document savings",
				],
				courseFocus: "Security engineering, SRE practices, architecture patterns",
			},
			{
				title: "Career launch",
				window: "Months 16+",
				summary: "Position as someone who reduces risk and toil for teams.",
				skills: ["Architecture interviews", "Writing ADRs", "Mentoring"],
				milestones: [
					"Publish 2 ADRs or architecture diagrams with tradeoffs",
					"Speak or blog on one reliability lesson learned",
					"Target platform, SRE, cloud, or security analyst/engineer roles",
				],
				courseFocus: "Certifications (optional), advanced architecture, leadership",
			},
		],
	},
	mobile: {
		title: "Mobile engineering & quality",
		tagline: "Ship polished apps with performance, accessibility, and release discipline.",
		phases: [
			{
				title: "Foundations",
				window: "Months 1–3",
				summary: "Platform UI toolkit, navigation, and local state done right.",
				skills: ["Layout systems", "State management", "Platform guidelines"],
				milestones: [
					"Two-screen app with persistence and navigation",
					"Explicit loading / empty / error UI on main flow",
					"Read HIG/Material and apply three concrete improvements",
				],
				courseFocus: "SwiftUI/UIKit or Kotlin/Compose or React Native",
			},
			{
				title: "Product-ready features",
				window: "Months 4–9",
				summary: "Networking, background work, and testable architecture.",
				skills: ["API integration", "Offline & sync patterns", "UI tests"],
				milestones: [
					"Cancel in-flight requests on navigation",
					"One automated UI test on critical path",
					"Beta via TestFlight or Play internal track",
				],
				courseFocus: "Mobile architecture, performance, push notifications",
			},
			{
				title: "Quality at scale",
				window: "Months 8–14",
				summary: "Stability, analytics, and release trains.",
				skills: ["Crash analytics", "Feature flags", "Release checklists"],
				milestones: [
					"Fix top crash or jank issue with measured before/after",
					"Document release checklist used twice",
					"Add accessibility audit pass to team or personal process",
				],
				courseFocus: "Test automation, DevOps for mobile, App Store policies",
			},
			{
				title: "Career launch",
				window: "Months 12+",
				summary: "Show apps people can install and a story for craft.",
				skills: ["Portfolio apps", "Performance storytelling", "Interview demos"],
				milestones: [
					"Polish one app store listing with honest screenshots",
					"Prepare live coding in platform idioms",
					"Target mobile, React Native, or cross-platform teams",
				],
				courseFocus: "Advanced patterns, interview prep, specialization",
			},
		],
	},
	default: {
		title: "Tech career (general)",
		tagline: "A balanced path when you are still exploring—build proof, then specialize.",
		phases: [
			{
				title: "Explore & build proof",
				window: "Months 1–4",
				summary: "Try two adjacent areas (e.g. code + design) with small time-boxed projects.",
				skills: ["Learning how you learn", "Basic tooling", "Shipping tiny MVPs"],
				milestones: [
					"Two 2-week experiments in different skills",
					"One public write-up of what you enjoyed and why",
					"Update Settings in EduPath with refined interests",
				],
				courseFocus: "Intro courses across CS, design, or data",
			},
			{
				title: "Choose a spine",
				window: "Months 4–10",
				summary: "Commit to one primary track for 6 months while keeping one side skill.",
				skills: ["Depth over breadth", "Feedback loops", "Community or cohort"],
				milestones: [
					"Pick a track using Guidance results and mentor/peers input",
					"Finish one substantial course or certification attempt",
					"Ship one portfolio artifact aligned to that track",
				],
				courseFocus: "Follow the roadmap for software, design, data, or product",
			},
			{
				title: "Credibility",
				window: "Months 8–16",
				summary: "Combine projects, optional certs, and clear narrative.",
				skills: ["Portfolio storytelling", "Interview behaviorals", "Networking"],
				milestones: [
					"Three documented projects with metrics or user quotes",
					"Practice weekly stories in STAR format",
					"Attend meetups or virtual communities in your target field",
				],
				courseFocus: "Interview skills, specialization electives",
			},
			{
				title: "Career launch",
				window: "Months 14+",
				summary: "Apply with focus; iterate using feedback.",
				skills: ["Targeted applications", "Referrals", "Offer evaluation"],
				milestones: [
					"Tailor resume per role family",
					"Schedule informational chats monthly",
					"Use EduPath Guidance refresh when APIs are available",
				],
				courseFocus: "Job search systems, negotiation, onboarding strong starts",
			},
		],
	},
};
