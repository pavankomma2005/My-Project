import React from "react";
import { Link } from "react-router-dom";
import {
	FaGraduationCap,
	FaFacebookF,
	FaTwitter,
	FaLinkedinIn,
	FaInstagram,
	FaEnvelope,
	FaPhone,
	FaMapMarkerAlt,
} from "react-icons/fa";
import "./Footer.css";

const Footer = () => {
	const currentYear = new Date().getFullYear();

	return (
		<footer className="footer">
			<div className="footer-main">
				<div className="container">
					<div className="footer-grid">
						{/* Brand Section */}
						<div className="footer-section">
							<Link to="/" className="footer-logo">
								<div className="footer-logo-icon">
									<FaGraduationCap />
								</div>
								<span className="footer-logo-text">
									<span className="logo-main">EduPath</span>
									<span className="logo-accent">AI</span>
								</span>
							</Link>
							<p className="footer-description">
								Your personalized AI-powered career and
								education advisor. Empowering students and
								professionals to make informed decisions about
								their future.
							</p>
							<div className="footer-social">
								<a
									href="#"
									className="social-link"
									aria-label="Facebook"
								>
									<FaFacebookF />
								</a>
								<a
									href="#"
									className="social-link"
									aria-label="Twitter"
								>
									<FaTwitter />
								</a>
								<a
									href="#"
									className="social-link"
									aria-label="LinkedIn"
								>
									<FaLinkedinIn />
								</a>
								<a
									href="#"
									className="social-link"
									aria-label="Instagram"
								>
									<FaInstagram />
								</a>
							</div>
						</div>

						{/* Quick Links */}
						<div className="footer-section">
							<h4 className="footer-title">Quick Links</h4>
							<ul className="footer-links">
								<li>
									<Link to="/">Home</Link>
								</li>
								<li>
									<Link to="/features">Features</Link>
								</li>
								<li>
									<Link to="/contact">Contact Us</Link>
								</li>
								<li>
									<Link to="/signup">Get Started</Link>
								</li>
							</ul>
						</div>

						{/* Resources */}
						<div className="footer-section">
							<h4 className="footer-title">Resources</h4>
							<ul className="footer-links">
								<li>
									<a href="#">Career Paths</a>
								</li>
								<li>
									<a href="#">Course Library</a>
								</li>
								<li>
									<a href="#">Skill Assessment</a>
								</li>
								<li>
									<a href="#">Blog</a>
								</li>
							</ul>
						</div>

						{/* Contact Info */}
						<div className="footer-section">
							<h4 className="footer-title">Contact Us</h4>
							<ul className="footer-contact">
								<li>
									<FaMapMarkerAlt />
									<span>
										Lovely Professional University (LPU),
										NH-1, Jalandhar-Delhi G.T. Road,
										Phagwara, Punjab 144411, India
									</span>
								</li>
								<li>
									<FaPhone />
									<span>+1 (555) 123-4567</span>
								</li>
								<li>
									<FaEnvelope />
									<span>info@edupathai.com</span>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>

			{/* Footer Bottom */}
			<div className="footer-bottom">
				<div className="container">
					<div className="footer-bottom-content">
						<p className="footer-copyright">
							&copy; {currentYear} EduPath AI. All rights
							reserved.
						</p>
						<div className="footer-legal">
							<a href="#">Privacy Policy</a>
							<span className="separator">•</span>
							<a href="#">Terms of Service</a>
							<span className="separator">•</span>
							<a href="#">Cookie Policy</a>
						</div>
					</div>
				</div>
			</div>
		</footer>
	);
};

export default Footer;
