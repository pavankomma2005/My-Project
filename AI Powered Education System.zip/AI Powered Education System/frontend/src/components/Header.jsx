import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { FaBars, FaTimes, FaGraduationCap, FaUser } from "react-icons/fa";
import { useAuth } from "../context/AuthContext";
import "./Header.css";

const Header = () => {
	const [isMenuOpen, setIsMenuOpen] = useState(false);
	const [isScrolled, setIsScrolled] = useState(false);
	const location = useLocation();
	const navigate = useNavigate();
	const { user, logout } = useAuth();

	useEffect(() => {
		const handleScroll = () => {
			setIsScrolled(window.scrollY > 20);
		};

		window.addEventListener("scroll", handleScroll);
		return () => window.removeEventListener("scroll", handleScroll);
	}, []);

	useEffect(() => {
		setIsMenuOpen(false);
	}, [location]);

	const toggleMenu = () => {
		setIsMenuOpen(!isMenuOpen);
	};

	const isActive = (path) => location.pathname === path;

	return (
		<header className={`header ${isScrolled ? "header-scrolled" : ""}`}>
			<div className="container">
				<nav className="nav">
					<Link to="/" className="logo">
						<div className="logo-icon">
							<FaGraduationCap />
						</div>
						<span className="logo-text">
							<span className="logo-main">EduPath</span>
							<span className="logo-accent">AI</span>
						</span>
					</Link>

					<ul
						className={`nav-menu ${
							isMenuOpen ? "nav-menu-active" : ""
						}`}
					>
						<li className="nav-item">
							<Link
								to="/"
								className={`nav-link ${
									isActive("/") ? "nav-link-active" : ""
								}`}
							>
								Home
							</Link>
						</li>
						<li className="nav-item">
							<Link
								to="/features"
								className={`nav-link ${
									isActive("/features")
										? "nav-link-active"
										: ""
								}`}
							>
								Features
							</Link>
						</li>
						<li className="nav-item">
							<Link
								to="/contact"
								className={`nav-link ${
									isActive("/contact")
										? "nav-link-active"
										: ""
								}`}
							>
								Contact
							</Link>
						</li>
						{user ? (
							<>
								<li className="nav-item nav-item-mobile">
									<Link to="/dashboard" className="nav-link">
										Dashboard
									</Link>
								</li>
								<li className="nav-item nav-item-mobile">
									<button
										type="button"
										className="btn btn-secondary btn-sm"
										onClick={() => { logout(); navigate("/"); }}
									>
										Log out
									</button>
								</li>
							</>
						) : (
							<>
								<li className="nav-item nav-item-mobile">
									<Link to="/login" className="btn btn-secondary btn-sm">Login</Link>
								</li>
								<li className="nav-item nav-item-mobile">
									<Link to="/signup" className="btn btn-primary btn-sm">Sign Up</Link>
								</li>
							</>
						)}
					</ul>

					<div className="nav-actions">
						{user ? (
							<>
								<Link to="/dashboard" className="btn btn-primary btn-sm nav-btn">
									<FaUser />
									Dashboard
								</Link>
								<button
									type="button"
									className="btn btn-secondary btn-sm nav-btn"
									onClick={() => { logout(); navigate("/"); }}
								>
									Log out
								</button>
							</>
						) : (
							<>
								<Link to="/login" className="btn btn-secondary btn-sm nav-btn">
									<FaUser />
									Login
								</Link>
								<Link to="/signup" className="btn btn-primary btn-sm nav-btn">
									Get Started
								</Link>
							</>
						)}
					</div>

					<button
						className="nav-toggle"
						onClick={toggleMenu}
						aria-label="Toggle menu"
					>
						{isMenuOpen ? <FaTimes /> : <FaBars />}
					</button>
				</nav>
			</div>
		</header>
	);
};

export default Header;
