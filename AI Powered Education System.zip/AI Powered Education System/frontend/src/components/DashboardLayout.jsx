import React, { useState } from "react";
import { NavLink, useNavigate, Outlet } from "react-router-dom";
import {
	FaGraduationCap,
	FaHome,
	FaCompass,
	FaRocket,
	FaBrain,
	FaBook,
	FaCog,
	FaSignOutAlt,
	FaBars,
	FaTimes,
	FaUserCircle,
	FaChevronDown,
} from "react-icons/fa";
import { useAuth } from "../context/AuthContext";
import "./DashboardLayout.css";

const navSections = [
	{
		title: null,
		items: [{ path: "/dashboard", label: "Overview", icon: FaHome, end: true }],
	},
	{
		title: "Everything you need",
		items: [
			{ path: "/dashboard/guidance", label: "Guidance", icon: FaCompass },
			{ path: "/dashboard/roadmap", label: "Roadmap", icon: FaRocket },
			{ path: "/dashboard/education", label: "Education paths", icon: FaGraduationCap },
			{ path: "/dashboard/skills", label: "Skill mapping", icon: FaBrain },
			{ path: "/dashboard/courses", label: "Expert courses", icon: FaBook },
		],
	},
	{
		title: "Account",
		items: [{ path: "/dashboard/settings", label: "Settings", icon: FaCog }],
	},
];

const DashboardLayout = ({ children }) => {
	const { user, logout } = useAuth();
	const navigate = useNavigate();
	const [sidebarOpen, setSidebarOpen] = useState(false);
	const [userMenuOpen, setUserMenuOpen] = useState(false);

	const handleLogout = () => {
		logout();
		navigate("/");
		setUserMenuOpen(false);
	};

	return (
		<div className="dashboard-layout">
			<aside className={`dashboard-sidebar ${sidebarOpen ? "sidebar-open" : ""}`}>
				<div className="sidebar-header">
					<NavLink to="/dashboard" className="sidebar-brand" onClick={() => setSidebarOpen(false)}>
						<div className="sidebar-brand-icon">
							<FaGraduationCap />
						</div>
						<span className="sidebar-brand-text">EduPath AI</span>
					</NavLink>
					<button
						className="sidebar-close"
						onClick={() => setSidebarOpen(false)}
						aria-label="Close menu"
					>
						<FaTimes />
					</button>
				</div>
				<nav className="sidebar-nav">
					{navSections.map((section, sIdx) => (
						<div key={sIdx} className="sidebar-nav-section">
							{section.title && (
								<div className="sidebar-nav-title" role="presentation">
									{section.title}
								</div>
							)}
							{section.items.map(({ path, label, icon: Icon, end }) => (
								<NavLink
									key={path}
									to={path}
									end={end}
									className={({ isActive }) =>
										`sidebar-link ${isActive ? "active" : ""}`
									}
									onClick={() => setSidebarOpen(false)}
								>
									<Icon className="sidebar-link-icon" />
									<span>{label}</span>
								</NavLink>
							))}
						</div>
					))}
				</nav>
				<div className="sidebar-footer">
					<div className="sidebar-user">
						{user?.avatar ? (
							<img src={user.avatar} alt="" className="sidebar-avatar" />
						) : (
							<FaUserCircle className="sidebar-avatar-placeholder" />
						)}
						<span className="sidebar-user-name">{user?.fullName || user?.email}</span>
					</div>
				</div>
			</aside>

			<div className="dashboard-main">
				<header className="dashboard-header">
					<button
						className="dashboard-menu-btn"
						onClick={() => setSidebarOpen(true)}
						aria-label="Open menu"
					>
						<FaBars />
					</button>
					<div className="dashboard-header-right">
						<div className="dashboard-user-menu-wrapper">
							<button
								className="dashboard-user-trigger"
								onClick={() => setUserMenuOpen(!userMenuOpen)}
								aria-expanded={userMenuOpen}
								aria-haspopup="true"
							>
								{user?.avatar ? (
									<img src={user.avatar} alt="" className="header-avatar" />
								) : (
									<div className="header-avatar-placeholder">
										<FaUserCircle />
									</div>
								)}
								<span className="header-user-name">{user?.fullName || "Account"}</span>
								<FaChevronDown className={`header-chevron ${userMenuOpen ? "open" : ""}`} />
							</button>
							{userMenuOpen && (
								<>
									<div
										className="dashboard-user-menu-backdrop"
										onClick={() => setUserMenuOpen(false)}
										aria-hidden="true"
									/>
									<div className="dashboard-user-menu" role="menu">
										<div className="user-menu-info">
											<span className="user-menu-name">{user?.fullName}</span>
											<span className="user-menu-email">{user?.email}</span>
										</div>
										<NavLink
											to="/dashboard/settings"
											className="user-menu-item"
											onClick={() => setUserMenuOpen(false)}
											role="menuitem"
										>
											<FaCog />
											Settings
										</NavLink>
										<button
											type="button"
											className="user-menu-item user-menu-logout"
											onClick={handleLogout}
											role="menuitem"
										>
											<FaSignOutAlt />
											Log out
										</button>
									</div>
								</>
							)}
						</div>
					</div>
				</header>
				<main className="dashboard-content">{children ?? <Outlet />}</main>
			</div>
		</div>
	);
};

export default DashboardLayout;
