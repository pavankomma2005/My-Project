import React, { createContext, useContext, useState, useEffect } from 'react';
import { api, getToken } from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchUser = async () => {
    const token = getToken();
    if (!token) {
      setUser(null);
      setLoading(false);
      return;
    }
    try {
      const { user: u } = await api('/api/auth/me');
      setUser(u);
    } catch {
      localStorage.removeItem('token');
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const token = params.get('token');
    if (token) {
      localStorage.setItem('token', token);
      window.history.replaceState({}, '', window.location.pathname);
    }
    fetchUser();
  }, []);

  const login = async (email, password) => {
    const { user: u, token } = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    localStorage.setItem('token', token);
    setUser(u);
    return u;
  };

  const register = async (fullName, email, password) => {
    const { user: u, token } = await api('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ fullName, email, password }),
    });
    localStorage.setItem('token', token);
    setUser(u);
    return u;
  };

  const loginWithGoogle = () => {
    const base = import.meta.env.VITE_API_URL || 'http://localhost:5000';
    window.location.href = `${base}/api/auth/google`;
  };

  const logout = async () => {
    try {
      await api('/api/auth/logout', { method: 'POST' });
    } catch (_) {}
    localStorage.removeItem('token');
    setUser(null);
  };

  const updateProfile = async (payload) => {
    const { user: u } = await api('/api/auth/profile', {
      method: 'PATCH',
      body: payload,
    });
    setUser(u);
    // Profile changes should immediately re-tune the app.
    // Clear session-only caches so Guidance / Roadmap / Education / Skills recompute from latest profile.
    try {
      sessionStorage.removeItem('edupath_guidance_bundle');
      sessionStorage.removeItem('edupath_guidance_recs');
      sessionStorage.removeItem('edupath_guidance_curated');
      sessionStorage.removeItem('edupath_custom_skills');
    } catch (_) {}
    return u;
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, loginWithGoogle, logout, refreshUser: fetchUser, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
