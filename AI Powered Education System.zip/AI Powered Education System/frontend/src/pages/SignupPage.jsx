import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
	FaUser,
	FaEnvelope,
	FaLock,
	FaEye,
	FaEyeSlash,
	FaCheckCircle,
} from "react-icons/fa";
import { useAuth } from "../context/AuthContext";
import "./AuthPages.css";

const SignupPage = () => {
	const { register, loginWithGoogle } = useAuth();
	const navigate = useNavigate();
	const [formData, setFormData] = useState({
		fullName: "",
		email: "",
		password: "",
		confirmPassword: "",
	});
	const [showPassword, setShowPassword] = useState(false);
	const [showConfirmPassword, setShowConfirmPassword] = useState(false);
	const [agreeToTerms, setAgreeToTerms] = useState(false);
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(false);

	const handleChange = (e) => {
		setFormData({ ...formData, [e.target.name]: e.target.value });
		setError("");
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		if (formData.password !== formData.confirmPassword) {
			setError("Passwords do not match");
			return;
		}
		setError("");
		setLoading(true);
		try {
			await register(formData.fullName, formData.email, formData.password);
			navigate("/dashboard");
		} catch (err) {
			setError(err.message || err.errors?.[0]?.msg || "Registration failed");
		} finally {
			setLoading(false);
		}
	};

	const handleGoogleSignup = () => {
		loginWithGoogle();
	};

	const benefits = [
		"Personalized career recommendations",
		"Access to 500+ expert courses",
		"AI-powered learning assistant",
		"Profile-based personalization",
		"Job & internship matching",
	];

	return (
		<div className="auth-page">
			<div className="auth-container">
				<div className="auth-grid auth-grid-reverse">
					<div className="auth-visual-section">
						<div className="auth-visual-content">
							<div className="visual-icon fade-in">🚀</div>
							<h2 className="visual-title fade-in">Join EduPath AI Today</h2>
							<p className="visual-description fade-in">
								Create your free account and unlock your potential with personalized career guidance.
							</p>
							<div className="benefits-list fade-in">
								{benefits.map((benefit, index) => (
									<div key={index} className="benefit-item">
										<FaCheckCircle />
										<span>{benefit}</span>
									</div>
								))}
							</div>
						</div>
					</div>

					<div className="auth-form-section">
						<div className="auth-form-wrapper">
							<div className="auth-header">
								<h1 className="auth-title fade-in">Create Your Account</h1>
								<p className="auth-subtitle fade-in">Start your journey to career success</p>
							</div>

							<div className="social-login fade-in">
								<button
									type="button"
									className="social-btn"
									onClick={handleGoogleSignup}
									disabled={loading}
								>
									<svg width="20" height="20" viewBox="0 0 24 24">
										<path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
										<path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
										<path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
										<path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
									</svg>
									<span>Sign up with Google</span>
								</button>
							</div>

							<div className="divider fade-in">
								<span>Or sign up with email</span>
							</div>

							{error && (
								<div className="auth-error fade-in" role="alert">
									{error}
								</div>
							)}

							<form className="auth-form fade-in" onSubmit={handleSubmit}>
								<div className="form-group">
									<label htmlFor="fullName" className="form-label">Full Name</label>
									<div className="input-with-icon">
										<FaUser className="input-icon" />
										<input
											type="text"
											id="fullName"
											name="fullName"
											className="form-input"
											placeholder="John Doe"
											value={formData.fullName}
											onChange={handleChange}
											required
										/>
									</div>
								</div>

								<div className="form-group">
									<label htmlFor="email" className="form-label">Email Address</label>
									<div className="input-with-icon">
										<FaEnvelope className="input-icon" />
										<input
											type="email"
											id="email"
											name="email"
											className="form-input"
											placeholder="you@example.com"
											value={formData.email}
											onChange={handleChange}
											required
										/>
									</div>
								</div>

								<div className="form-group">
									<label htmlFor="password" className="form-label">Password</label>
									<div className="input-with-icon">
										<FaLock className="input-icon" />
										<input
											type={showPassword ? "text" : "password"}
											id="password"
											name="password"
											className="form-input"
											placeholder="Create a strong password (min 8 characters)"
											value={formData.password}
											onChange={handleChange}
											required
											minLength={8}
										/>
										<button
											type="button"
											className="password-toggle"
											onClick={() => setShowPassword(!showPassword)}
											aria-label="Toggle password visibility"
										>
											{showPassword ? <FaEyeSlash /> : <FaEye />}
										</button>
									</div>
								</div>

								<div className="form-group">
									<label htmlFor="confirmPassword" className="form-label">Confirm Password</label>
									<div className="input-with-icon">
										<FaLock className="input-icon" />
										<input
											type={showConfirmPassword ? "text" : "password"}
											id="confirmPassword"
											name="confirmPassword"
											className="form-input"
											placeholder="Confirm your password"
											value={formData.confirmPassword}
											onChange={handleChange}
											required
										/>
										<button
											type="button"
											className="password-toggle"
											onClick={() => setShowConfirmPassword(!showConfirmPassword)}
											aria-label="Toggle password visibility"
										>
											{showConfirmPassword ? <FaEyeSlash /> : <FaEye />}
										</button>
									</div>
								</div>

								<div className="form-options">
									<label className="checkbox-label">
										<input
											type="checkbox"
											checked={agreeToTerms}
											onChange={(e) => setAgreeToTerms(e.target.checked)}
											required
										/>
										<span>
											I agree to the <a href="#" className="inline-link">Terms of Service</a> and <a href="#" className="inline-link">Privacy Policy</a>
										</span>
									</label>
								</div>

								<button
									type="submit"
									className="btn btn-primary btn-lg auth-submit"
									disabled={loading}
								>
									{loading ? "Creating account…" : "Create Account"}
								</button>
							</form>

							<p className="auth-footer-text fade-in">
								Already have an account? <Link to="/login" className="auth-link">Log in</Link>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

export default SignupPage;
