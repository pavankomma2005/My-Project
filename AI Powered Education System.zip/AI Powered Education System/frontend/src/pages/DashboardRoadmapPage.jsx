import React, { useMemo } from "react";
import { Link } from "react-router-dom";
import { FaRocket, FaCompass, FaBook, FaCog, FaCheckCircle } from "react-icons/fa";
import { useAuth } from "../context/AuthContext";
import { ROADMAPS_BY_TRACK } from "../data/careerRoadmapsData";
import {
	buildLearningPlanContext,
	planContextLabel,
	resolveLearningTrack,
} from "../lib/learningPlan";
import "./DashboardPage.css";
import "./DashboardFeaturePages.css";

const DashboardRoadmapPage = () => {
	const { user } = useAuth();
	const ctx = useMemo(() => buildLearningPlanContext(user), [user]);
	const trackId = useMemo(() => resolveLearningTrack(ctx), [ctx]);
	const roadmap = ROADMAPS_BY_TRACK[trackId] || ROADMAPS_BY_TRACK.default;
	const contextLabel = planContextLabel(ctx, trackId);

	return (
		<div className="dashboard-page roadmap-page">
			<div className="feature-page-intro">
				<h1>
					<FaRocket style={{ marginRight: "0.5rem", opacity: 0.85, verticalAlign: "-0.1em" }} />
					Career Roadmap
				</h1>
				<p className="lead">
					Phases, skills, milestones, and course focus areas aligned to your profile and latest
					guidance. Update{" "}
					<Link to="/dashboard/settings" className="dashboard-card-link" style={{ display: "inline" }}>
						Settings
					</Link>{" "}
					or refresh{" "}
					<Link to="/dashboard/guidance" className="dashboard-card-link" style={{ display: "inline" }}>
						Personalized Guidance
					</Link>{" "}
					to re-tune this plan.
				</p>
			</div>

			<div className="roadmap-context-bar">
				<div className="roadmap-context-pill">
					<FaCompass aria-hidden />
					<span>
						<strong>Aligned with:</strong> {contextLabel}
					</span>
				</div>
				<span className="roadmap-context-track">Track: {roadmap.title}</span>
			</div>

			<div className="feature-panel roadmap-hero-panel">
				<p className="roadmap-tagline">{roadmap.tagline}</p>
				<div className="roadmap-actions">
					<Link to="/dashboard/guidance" className="btn btn-primary">
						<FaCompass style={{ marginRight: "0.4rem" }} />
						View guidance
					</Link>
					<Link to="/dashboard/courses" className="btn btn-secondary">
						<FaBook style={{ marginRight: "0.4rem" }} />
						Expert courses
					</Link>
					<Link to="/dashboard/education" className="btn btn-secondary">
						Education paths
					</Link>
					<Link to="/dashboard/settings" className="roadmap-link-quiet">
						<FaCog style={{ marginRight: "0.35rem" }} />
						Edit profile
					</Link>
				</div>
			</div>

			<h2 className="feature-section-title" style={{ marginTop: "2rem" }}>
				Your journey
			</h2>
			<div className="feature-panel roadmap-timeline-panel">
				<div className="roadmap-timeline">
					{roadmap.phases.map((phase) => (
						<div key={phase.title} className="roadmap-step">
							<div className="roadmap-step-dot" aria-hidden />
							<div className="roadmap-step-title">{phase.title}</div>
							<div className="roadmap-step-meta">{phase.window}</div>
							{phase.summary && <p className="roadmap-phase-summary">{phase.summary}</p>}
							{phase.skills?.length > 0 && (
								<div className="roadmap-skills-row">
									{phase.skills.map((s) => (
										<span key={s} className="roadmap-skill-chip">
											{s}
										</span>
									))}
								</div>
							)}
							{phase.milestones?.length > 0 && (
								<ul className="roadmap-milestone-list">
									{phase.milestones.map((m) => (
										<li key={m}>
											<FaCheckCircle className="roadmap-milestone-icon" aria-hidden />
											{m}
										</li>
									))}
								</ul>
							)}
							{phase.courseFocus && (
								<p className="roadmap-course-focus">
									<strong>Course focus:</strong> {phase.courseFocus}
								</p>
							)}
						</div>
					))}
				</div>
			</div>
		</div>
	);
};

export default DashboardRoadmapPage;
