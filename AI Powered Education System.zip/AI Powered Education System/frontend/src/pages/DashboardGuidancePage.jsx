import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
	FaCompass,
	FaCheckCircle,
	FaStar,
	FaRedo,
	FaRobot,
	FaArrowRight,
} from "react-icons/fa";
import { useAuth } from "../context/AuthContext";
import { api } from "../api/client";
import {
	CURATED_HOME_LIST_LIMIT,
	STATIC_GUIDANCE_RECOMMENDATIONS,
} from "../data/staticGuidanceRecommendations";
import {
	clearGuidanceBundle,
	saveGuidanceBundle,
	saveGuidanceRecommendations,
} from "../lib/guidanceStorage";
import "./DashboardPage.css";
import "./DashboardFeaturePages.css";
import "./DashboardGuidancePage.css";

const LEARNING_LABELS = {
	video: "Video",
	reading: "Reading",
	"hands-on": "Hands-on",
	projects: "Projects",
	"live-sessions": "Live sessions",
};

const LEVEL_LABELS = {
	beginner: "Beginner",
	intermediate: "Intermediate",
	advanced: "Advanced",
};

const FALLBACK_SIGNALS = [
	{ label: "Interests", value: "Technology, design, problem-solving" },
	{ label: "Academic focus", value: "STEM / Computer Science pathway" },
	{ label: "Skills noted", value: "Communication, analytical thinking, coding basics" },
];

function buildProfileSignals(user) {
	const p = user?.preferences;
	if (!p) return { rows: FALLBACK_SIGNALS, usingProfile: false };

	const tech = (p.techInterests || []).filter(Boolean);
	const career = (p.careerFocus || "").trim();
	const goals = (p.learningGoals || "").trim();
	const bio = (p.bio || "").trim();
	const level = p.experienceLevel || "beginner";
	const styles = (p.learningStyles || []).map((id) => LEARNING_LABELS[id]).filter(Boolean);

	const rows = [];

	if (tech.length) {
		rows.push({ label: "Tech & topics", value: tech.join(", ") });
	} else {
		rows.push({ label: "Interests", value: FALLBACK_SIGNALS[0].value });
	}

	if (bio) {
		const short = bio.length > 220 ? `${bio.slice(0, 217)}…` : bio;
		rows.push({ label: "Bio", value: short });
	}

	if (career) {
		rows.push({ label: "Career focus", value: career });
	} else if (goals) {
		const short = goals.length > 140 ? `${goals.slice(0, 137)}…` : goals;
		rows.push({ label: "Learning goals", value: short });
	} else {
		rows.push({ label: "Academic focus", value: FALLBACK_SIGNALS[1].value });
	}

	const parts = [];
	if (styles.length) parts.push(`Formats: ${styles.join(", ")}`);
	parts.push(`Experience: ${LEVEL_LABELS[level] || level}`);
	rows.push({
		label: "Learning profile",
		value: parts.join(" · "),
	});

	const usingProfile =
		tech.length > 0 ||
		!!career ||
		!!goals ||
		!!bio ||
		styles.length > 0 ||
		level !== "beginner";

	return { rows, usingProfile };
}

function matchPillClass(match) {
	const m = String(match || "").toLowerCase();
	if (m.includes("strong")) return "guidance-match-pill guidance-match--strong";
	if (m.includes("good")) return "guidance-match-pill guidance-match--good";
	return "guidance-match-pill guidance-match--explore";
}

const DashboardGuidancePage = () => {
	const { user } = useAuth();
	const navigate = useNavigate();
	const { rows, usingProfile } = useMemo(() => buildProfileSignals(user), [user]);

	const [loading, setLoading] = useState(true);
	const [error, setError] = useState("");
	const [ai, setAi] = useState(null);
	const [provider, setProvider] = useState(null);
	const [fallbackFrom, setFallbackFrom] = useState(null);
	const [configured, setConfigured] = useState(true);

	const loadGuidance = useCallback(async (force = false) => {
		setLoading(true);
		setError("");
		try {
			const data = await api("/api/guidance/generate", { method: "POST", body: { force: !!force } });
			if (data?.success === false) {
				throw new Error(data.message || "Could not generate guidance");
			}
			setConfigured(data.configured !== false);
			setProvider(data.provider || null);
			setFallbackFrom(data.fallbackFrom || null);

			if (data.configured === false) {
				setAi(null);
				clearGuidanceBundle();
				return;
			}

			const guidance = data.guidance;
			const hasValidRecs =
				guidance &&
				Array.isArray(guidance.recommendations) &&
				guidance.recommendations.length >= 3;

			if (!hasValidRecs) {
				setAi(null);
				setError(
					data.message ||
						"AI returned incomplete guidance. Showing expert-curated paths below."
				);
				clearGuidanceBundle();
				return;
			}

			setAi(guidance);
			if (Array.isArray(data.recommendationDetails) && data.recommendationDetails.length > 0) {
				saveGuidanceBundle({
					guidance,
					recommendationDetails: data.recommendationDetails,
					provider: data.provider || null,
					fallbackFrom: data.fallbackFrom || null,
				});
			}
		} catch (e) {
			setError(e.message || "Could not load AI guidance");
			setAi(null);
			setProvider(null);
			setFallbackFrom(null);
			clearGuidanceBundle();
		} finally {
			setLoading(false);
		}
	}, []);

	useEffect(() => {
		loadGuidance(false);
	}, [loadGuidance]);

	const recommendations = useMemo(() => {
		if (ai?.recommendations?.length >= 3) {
			return ai.recommendations.map((r) => ({
				title: r.title,
				match: r.match || "Explore",
				summary: r.summary || "",
				nextSteps: Array.isArray(r.nextSteps) ? r.nextSteps : [],
			}));
		}
		return STATIC_GUIDANCE_RECOMMENDATIONS.slice(0, CURATED_HOME_LIST_LIMIT);
	}, [ai]);

	useEffect(() => {
		const fromAi = ai?.recommendations?.length >= 3;
		saveGuidanceRecommendations(recommendations, { curatedFallback: !fromAi });
	}, [recommendations, ai]);

	const showAiNotice = !loading && !error && configured === false;

	const openRecommendation = (index) => {
		navigate(`/dashboard/guidance/recommendation/${index}`);
	};

	return (
		<div className="dashboard-page guidance-page">
			<header className="guidance-hero">
				<div className="guidance-hero-inner">
					<h1 className="guidance-hero-title">
						<FaCompass aria-hidden />
						<span>
							<span className="guidance-hero-accent">Personalized</span> Guidance
						</span>
					</h1>
					<p className="guidance-hero-lead">
						AI reads your full profile—tech tags, bio, career focus, goals, experience level, and
						preferred learning formats—to suggest directions. Refine anytime in{" "}
						<Link to="/dashboard/settings" className="dashboard-card-link" style={{ display: "inline" }}>
							Settings
						</Link>{" "}
						and refresh for new output.
					</p>
					<div className="guidance-hero-actions">
						<button
							type="button"
							className="btn btn-primary"
							onClick={() => loadGuidance(true)}
							disabled={loading}
							style={{ fontSize: "0.9rem" }}
						>
							<FaRedo style={{ marginRight: "0.45rem" }} />
							{loading ? "Refreshing…" : "Refresh guidance"}
						</button>
						<Link to="/dashboard/courses" className="btn btn-secondary" style={{ fontSize: "0.9rem" }}>
							Browse courses
						</Link>
						{provider && (
							<span className="guidance-provider-pill">
								<FaRobot aria-hidden />
								{provider === "gemini" && "Google Gemini"}
								{provider === "groq" &&
									(fallbackFrom === "gemini" ? "Groq (fallback)" : "Groq")}
							</span>
						)}
					</div>
				</div>
			</header>

			{showAiNotice && (
				<div className="guidance-alert guidance-alert--warn">
					<p>
						Live AI isn&apos;t configured (add <code>GEMINI_API_KEY</code> and/or{" "}
						<code>GROQ_API_KEY</code> to backend <code>.env</code>). Below are the top{" "}
						{CURATED_HOME_LIST_LIMIT} expert-curated paths—each opens a full detail page with timelines,
						skills, and actions.
					</p>
				</div>
			)}

			{error && (
				<div className="guidance-alert guidance-alert--err">
					<p>{error}</p>
					<p>
						Below are the top {CURATED_HOME_LIST_LIMIT} expert-curated paths with full detail pages. When
						live AI works again, use <strong>Refresh guidance</strong> for a profile-tuned plan.
					</p>
				</div>
			)}

			<div className="guidance-section-head">
				<h2 className="guidance-section-title">Your profile</h2>
				<p className="guidance-section-hint">
					Signed in as <strong>{user?.fullName || user?.email || "Student"}</strong>
					{usingProfile ? "" : " — add more in Settings for richer AI output"}
				</p>
			</div>
			<div className="guidance-profile-grid">
				{rows.map((row) => (
					<div key={row.label} className="guidance-profile-card">
						<p className="guidance-profile-card-label">{row.label}</p>
						<p className="guidance-profile-card-value">{row.value}</p>
					</div>
				))}
			</div>

			{ai?.profileHighlights?.length > 0 && (
				<>
					<div className="guidance-section-head">
						<h2 className="guidance-section-title">AI insights</h2>
					</div>
					<div className="guidance-insights-panel">
						<ul className="guidance-insights-list">
							{ai.profileHighlights.map((line, i) => (
								<li key={i}>
									<FaStar className="guidance-insights-icon" aria-hidden />
									<span>{line}</span>
								</li>
							))}
						</ul>
						{ai.shortAdvice && <p className="guidance-advice">{ai.shortAdvice}</p>}
					</div>
				</>
			)}

			<div className="guidance-section-head">
				<h2 className="guidance-section-title">Recommended directions</h2>
				<p className="guidance-section-hint">
					Click a card—including <strong>Explore match</strong>—for the full plan on a dedicated page.
				</p>
			</div>
			{loading && !ai && (
				<p style={{ color: "var(--text-secondary)", fontSize: "0.9375rem", marginBottom: "1rem" }}>
					Generating personalized guidance…
				</p>
			)}
			<div className="guidance-rec-grid">
				{recommendations.map((item, index) => (
					<button
						key={`${index}-${item.title}`}
						type="button"
						className="guidance-rec-card"
						onClick={() => openRecommendation(index)}
					>
						<div className="guidance-rec-card-header">
							<h3 className="guidance-rec-card-title">{item.title}</h3>
							<span className={matchPillClass(item.match)}>{item.match} match</span>
						</div>
						<p className="guidance-rec-summary">{item.summary}</p>
						{item.nextSteps?.length > 0 && (
							<ul className="guidance-rec-preview-steps">
								{item.nextSteps.slice(0, 3).map((step, idx) => (
									<li key={idx}>{step}</li>
								))}
								{item.nextSteps.length > 3 && <li>…</li>}
							</ul>
						)}
						<div className="guidance-rec-footer">
							<span className="guidance-rec-meta">
								<FaStar style={{ opacity: 0.65 }} aria-hidden />
								{ai?.recommendations?.length >= 3 ? "AI · your profile" : "Curated path"}
							</span>
							<span className="guidance-rec-cta">
								Open full page
								<FaArrowRight aria-hidden />
							</span>
						</div>
					</button>
				))}
			</div>
		</div>
	);
};

export default DashboardGuidancePage;
