import React, { useEffect, useState } from "react";
import { FaSave } from "react-icons/fa";
import { useAuth } from "../context/AuthContext";
import "./DashboardPage.css";
import "./DashboardSettingsPage.css";

const LEARNING_STYLES = [
	{ id: "video", label: "Video lessons" },
	{ id: "reading", label: "Reading & articles" },
	{ id: "hands-on", label: "Hands-on labs" },
	{ id: "projects", label: "Project-based" },
	{ id: "live-sessions", label: "Live sessions" },
];

const EXPERIENCE_OPTIONS = [
	{ value: "beginner", label: "Beginner" },
	{ value: "intermediate", label: "Intermediate" },
	{ value: "advanced", label: "Advanced" },
];

const SUGGESTED_TECH = [
	"JavaScript",
	"TypeScript",
	"React",
	"Node.js",
	"Python",
	"Java",
	"C++",
	"Rust",
	"Go",
	"SQL",
	"Machine learning",
	"Data science",
	"Cloud / AWS",
	"DevOps",
	"Cybersecurity",
	"Web design",
	"Mobile development",
];

const defaultPrefs = () => ({
	techInterests: [],
	bio: "",
	learningGoals: "",
	experienceLevel: "beginner",
	learningStyles: [],
	careerFocus: "",
});

const DashboardSettingsPage = () => {
	const { user, updateProfile } = useAuth();
	const [fullName, setFullName] = useState("");
	const [prefs, setPrefs] = useState(defaultPrefs);
	const [techDraft, setTechDraft] = useState("");
	const [saving, setSaving] = useState(false);
	const [message, setMessage] = useState({ type: "", text: "" });

	useEffect(() => {
		if (!user) return;
		setFullName(user.fullName || "");
		setPrefs({ ...defaultPrefs(), ...(user.preferences || {}) });
	}, [user]);

	const addTechTag = (raw) => {
		const t = String(raw).trim();
		if (!t || t.length > 48) return;
		setPrefs((p) => {
			const next = t.slice(0, 48);
			if (p.techInterests.includes(next)) return p;
			if (p.techInterests.length >= 40) return p;
			return { ...p, techInterests: [...p.techInterests, next] };
		});
		setTechDraft("");
	};

	const removeTechTag = (tag) => {
		setPrefs((p) => ({
			...p,
			techInterests: p.techInterests.filter((x) => x !== tag),
		}));
	};

	const toggleLearningStyle = (id) => {
		setPrefs((p) => {
			const has = p.learningStyles.includes(id);
			const learningStyles = has
				? p.learningStyles.filter((x) => x !== id)
				: [...p.learningStyles, id];
			return { ...p, learningStyles };
		});
	};

	const handleTechKeyDown = (e) => {
		if (e.key === "Enter") {
			e.preventDefault();
			addTechTag(techDraft);
		}
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		setMessage({ type: "", text: "" });
		setSaving(true);
		try {
			await updateProfile({
				fullName: fullName.trim(),
				preferences: {
					techInterests: prefs.techInterests,
					bio: prefs.bio,
					learningGoals: prefs.learningGoals,
					experienceLevel: prefs.experienceLevel,
					learningStyles: prefs.learningStyles,
					careerFocus: prefs.careerFocus,
				},
			});
			setMessage({ type: "ok", text: "Profile saved." });
		} catch (err) {
			setMessage({
				type: "err",
				text: err.message || "Could not save. Try again.",
			});
		} finally {
			setSaving(false);
		}
	};

	return (
		<div className="dashboard-page">
			<div className="dashboard-page-header">
				<h1 className="dashboard-page-title">Settings</h1>
				<p className="dashboard-page-subtitle">
					Update your profile and learning preferences. We use this to personalize courses and
					guidance.
				</p>
			</div>

			<form className="settings-layout" onSubmit={handleSubmit}>
				<div className="dashboard-card settings-section">
					<h2 className="settings-section-title">Account</h2>
					<div className="settings-field">
						<label className="settings-label" htmlFor="email">
							Email
						</label>
						<p className="settings-readonly">{user?.email}</p>
					</div>
					<div className="settings-field">
						<label className="settings-label" htmlFor="fullName">
							Display name
						</label>
						<input
							id="fullName"
							className="settings-input"
							type="text"
							autoComplete="name"
							value={fullName}
							onChange={(e) => setFullName(e.target.value)}
							placeholder="Your name"
							maxLength={120}
						/>
					</div>
				</div>

				<div className="dashboard-card settings-section">
					<h2 className="settings-section-title">About you</h2>
					<p className="settings-section-desc">
						A short bio and career direction help us tailor recommendations.
					</p>
					<div className="settings-field">
						<label className="settings-label" htmlFor="bio">
							Bio
						</label>
						<textarea
							id="bio"
							className="settings-textarea"
							value={prefs.bio}
							onChange={(e) => setPrefs((p) => ({ ...p, bio: e.target.value }))}
							placeholder="A few words about you, your background, or what you enjoy learning."
							maxLength={500}
						/>
					</div>
					<div className="settings-field">
						<label className="settings-label" htmlFor="careerFocus">
							Career focus
						</label>
						<input
							id="careerFocus"
							className="settings-input"
							type="text"
							value={prefs.careerFocus}
							onChange={(e) => setPrefs((p) => ({ ...p, careerFocus: e.target.value }))}
							placeholder="e.g. Software engineering, UX design, Data analytics"
							maxLength={200}
						/>
					</div>
				</div>

				<div className="dashboard-card settings-section">
					<h2 className="settings-section-title">Tech & topics</h2>
					<p className="settings-section-desc">
						Add technologies, languages, or domains you care about. Click a suggestion or type
						and press Enter.
					</p>
					<div className="settings-field">
						<span className="settings-label">Your tags</span>
						<div className="settings-tag-input-wrap">
							<div className="settings-tags">
								{prefs.techInterests.map((tag) => (
									<span key={tag} className="settings-tag">
										{tag}
										<button
											type="button"
											className="settings-tag-remove"
											onClick={() => removeTechTag(tag)}
											aria-label={`Remove ${tag}`}
										>
											×
										</button>
									</span>
								))}
							</div>
							<input
								className="settings-tag-field"
								type="text"
								value={techDraft}
								onChange={(e) => setTechDraft(e.target.value)}
								onKeyDown={handleTechKeyDown}
								placeholder="Add a tag…"
								maxLength={48}
							/>
						</div>
						<p className="settings-hint">Up to 40 tags. Press Enter to add.</p>
					</div>
					<div>
						<span className="settings-label">Suggestions</span>
						<div className="settings-chip-grid">
							{SUGGESTED_TECH.map((s) => (
								<button
									key={s}
									type="button"
									className={`settings-chip ${prefs.techInterests.includes(s) ? "settings-chip--active" : ""}`}
									onClick={() => addTechTag(s)}
								>
									{s}
								</button>
							))}
						</div>
					</div>
				</div>

				<div className="dashboard-card settings-section">
					<h2 className="settings-section-title">Learning preferences</h2>
					<div className="settings-field">
						<label className="settings-label" htmlFor="experience">
							Experience level
						</label>
						<select
							id="experience"
							className="settings-select"
							value={prefs.experienceLevel}
							onChange={(e) =>
								setPrefs((p) => ({ ...p, experienceLevel: e.target.value }))
							}
						>
							{EXPERIENCE_OPTIONS.map((o) => (
								<option key={o.value} value={o.value}>
									{o.label}
								</option>
							))}
						</select>
					</div>
					<div className="settings-field">
						<span className="settings-label">Preferred formats</span>
						<div className="settings-chip-grid">
							{LEARNING_STYLES.map(({ id, label }) => (
								<button
									key={id}
									type="button"
									className={`settings-chip ${prefs.learningStyles.includes(id) ? "settings-chip--active" : ""}`}
									onClick={() => toggleLearningStyle(id)}
								>
									{label}
								</button>
							))}
						</div>
					</div>
					<div className="settings-field">
						<label className="settings-label" htmlFor="learningGoals">
							Learning goals
						</label>
						<textarea
							id="learningGoals"
							className="settings-textarea"
							value={prefs.learningGoals}
							onChange={(e) => setPrefs((p) => ({ ...p, learningGoals: e.target.value }))}
							placeholder="What do you want to achieve next? Certificates, a job switch, a specific skill…"
							maxLength={2000}
						/>
					</div>
				</div>

				<div className="settings-actions">
					<button type="submit" className="btn btn-primary" disabled={saving}>
						<FaSave style={{ marginRight: "0.5rem", opacity: 0.9 }} />
						{saving ? "Saving…" : "Save profile"}
					</button>
					{message.text && (
						<span
							className={`settings-msg ${message.type === "ok" ? "settings-msg--ok" : "settings-msg--err"}`}
						>
							{message.text}
						</span>
					)}
				</div>
			</form>
		</div>
	);
};

export default DashboardSettingsPage;
