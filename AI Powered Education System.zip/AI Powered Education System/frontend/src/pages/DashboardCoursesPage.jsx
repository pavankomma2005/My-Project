import React, { useEffect, useMemo, useState } from "react";
import {
	FaBook,
	FaUser,
	FaExternalLinkAlt,
	FaSearch,
	FaStar,
	FaChevronLeft,
	FaChevronRight,
} from "react-icons/fa";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./DashboardPage.css";
import "./DashboardFeaturePages.css";
import "./DashboardCoursesPage.css";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:5000";
const PAGE_SIZE = 12;

const DashboardCoursesPage = () => {
	const { user } = useAuth();
	const [courses, setCourses] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState("");
	const [personalized, setPersonalized] = useState(false);

	const [search, setSearch] = useState("");
	const [platform, setPlatform] = useState("all");
	const [sort, setSort] = useState("recommended");
	const [matchesOnly, setMatchesOnly] = useState(false);
	const [page, setPage] = useState(1);

	const profileQuery = useMemo(() => {
		const params = new URLSearchParams();
		const tags = user?.preferences?.techInterests;
		if (Array.isArray(tags) && tags.length) params.set("match", tags.join(","));
		const focus = user?.preferences?.careerFocus?.trim();
		if (focus) params.set("focus", focus);
		const goals = user?.preferences?.learningGoals?.trim();
		if (goals) params.set("goals", goals.slice(0, 500));
		return params.toString();
	}, [user?.preferences]);

	useEffect(() => {
		let cancelled = false;
		const load = async () => {
			setLoading(true);
			setError("");
			try {
				const q = profileQuery ? `?${profileQuery}` : "";
				const res = await fetch(`${API_BASE}/api/courses/external${q}`);
				const data = await res.json().catch(() => ({}));
				if (!res.ok) throw new Error(data.message || "Could not load courses");
				if (!cancelled) {
					setCourses(data.courses || []);
					setPersonalized(!!data.personalized);
				}
			} catch (e) {
				if (!cancelled) setError(e.message || "Failed to load courses");
			} finally {
				if (!cancelled) setLoading(false);
			}
		};
		load();
		return () => {
			cancelled = true;
		};
	}, [profileQuery]);

	const platforms = useMemo(() => {
		const s = new Set(courses.map((c) => c.platform));
		return ["all", ...Array.from(s).sort((a, b) => a.localeCompare(b))];
	}, [courses]);

	const sortedCourses = useMemo(() => {
		const list = [...courses];
		if (sort === "title") list.sort((a, b) => a.title.localeCompare(b.title));
		else if (sort === "platform")
			list.sort((a, b) => a.platform.localeCompare(b.platform) || a.title.localeCompare(b.title));
		return list;
	}, [courses, sort]);

	const filtered = useMemo(() => {
		let list = sortedCourses;
		if (matchesOnly) list = list.filter((c) => c.matched);
		const q = search.trim().toLowerCase();
		if (q) {
			list = list.filter(
				(c) =>
					c.title.toLowerCase().includes(q) ||
					c.platform.toLowerCase().includes(q) ||
					(c.blurb && c.blurb.toLowerCase().includes(q)) ||
					(c.instructor && c.instructor.toLowerCase().includes(q)) ||
					(c.tags && c.tags.some((t) => t.toLowerCase().includes(q)))
			);
		}
		if (platform !== "all") list = list.filter((c) => c.platform === platform);
		return list;
	}, [sortedCourses, search, platform, matchesOnly]);

	const matchCount = useMemo(() => courses.filter((c) => c.matched).length, [courses]);

	useEffect(() => {
		setPage(1);
	}, [search, platform, sort, matchesOnly, profileQuery]);

	const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
	const safePage = Math.min(page, totalPages);
	const pageSlice = useMemo(() => {
		const start = (safePage - 1) * PAGE_SIZE;
		return filtered.slice(start, start + PAGE_SIZE);
	}, [filtered, safePage]);

	const hasProfileSignals =
		(user?.preferences?.techInterests?.length ?? 0) > 0 ||
		!!user?.preferences?.careerFocus?.trim() ||
		!!user?.preferences?.learningGoals?.trim();

	return (
		<div className="dashboard-page expert-courses-page">
			<header className="expert-hero">
				<h1>
					<FaBook style={{ marginRight: "0.5rem", opacity: 0.88, verticalAlign: "-0.08em" }} />
					Expert Courses
				</h1>
				<p className="lead">
					{hasProfileSignals ? (
						<>
							Courses are <strong>ranked for you</strong> using your tech interests, career focus,
							and learning goals from{" "}
							<Link to="/dashboard/settings" className="dashboard-card-link" style={{ display: "inline" }}>
								Settings
							</Link>
							. Open any card to continue on the provider&apos;s site in a new tab.
						</>
					) : (
						<>
							Browse {courses.length || "50+"}+ curated programs from trusted platforms. Add
							preferences in{" "}
							<Link to="/dashboard/settings" className="dashboard-card-link" style={{ display: "inline" }}>
								Settings
							</Link>{" "}
							to personalize ranking. Links open on the provider&apos;s site.
						</>
					)}
				</p>
				{!loading && !error && (
					<div className="expert-stats" role="status">
						<span className="expert-stat-pill">
							<strong>{courses.length}</strong> courses listed
						</span>
						{personalized && matchCount > 0 && (
							<span className="expert-stat-pill">
								<strong>{matchCount}</strong> flagged as a strong match
							</span>
						)}
						{filtered.length !== courses.length && (
							<span className="expert-stat-pill">
								<strong>{filtered.length}</strong> after filters
							</span>
						)}
					</div>
				)}
			</header>

			<div className="expert-toolbar" role="search">
				<div className="expert-toolbar-field expert-toolbar-field--grow">
					<span className="expert-toolbar-label">Search</span>
					<div className="expert-search-wrap">
						<FaSearch className="expert-search-icon" aria-hidden />
						<input
							className="expert-search-input"
							type="search"
							placeholder="Title, platform, topic, or tag…"
							value={search}
							onChange={(e) => setSearch(e.target.value)}
							aria-label="Search courses"
						/>
					</div>
				</div>
				<div className="expert-toolbar-field expert-toolbar-field--sm">
					<span className="expert-toolbar-label">Platform</span>
					<select
						className="expert-select"
						value={platform}
						onChange={(e) => setPlatform(e.target.value)}
						aria-label="Filter by platform"
					>
						{platforms.map((p) => (
							<option key={p} value={p}>
								{p === "all" ? "All platforms" : p}
							</option>
						))}
					</select>
				</div>
				<div className="expert-toolbar-field expert-toolbar-field--sm">
					<span className="expert-toolbar-label">Sort</span>
					<select
						className="expert-select"
						value={sort}
						onChange={(e) => setSort(e.target.value)}
						aria-label="Sort courses"
					>
						<option value="recommended">Best match (default)</option>
						<option value="title">Title (A–Z)</option>
						<option value="platform">Platform</option>
					</select>
				</div>
				{personalized && (
					<div className="expert-toolbar-field">
						<span className="expert-toolbar-label">Profile</span>
						<label className="expert-toggle">
							<input
								type="checkbox"
								checked={matchesOnly}
								onChange={(e) => setMatchesOnly(e.target.checked)}
							/>
							Strong matches only
						</label>
					</div>
				)}
			</div>

			{loading && (
				<p style={{ color: "var(--text-secondary)", fontSize: "0.9375rem" }}>Loading courses…</p>
			)}
			{error && (
				<p style={{ color: "#b91c1c", fontSize: "0.9375rem", marginBottom: "1rem" }}>{error}</p>
			)}

			{!loading && !error && filtered.length === 0 && (
				<div className="expert-empty">
					No courses match your filters. Try clearing search or switching platform.
				</div>
			)}

			{!loading && !error && filtered.length > 0 && (
				<>
					{personalized && matchCount > 0 && page === 1 && !search && platform === "all" && !matchesOnly && (
						<p className="expert-section-note">
							Cards with a &quot;Strong match&quot; badge align with your profile; the list below
							follows your sort order (best match keeps server ranking when selected).
						</p>
					)}
					<div className="expert-grid">
						{pageSlice.map((c) => (
							<article
								key={c.id}
								className={`expert-course-card ${c.matched ? "expert-course-card--match" : ""}`}
							>
								<div className="expert-course-thumb" aria-hidden>
									<span>{c.emoji}</span>
								</div>
								<div className="expert-course-body">
									<div className="expert-course-meta">
										<span className="expert-course-platform">{c.platform}</span>
										{c.matched && (
											<span className="expert-course-badge">
												<FaStar
													style={{
														display: "inline",
														marginRight: "0.2rem",
														fontSize: "0.55rem",
														verticalAlign: "0.05em",
													}}
												/>
												Strong match
											</span>
										)}
									</div>
									<h2 className="expert-course-title">{c.title}</h2>
									<p className="expert-course-instructor">
										<FaUser style={{ flexShrink: 0, marginTop: "0.12rem", opacity: 0.65 }} />
										<span>{c.instructor}</span>
									</p>
									{c.blurb && <p className="expert-course-blurb">{c.blurb}</p>}
									{c.tags && c.tags.length > 0 && (
										<div className="expert-course-tags">
											{c.tags.slice(0, 5).map((t) => (
												<span key={t} className="expert-course-tag">
													{t}
												</span>
											))}
										</div>
									)}
									<div className="expert-course-footer">
										<span className="expert-course-level">{c.level}</span>
										<a
											href={c.url}
											target="_blank"
											rel="noopener noreferrer"
											className="expert-course-link"
										>
											Open
											<FaExternalLinkAlt style={{ fontSize: "0.7rem", opacity: 0.95 }} />
										</a>
									</div>
									<span className="expert-course-duration">{c.duration}</span>
								</div>
							</article>
						))}
					</div>

					{filtered.length > PAGE_SIZE && (
						<nav className="expert-pagination" aria-label="Course pages">
							<button
								type="button"
								disabled={safePage <= 1}
								onClick={() => setPage((p) => Math.max(1, p - 1))}
								aria-label="Previous page"
							>
								<FaChevronLeft style={{ marginRight: "0.25rem" }} />
								Prev
							</button>
							<span className="expert-pagination-info">
								Page {safePage} of {totalPages} ({filtered.length} courses)
							</span>
							<button
								type="button"
								disabled={safePage >= totalPages}
								onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
								aria-label="Next page"
							>
								Next
								<FaChevronRight style={{ marginLeft: "0.25rem" }} />
							</button>
						</nav>
					)}
				</>
			)}

			<div className="feature-panel" style={{ marginTop: "1rem" }}>
				<h3 style={{ marginTop: 0 }}>Dashboard</h3>
				<p style={{ margin: "0 0 1rem 0", color: "var(--text-secondary)", fontSize: "0.9375rem" }}>
					Return to your overview anytime.
				</p>
				<Link to="/dashboard" className="btn btn-secondary">
					Back to overview
				</Link>
			</div>
		</div>
	);
};

export default DashboardCoursesPage;
