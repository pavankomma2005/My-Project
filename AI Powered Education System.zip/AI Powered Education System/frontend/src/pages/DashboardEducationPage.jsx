import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
	FaGraduationCap,
	FaCompass,
	FaBook,
	FaExternalLinkAlt,
	FaClipboardList,
} from "react-icons/fa";
import { useAuth } from "../context/AuthContext";
import { EDUCATION_BY_TRACK } from "../data/educationPathsData";
import {
	buildLearningPlanContext,
	planContextLabel,
	resolveLearningTrack,
} from "../lib/learningPlan";
import "./DashboardPage.css";
import "./DashboardFeaturePages.css";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:5000";

const LEVEL_NOTE = {
	beginner: "Prioritize foundational courses and structured degree or diploma routes.",
	intermediate: "Strong time to add credentials that differentiate (portfolio-heavy programs or certs).",
	advanced: "Consider graduate specialization, leadership electives, or executive-format programs.",
};

const DashboardEducationPage = () => {
	const { user } = useAuth();
	const ctx = useMemo(() => buildLearningPlanContext(user), [user]);
	const trackId = useMemo(() => resolveLearningTrack(ctx), [ctx]);
	const edu = EDUCATION_BY_TRACK[trackId] || EDUCATION_BY_TRACK.default;
	const contextLabel = planContextLabel(ctx, trackId);

	const profileQuery = useMemo(() => {
		const params = new URLSearchParams();
		const tags = user?.preferences?.techInterests;
		if (Array.isArray(tags) && tags.length) params.set("match", tags.join(","));
		const focus = user?.preferences?.careerFocus?.trim();
		if (focus) params.set("focus", focus);
		const goals = user?.preferences?.learningGoals?.trim();
		if (goals) params.set("goals", goals.slice(0, 500));
		return params.toString();
	}, [user?.preferences]);

	const [courses, setCourses] = useState([]);
	const [coursesLoading, setCoursesLoading] = useState(true);
	const [coursesError, setCoursesError] = useState("");

	useEffect(() => {
		let cancelled = false;
		const load = async () => {
			setCoursesLoading(true);
			setCoursesError("");
			try {
				const q = profileQuery ? `?${profileQuery}` : "";
				const res = await fetch(`${API_BASE}/api/courses/external${q}`);
				const data = await res.json().catch(() => ({}));
				if (!res.ok) throw new Error(data.message || "Could not load courses");
				if (!cancelled) {
					const list = data.courses || [];
					const matched = list.filter((c) => c.matched);
					const rest = list.filter((c) => !c.matched);
					setCourses([...matched, ...rest].slice(0, 6));
				}
			} catch (e) {
				if (!cancelled) setCoursesError(e.message || "Failed to load courses");
			} finally {
				if (!cancelled) setCoursesLoading(false);
			}
		};
		load();
		return () => {
			cancelled = true;
		};
	}, [profileQuery]);

	const level = ctx.experienceLevel || "beginner";
	const levelHint = LEVEL_NOTE[level] || LEVEL_NOTE.beginner;

	return (
		<div className="dashboard-page education-page">
			<div className="feature-page-intro">
				<h1>
					<FaGraduationCap style={{ marginRight: "0.5rem", opacity: 0.85, verticalAlign: "-0.1em" }} />
					Education Paths
				</h1>
				<p className="lead">
					Formal degrees, exams, and stackable credentials matched to your direction—plus expert courses you
					can start now. Refine{" "}
					<Link to="/dashboard/settings" className="dashboard-card-link" style={{ display: "inline" }}>
						Settings
					</Link>{" "}
					(career focus, goals, tech tags) for tighter alignment.
				</p>
			</div>

			<div className="roadmap-context-bar">
				<div className="roadmap-context-pill">
					<FaCompass aria-hidden />
					<span>
						<strong>Direction:</strong> {contextLabel}
					</span>
				</div>
				<span className="roadmap-context-track">Education pack: {edu.headline}</span>
			</div>

			<div className="feature-panel edu-level-panel">
				<h3 style={{ marginTop: 0, marginBottom: "0.5rem" }}>Experience level</h3>
				<p style={{ margin: 0, fontSize: "0.9375rem", color: "var(--text-secondary)", lineHeight: 1.55 }}>
					<span className="edu-level-badge">{level}</span>
					{levelHint}
				</p>
			</div>

			<div className="feature-panel" style={{ marginBottom: "1.5rem" }}>
				<h3 style={{ marginTop: 0 }}>{edu.headline}</h3>
				<p style={{ margin: 0, fontSize: "0.9375rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>
					{edu.intro}
				</p>
			</div>

			<h2 className="feature-section-title">Formal routes</h2>
			<div className="feature-grid">
				{edu.routes.map((r) => (
					<div key={r.title} className="feature-panel edu-card">
						<div className="edu-card-head">
							<h3 className="edu-card-name">{r.title}</h3>
							<span className="edu-card-badge">{r.fit}</span>
						</div>
						<p className="edu-card-meta">
							{r.credential} · {r.duration}
						</p>
						<p style={{ margin: 0, fontSize: "0.9375rem", color: "var(--text-secondary)", lineHeight: 1.5 }}>
							{r.description}
						</p>
					</div>
				))}
			</div>

			<h2 className="feature-section-title" style={{ marginTop: "2rem" }}>
				Exams & milestones
			</h2>
			<div className="feature-panel edu-exams-panel">
				<ul className="edu-exam-list">
					{edu.exams.map((ex) => (
						<li key={ex.title}>
							<FaClipboardList className="edu-exam-icon" aria-hidden />
							<div>
								<strong className="edu-exam-title">{ex.title}</strong>
								<p className="edu-exam-detail">{ex.detail}</p>
							</div>
						</li>
					))}
				</ul>
			</div>

			<h2 className="feature-section-title" style={{ marginTop: "2rem" }}>
				Start building skills now
			</h2>
			<p className="course-section-desc" style={{ marginBottom: "1rem" }}>
				Personalized picks from our expert course catalog (same ranking as the Courses page). Add tech
				interests in Settings for stronger matches.
			</p>

			{coursesLoading && (
				<p style={{ color: "var(--text-secondary)", fontSize: "0.9375rem" }}>Loading course matches…</p>
			)}
			{coursesError && (
				<p style={{ color: "var(--accent-error)", fontSize: "0.9375rem" }}>{coursesError}</p>
			)}

			{!coursesLoading && !coursesError && courses.length > 0 && (
				<div className="course-card-grid edu-course-grid">
					{courses.map((c) => (
						<div key={c.id || c.title} className="course-card course-card--external">
							<div className="course-card-thumb" aria-hidden>
								<FaBook />
							</div>
							<div className="course-card-body">
								<div className="course-card-platform-row">
									<span className="course-card-platform">{c.platform}</span>
									{c.matched && <span className="course-card-matched">Matches profile</span>}
								</div>
								<h3 className="course-card-title">{c.title}</h3>
								<p className="course-card-educator">{c.instructor || "Instructor TBA"}</p>
								<p style={{ fontSize: "0.8125rem", color: "var(--text-secondary)", margin: "0 0 0.75rem", flex: 1, lineHeight: 1.45 }}>
									{(c.blurb || "").slice(0, 140)}
									{(c.blurb || "").length > 140 ? "…" : ""}
								</p>
								<div className="course-card-footer">
									<span className="course-card-level">{c.level || "All levels"}</span>
									{c.url && (
										<a
											href={c.url}
											target="_blank"
											rel="noopener noreferrer"
											className="btn btn-secondary"
											style={{ fontSize: "0.8125rem", padding: "0.35rem 0.75rem" }}
										>
											Open
											<FaExternalLinkAlt style={{ marginLeft: "0.35rem", fontSize: "0.7rem" }} />
										</a>
									)}
								</div>
							</div>
						</div>
					))}
				</div>
			)}

			<div className="edu-footer-cta">
				<Link to="/dashboard/courses" className="btn btn-primary">
					<FaBook style={{ marginRight: "0.45rem" }} />
					Browse all expert courses
				</Link>
				<Link to="/dashboard/roadmap" className="btn btn-secondary">
					View career roadmap
				</Link>
			</div>
		</div>
	);
};

export default DashboardEducationPage;
