import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { loadGuidanceBundle } from "../lib/guidanceStorage";
import {
	FaBookOpen,
	FaChartLine,
	FaClock,
	FaAward,
	FaArrowRight,
	FaCompass,
	FaRocket,
	FaGraduationCap,
	FaBrain,
	FaBook,
} from "react-icons/fa";
import "./DashboardPage.css";
import "./DashboardFeaturePages.css";

const statCards = [
	{
		title: "Courses in progress",
		value: "3",
		subtext: "2 completed this month",
		icon: FaBookOpen,
		trend: "+1",
		color: "primary",
	},
	{
		title: "Learning streak",
		value: "7 days",
		subtext: "Keep it up!",
		icon: FaChartLine,
		trend: "+2",
		color: "success",
	},
	{
		title: "Hours this week",
		value: "12h",
		subtext: "Goal: 15h",
		icon: FaClock,
		trend: "75%",
		color: "info",
	},
	{
		title: "Certificates",
		value: "5",
		subtext: "Latest: React Fundamentals",
		icon: FaAward,
		trend: "+1",
		color: "accent",
	},
];

const recentActivity = [
	{ id: 1, title: "Completed: Introduction to Node.js", time: "2 hours ago", type: "completion" },
	{ id: 2, title: "Started: MongoDB Basics", time: "Yesterday", type: "start" },
	{ id: 3, title: "Earned badge: First Steps", time: "2 days ago", type: "badge" },
];

const succeedTools = [
	{
		to: "/dashboard/guidance",
		title: "Personalized Guidance",
		description:
			"Get tailored career recommendations based on your interests, skills, and academic background.",
		icon: FaCompass,
	},
	{
		to: "/dashboard/roadmap",
		title: "Career Roadmap",
		description:
			"Step-by-step plans with courses, exams, skills, and timelines for your dream career.",
		icon: FaRocket,
	},
	{
		to: "/dashboard/education",
		title: "Education Paths",
		description: "Smart recommendations for higher education, universities, and courses suited for you.",
		icon: FaGraduationCap,
	},
	{
		to: "/dashboard/skills",
		title: "Skill-Based Mapping",
		description: "Discover careers and certifications that match your existing skills and talents.",
		icon: FaBrain,
	},
	{
		to: "/dashboard/courses",
		title: "Expert Courses",
		description: "Access quality courses uploaded by educators across various skill areas.",
		icon: FaBook,
	},
];

function truncateGuidanceText(text, maxLen) {
	const s = String(text || "").trim();
	if (s.length <= maxLen) return s;
	return `${s.slice(0, maxLen - 1)}…`;
}

const DashboardPage = () => {
	const { user } = useAuth();
	const location = useLocation();
	const [guidanceBundle, setGuidanceBundle] = useState(null);

	useEffect(() => {
		setGuidanceBundle(loadGuidanceBundle());
	}, [location.pathname]);

	const snapAdvice = guidanceBundle?.guidance?.shortAdvice;
	const topRec = guidanceBundle?.guidance?.recommendations?.[0];

	return (
		<div className="dashboard-page">
			<div className="dashboard-page-header">
				<div>
					<h1 className="dashboard-page-title">
						Welcome back, {user?.fullName?.split(" ")[0] || "there"}!
					</h1>
					<p className="dashboard-page-subtitle">
						Here’s your learning overview for today.
					</p>
				</div>
			</div>

			{snapAdvice && (
				<section
					className="dashboard-card dashboard-card--wide"
					style={{ marginBottom: "1.75rem" }}
					aria-labelledby="dash-guidance-snapshot-title"
				>
					<div className="dashboard-card-header">
						<h2 id="dash-guidance-snapshot-title" className="dashboard-card-title">
							Your personalized guidance
						</h2>
						<Link to="/dashboard/guidance" className="dashboard-card-link">
							Full guidance <FaArrowRight />
						</Link>
					</div>
					<p
						style={{
							margin: "0 0 0.75rem 0",
							fontSize: "0.9375rem",
							color: "var(--text-secondary)",
							lineHeight: 1.65,
						}}
					>
						{truncateGuidanceText(snapAdvice, 320)}
					</p>
					{topRec?.title && (
						<Link
							to="/dashboard/guidance/recommendation/0"
							className="dashboard-card-link"
							style={{ display: "inline-flex", alignItems: "center", gap: "0.35rem" }}
						>
							Open top direction: {topRec.title} <FaArrowRight />
						</Link>
					)}
				</section>
			)}

			<section className="dashboard-hub section-lg" style={{ marginBottom: "2rem" }}>
				<div className="feature-page-intro" style={{ maxWidth: "100%" }}>
					<h2 className="dashboard-page-title" style={{ fontSize: "1.35rem" }}>
						Everything You Need to{" "}
						<span className="text-gradient" style={{ fontFamily: "inherit" }}>
							Succeed
						</span>
					</h2>
					<p className="dashboard-page-subtitle" style={{ maxWidth: "560px", marginTop: "0.5rem" }}>
						Comprehensive tools and features designed to guide you from confusion to clarity
					</p>
				</div>
				<div className="feature-grid">
					{succeedTools.map((tool) => (
						<Link key={tool.to} to={tool.to} className="feature-panel dashboard-hub-card">
							<div style={{ display: "flex", alignItems: "flex-start", gap: "0.75rem" }}>
								<div
									className="dashboard-hub-icon"
									aria-hidden
								>
									<tool.icon />
								</div>
								<div>
									<h3 style={{ margin: "0 0 0.5rem 0", fontSize: "1.0625rem" }}>{tool.title}</h3>
									<p style={{ margin: 0, fontSize: "0.9rem", color: "var(--text-secondary)", lineHeight: 1.5 }}>
										{tool.description}
									</p>
								</div>
							</div>
							<span
								style={{
									display: "inline-flex",
									alignItems: "center",
									gap: "0.35rem",
									marginTop: "1rem",
									fontSize: "0.875rem",
									fontWeight: 600,
									color: "var(--primary-color)",
								}}
							>
								Open <FaArrowRight />
							</span>
						</Link>
					))}
				</div>
			</section>

			<section className="dashboard-stats">
				{statCards.map((card) => (
					<div
						key={card.title}
						className={`stat-card stat-card--${card.color}`}
					>
						<div className="stat-card-header">
							<span className="stat-card-title">{card.title}</span>
							<span className="stat-card-trend">{card.trend}</span>
						</div>
						<div className="stat-card-value">{card.value}</div>
						<p className="stat-card-subtext">{card.subtext}</p>
						<div className="stat-card-icon">
							<card.icon />
						</div>
					</div>
				))}
			</section>

			<div className="dashboard-grid">
				<section className="dashboard-card dashboard-card--wide">
					<div className="dashboard-card-header">
						<h2 className="dashboard-card-title">Continue learning</h2>
						<Link to="/dashboard/courses" className="dashboard-card-link">
							View all <FaArrowRight />
						</Link>
					</div>
					<div className="continue-learning-list">
						{[
							{ title: "Advanced React Patterns", progress: 65, color: "primary" },
							{ title: "REST APIs with Express", progress: 30, color: "success" },
							{ title: "MongoDB & Mongoose", progress: 10, color: "info" },
						].map((item) => (
							<div key={item.title} className="continue-learning-item">
								<div className="continue-learning-info">
									<span className="continue-learning-title">{item.title}</span>
									<span className="continue-learning-progress">{item.progress}%</span>
								</div>
								<div className="progress-bar">
									<div
										className={`progress-bar-fill progress-bar-fill--${item.color}`}
										style={{ width: `${item.progress}%` }}
									/>
								</div>
							</div>
						))}
					</div>
				</section>

				<section className="dashboard-card">
					<div className="dashboard-card-header">
						<h2 className="dashboard-card-title">Recent activity</h2>
					</div>
					<ul className="activity-list">
						{recentActivity.map((item) => (
							<li key={item.id} className="activity-item">
								<span className="activity-title">{item.title}</span>
								<span className="activity-time">{item.time}</span>
							</li>
						))}
					</ul>
				</section>
			</div>
		</div>
	);
};

export default DashboardPage;
