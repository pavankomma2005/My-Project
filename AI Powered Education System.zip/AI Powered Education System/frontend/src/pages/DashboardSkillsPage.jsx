import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
	FaBrain,
	FaCertificate,
	FaBriefcase,
	FaCompass,
	FaPlus,
	FaTimes,
	FaBook,
	FaExternalLinkAlt,
} from "react-icons/fa";
import { useAuth } from "../context/AuthContext";
import { buildLearningPlanContext, planContextLabel, resolveLearningTrack } from "../lib/learningPlan";
import {
	buildCoursesQueryFromSkills,
	buildInitialSkills,
	normalizeCustomSkills,
	pickCertifications,
	scoreRoles,
} from "../lib/skillMapping";
import "./DashboardPage.css";
import "./DashboardFeaturePages.css";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:5000";

function pctLabel(p) {
	if (!Number.isFinite(p)) return "0%";
	return `${Math.round(p * 100)}%`;
}

const DashboardSkillsPage = () => {
	const { user, updateProfile } = useAuth();
	const ctx = useMemo(() => buildLearningPlanContext(user), [user]);
	const trackId = useMemo(() => resolveLearningTrack(ctx), [ctx]);
	const contextLabel = planContextLabel(ctx, trackId);

	const initial = useMemo(() => buildInitialSkills(user), [user]);

	const [custom, setCustom] = useState(() =>
		normalizeCustomSkills(user?.preferences?.customSkills || [])
	);
	const [draft, setDraft] = useState("");
	const [courses, setCourses] = useState([]);
	const [coursesLoading, setCoursesLoading] = useState(true);
	const [coursesError, setCoursesError] = useState("");
	const [savingSkills, setSavingSkills] = useState(false);
	const [saveHint, setSaveHint] = useState("");

	const skills = useMemo(() => {
		const base = initial.skills || [];
		return [...base, ...custom].slice(0, 40);
	}, [initial.skills, custom]);

	useEffect(() => {
		setCustom(normalizeCustomSkills(user?.preferences?.customSkills || []));
	}, [user?.preferences?.customSkills]);

	useEffect(() => {
		// Persist custom skill chips in DB (debounced) so mapping stays synced across devices.
		const currentInProfile = normalizeCustomSkills(user?.preferences?.customSkills || []);
		const current = normalizeCustomSkills(custom);
		if (JSON.stringify(currentInProfile) === JSON.stringify(current)) return;

		setSaveHint("Saving skill mapping…");
		const timer = setTimeout(async () => {
			try {
				setSavingSkills(true);
				await updateProfile({ preferences: { customSkills: current } });
				setSaveHint("Saved");
			} catch (_) {
				setSaveHint("Could not save skill changes");
			} finally {
				setSavingSkills(false);
				setTimeout(() => setSaveHint(""), 1500);
			}
		}, 500);
		return () => clearTimeout(timer);
	}, [custom, user?.preferences?.customSkills, updateProfile]);

	const roles = useMemo(() => scoreRoles(skills), [skills]);
	const certs = useMemo(() => pickCertifications(skills, trackId), [skills, trackId]);

	const addSkill = () => {
		const s = String(draft || "").trim();
		if (!s) return;
		setCustom((prev) => {
			const next = [...prev, s]
				.map((x) => String(x || "").trim())
				.filter(Boolean);
			const seen = new Set();
			const out = [];
			for (const x of next) {
				const k = x.toLowerCase();
				if (seen.has(k)) continue;
				seen.add(k);
				out.push(x);
			}
			return normalizeCustomSkills(out);
		});
		setDraft("");
	};

	const removeCustom = (s) => {
		setCustom((prev) => prev.filter((x) => String(x).toLowerCase() !== String(s).toLowerCase()));
	};

	const courseQuery = useMemo(() => buildCoursesQueryFromSkills(skills, user), [skills, user]);

	useEffect(() => {
		let cancelled = false;
		const load = async () => {
			setCoursesLoading(true);
			setCoursesError("");
			try {
				const q = courseQuery ? `?${courseQuery}` : "";
				const res = await fetch(`${API_BASE}/api/courses/external${q}`);
				const data = await res.json().catch(() => ({}));
				if (!res.ok) throw new Error(data.message || "Could not load courses");
				if (!cancelled) {
					const list = data.courses || [];
					const matched = list.filter((c) => c.matched);
					const rest = list.filter((c) => !c.matched);
					setCourses([...matched, ...rest].slice(0, 6));
				}
			} catch (e) {
				if (!cancelled) setCoursesError(e.message || "Failed to load courses");
			} finally {
				if (!cancelled) setCoursesLoading(false);
			}
		};
		load();
		return () => {
			cancelled = true;
		};
	}, [courseQuery]);

	return (
		<div className="dashboard-page skill-map-page">
			<div className="feature-page-intro">
				<h1>
					<FaBrain style={{ marginRight: "0.5rem", opacity: 0.85, verticalAlign: "-0.1em" }} />
					Skill-Based Mapping
				</h1>
				<p className="lead">
					See which roles you’re closest to based on your profile tags + guidance direction, then fill
					gaps with focused skills and course picks.
				</p>
			</div>

			<div className="roadmap-context-bar">
				<div className="roadmap-context-pill">
					<FaCompass aria-hidden />
					<span>
						<strong>Aligned with:</strong> {contextLabel}
					</span>
				</div>
				<span className="roadmap-context-track">Track: {trackId}</span>
			</div>

			<div className="feature-panel skill-map-panel">
				<div className="skill-map-head">
					<div>
						<p className="feature-section-title" style={{ marginBottom: "0.5rem" }}>
							Skills used for mapping
						</p>
						<p className="skill-map-sub">
							We start from your Settings + Guidance context, then you can add custom skills. These are
							auto-saved to your profile.
						</p>
					</div>
					<Link to="/dashboard/settings" className="dashboard-card-link">
						Edit profile <FaCompass />
					</Link>
				</div>

				<div className="skill-map-add">
					<input
						className="skill-map-input"
						value={draft}
						onChange={(e) => setDraft(e.target.value)}
						placeholder="Add a skill (e.g. React, SQL, Figma, Linux)"
						maxLength={48}
						onKeyDown={(e) => {
							if (e.key === "Enter") {
								e.preventDefault();
								addSkill();
							}
						}}
					/>
					<button type="button" className="btn btn-secondary btn-sm" onClick={addSkill} disabled={!draft.trim()}>
						<FaPlus aria-hidden />
						Add
					</button>
					{custom.length > 0 && (
						<button
							type="button"
							className="btn btn-outline btn-sm"
							onClick={() => setCustom([])}
							style={{ padding: "0.625rem 1.1rem" }}
						>
							<FaTimes aria-hidden />
							Clear custom
						</button>
					)}
					{(savingSkills || saveHint) && (
						<span className="feature-meta" style={{ marginLeft: "0.25rem" }}>
							{saveHint || "Saving skill mapping…"}
						</span>
					)}
				</div>

				<div className="skill-chips" style={{ marginBottom: 0 }}>
					{skills.map((s) => {
						const isCustom = custom.some((c) => String(c).toLowerCase() === String(s).toLowerCase());
						return (
							<span key={s} className={`skill-chip ${isCustom ? "skill-chip--custom" : "skill-chip--match"}`}>
								{s}
								{isCustom && (
									<button
										type="button"
										className="skill-chip-remove"
										onClick={() => removeCustom(s)}
										aria-label={`Remove ${s}`}
									>
										×
									</button>
								)}
							</span>
						);
					})}
				</div>
			</div>

			<div className="feature-two-col" style={{ marginTop: "1.25rem" }}>
				<section className="feature-panel">
					<h3 style={{ marginTop: 0, display: "flex", alignItems: "center", gap: "0.5rem" }}>
						<FaBriefcase /> Career matches
					</h3>
					<ul className="skill-map-role-list">
						{roles.map((r) => (
							<li key={r.id} className="skill-map-role">
								<div className="skill-map-role-top">
									<div>
										<strong className="skill-map-role-title">{r.title}</strong>
										<p className="skill-map-role-desc">{r.description}</p>
									</div>
									<span className="skill-map-role-score">{pctLabel(r.requiredPct)}</span>
								</div>
								<div className="skill-map-bar" aria-hidden>
									<div className="skill-map-bar-fill" style={{ width: `${Math.round(r.requiredPct * 100)}%` }} />
								</div>
								<div className="skill-map-role-meta">
									<span>
										<strong>{r.requiredHit.length}</strong> / {r.required.length} core skills matched
									</span>
									<span className="skill-map-role-pill">{r.track}</span>
								</div>
								{r.suggestions?.length > 0 && (
									<div className="skill-map-gaps">
										<span className="skill-map-gaps-label">Best next skills</span>
										<div className="skill-map-gaps-chips">
											{r.suggestions.map((g) => (
												<span key={g} className="skill-map-gap-chip">
													{g}
												</span>
											))}
										</div>
									</div>
								)}
							</li>
						))}
					</ul>
				</section>

				<section className="feature-panel">
					<h3 style={{ marginTop: 0, display: "flex", alignItems: "center", gap: "0.5rem" }}>
						<FaCertificate /> Certifications to consider
					</h3>
					<ul className="feature-list">
						{certs.map((c) => (
							<li key={c.id}>
								<FaCertificate className="feature-list-icon" />
								<div>
									<strong>{c.name}</strong>
									<div className="feature-meta">{c.reason}</div>
									{c.builds?.length > 0 && (
										<div className="skill-map-mini-tags">
											{c.builds.slice(0, 6).map((t) => (
												<span key={t} className="skill-map-mini-tag">
													{t}
												</span>
											))}
										</div>
									)}
								</div>
							</li>
						))}
					</ul>
				</section>
			</div>

			<h2 className="feature-section-title" style={{ marginTop: "2rem" }}>
				Courses to close gaps faster
			</h2>
			<p className="course-section-desc" style={{ marginBottom: "1rem" }}>
				Personalized picks from the expert course catalog, using your current mapped skills.
			</p>

			{coursesLoading && (
				<p style={{ color: "var(--text-secondary)", fontSize: "0.9375rem" }}>Loading course matches…</p>
			)}
			{coursesError && (
				<p style={{ color: "var(--accent-error)", fontSize: "0.9375rem" }}>{coursesError}</p>
			)}

			{!coursesLoading && !coursesError && courses.length > 0 && (
				<div className="course-card-grid">
					{courses.map((c) => (
						<div key={c.id || c.title} className="course-card course-card--external">
							<div className="course-card-thumb" aria-hidden>
								<FaBook />
							</div>
							<div className="course-card-body">
								<div className="course-card-platform-row">
									<span className="course-card-platform">{c.platform}</span>
									{c.matched && <span className="course-card-matched">Matches mapping</span>}
								</div>
								<h3 className="course-card-title">{c.title}</h3>
								<p className="course-card-educator">{c.instructor || "Instructor TBA"}</p>
								{c.blurb && (
									<p
										style={{
											fontSize: "0.8125rem",
											color: "var(--text-secondary)",
											margin: "0 0 0.75rem",
											flex: 1,
											lineHeight: 1.45,
										}}
									>
										{c.blurb.slice(0, 140)}
										{c.blurb.length > 140 ? "…" : ""}
									</p>
								)}
								<div className="course-card-footer">
									<span className="course-card-level">{c.level || "All levels"}</span>
									{c.url && (
										<a
											href={c.url}
											target="_blank"
											rel="noopener noreferrer"
											className="btn btn-secondary"
											style={{ fontSize: "0.8125rem", padding: "0.35rem 0.75rem" }}
										>
											Open <FaExternalLinkAlt style={{ marginLeft: "0.35rem", fontSize: "0.7rem" }} />
										</a>
									)}
								</div>
							</div>
						</div>
					))}
				</div>
			)}

			<div className="edu-footer-cta">
				<Link to="/dashboard/courses" className="btn btn-primary">
					<FaBook style={{ marginRight: "0.45rem" }} />
					Browse all expert courses
				</Link>
				<Link to="/dashboard/roadmap" className="btn btn-secondary">
					View career roadmap
				</Link>
			</div>
		</div>
	);
};

export default DashboardSkillsPage;
