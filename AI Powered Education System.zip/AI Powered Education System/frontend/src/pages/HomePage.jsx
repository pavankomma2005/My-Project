import React from "react";
import { Link } from "react-router-dom";
import {
	FaRocket,
	FaCompass,
	FaGraduationCap,
	FaBrain,
	FaCog,
	FaUsers,
	FaTrophy,
	FaStar,
	FaArrowRight,
	FaCheckCircle,
	FaQuoteLeft,
} from "react-icons/fa";
import "./HomePage.css";

const HomePage = () => {
	const features = [
		{
			icon: <FaCompass />,
			title: "Personalized Guidance",
			description:
				"Get tailored career recommendations based on your interests, skills, and academic background.",
		},
		{
			icon: <FaRocket />,
			title: "Career Roadmap",
			description:
				"Step-by-step plans with courses, exams, skills, and timelines for your dream career.",
		},
		{
			icon: <FaGraduationCap />,
			title: "Education Paths",
			description:
				"Smart recommendations for higher education, universities, and courses suited for you.",
		},
		{
			icon: <FaBrain />,
			title: "Skill-Based Mapping",
			description:
				"Discover careers and certifications that match your existing skills and talents.",
		},
		{
			icon: <FaCog />,
			title: "Profile & preferences",
			description:
				"Save your tech interests and goals to personalize guidance and course recommendations.",
		},
		{
			icon: <FaUsers />,
			title: "Expert Courses",
			description:
				"Access quality courses uploaded by educators across various skill areas.",
		},
	];

	const stats = [
		{ number: "50K+", label: "Active Students" },
		{ number: "1000+", label: "Career Paths" },
		{ number: "500+", label: "Expert Courses" },
		{ number: "98%", label: "Success Rate" },
	];

	const testimonials = [
		{
			name: "Sarah Johnson",
			role: "Data Science Student",
			image: "👩‍💼",
			text: "EduPath AI helped me discover my passion for data science. The roadmap was clear and the resources were invaluable!",
		},
		{
			name: "Michael Chen",
			role: "Software Engineer",
			image: "👨‍💻",
			text: "The skill-based career mapping feature opened doors I never knew existed. Best career advisor ever!",
		},
		{
			name: "Priya Sharma",
			role: "Medical Student",
			image: "👩‍⚕️",
			text: "From confused high school student to confident medical aspirant - EduPath AI guided me every step of the way.",
		},
	];

	const benefits = [
		"AI-powered personalized recommendations",
		"Comprehensive career roadmaps",
		"Expert-curated course content",
		"Real-time learning assistance",
		"Profile-based personalization",
		"Internship & job matching",
	];

	return (
		<div className="home-page">
			{/* Hero Section */}
			<section className="hero-section">
				<div className="hero-background">
					<div className="hero-shape hero-shape-1"></div>
					<div className="hero-shape hero-shape-2"></div>
					<div className="hero-shape hero-shape-3"></div>
				</div>

				<div className="container">
					<div className="hero-content">
						<div className="hero-text">
							<div className="hero-badge fade-in">
								<FaTrophy />
								<span>#1 AI Career Advisor</span>
							</div>

							<h1 className="hero-title slide-in-left">
								Your Future Starts with the
								<span className="text-gradient">
									{" "}
									Right Guidance
								</span>
							</h1>

							<p className="hero-description slide-in-left">
								Confused about your career path? Let our
								AI-powered platform guide you with personalized
								recommendations, detailed roadmaps, and expert
								courses tailored to your unique skills and
								aspirations.
							</p>

							<div className="hero-actions slide-in-left">
								<Link
									to="/signup"
									className="btn btn-primary btn-lg"
								>
									Get Started Free
									<FaArrowRight />
								</Link>
								<Link
									to="/features"
									className="btn btn-secondary btn-lg"
								>
									Explore Features
								</Link>
							</div>

							<div className="hero-trust slide-in-left">
								<div className="trust-stars">
									{[1, 2, 3, 4, 5].map((star) => (
										<FaStar key={star} />
									))}
								</div>
								<p>Trusted by 50,000+ students worldwide</p>
							</div>
						</div>

						<div className="hero-visual slide-in-right">
							<div className="hero-card hero-card-1 float">
								<div className="card-icon">
									<FaGraduationCap />
								</div>
								<div className="card-content">
									<div className="card-stat">98%</div>
									<div className="card-label">
										Success Rate
									</div>
								</div>
							</div>

							<div className="hero-card hero-card-2 float">
								<div className="card-icon">
									<FaUsers />
								</div>
								<div className="card-content">
									<div className="card-stat">50K+</div>
									<div className="card-label">
										Active Students
									</div>
								</div>
							</div>

							<div className="hero-card hero-card-3 float">
								<div className="card-icon">
									<FaChartLine />
								</div>
								<div className="card-content">
									<div className="card-stat">1000+</div>
									<div className="card-label">
										Career Paths
									</div>
								</div>
							</div>

							<div className="hero-illustration">
								<div className="illustration-circle"></div>
								<div className="illustration-icon">🎓</div>
							</div>
						</div>
					</div>
				</div>
			</section>

			{/* Stats Section */}
			<section className="stats-section">
				<div className="container">
					<div className="stats-grid">
						{stats.map((stat, index) => (
							<div key={index} className="stat-card fade-in">
								<div className="stat-number">{stat.number}</div>
								<div className="stat-label">{stat.label}</div>
							</div>
						))}
					</div>
				</div>
			</section>

			{/* Features Section */}
			<section className="features-section section-lg">
				<div className="container">
					<div className="section-header text-center">
						<h2 className="section-title fade-in">
							Everything You Need to
							<span className="text-gradient"> Succeed</span>
						</h2>
						<p className="section-description fade-in">
							Comprehensive tools and features designed to guide
							you from confusion to clarity
						</p>
					</div>

					<div className="grid grid-3">
						{features.map((feature, index) => (
							<div
								key={index}
								className="card fade-in"
								style={{ animationDelay: `${index * 0.1}s` }}
							>
								<div className="card-icon">{feature.icon}</div>
								<h3 className="card-title">{feature.title}</h3>
								<p className="card-description">
									{feature.description}
								</p>
							</div>
						))}
					</div>

					<div className="section-cta text-center mt-5">
						<Link to="/features" className="btn btn-primary btn-lg">
							View All Features
							<FaArrowRight />
						</Link>
					</div>
				</div>
			</section>

			{/* Benefits Section */}
			<section className="benefits-section section-lg">
				<div className="container">
					<div className="benefits-grid">
						<div className="benefits-content">
							<h2 className="section-title fade-in">
								Why Choose
								<span className="text-gradient">
									{" "}
									EduPath AI
								</span>
								?
							</h2>
							<p className="section-description fade-in">
								We combine cutting-edge AI technology with
								expert educational insights to provide you with
								the most personalized career guidance
								experience.
							</p>

							<ul className="benefits-list">
								{benefits.map((benefit, index) => (
									<li
										key={index}
										className="benefit-item fade-in"
										style={{
											animationDelay: `${index * 0.1}s`,
										}}
									>
										<FaCheckCircle className="check-icon" />
										<span>{benefit}</span>
									</li>
								))}
							</ul>

							<Link
								to="/signup"
								className="btn btn-primary btn-lg mt-4"
							>
								Start Your Journey
								<FaArrowRight />
							</Link>
						</div>

						<div className="benefits-visual">
							<div className="benefits-image">
								<div className="benefits-illustration">
									<div className="illustration-bg"></div>
									<div className="illustration-text">🚀</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

			{/* Testimonials Section */}
			<section className="testimonials-section section-lg">
				<div className="container">
					<div className="section-header text-center">
						<h2 className="section-title fade-in">
							Loved by
							<span className="text-gradient">
								{" "}
								Students Worldwide
							</span>
						</h2>
						<p className="section-description fade-in">
							See how EduPath AI has transformed the career
							journeys of thousands
						</p>
					</div>

					<div className="grid grid-3">
						{testimonials.map((testimonial, index) => (
							<div
								key={index}
								className="testimonial-card fade-in"
								style={{ animationDelay: `${index * 0.1}s` }}
							>
								<FaQuoteLeft className="quote-icon" />
								<p className="testimonial-text">
									{testimonial.text}
								</p>
								<div className="testimonial-author">
									<div className="author-image">
										{testimonial.image}
									</div>
									<div className="author-info">
										<div className="author-name">
											{testimonial.name}
										</div>
										<div className="author-role">
											{testimonial.role}
										</div>
									</div>
								</div>
							</div>
						))}
					</div>
				</div>
			</section>

			{/* CTA Section */}
			<section className="cta-section section-lg">
				<div className="container">
					<div className="cta-content">
						<h2 className="cta-title fade-in">
							Ready to Transform Your Future?
						</h2>
						<p className="cta-description fade-in">
							Join thousands of students who have found their
							perfect career path with EduPath AI
						</p>
						<div className="cta-actions fade-in">
							<Link
								to="/signup"
								className="btn btn-primary btn-lg"
							>
								Get Started Free
								<FaArrowRight />
							</Link>
							<Link
								to="/contact"
								className="btn btn-secondary btn-lg"
							>
								Contact Us
							</Link>
						</div>
					</div>
				</div>
			</section>
		</div>
	);
};

export default HomePage;
