import React, { useState } from "react";
import {
	FaEnvelope,
	FaPhone,
	FaMapMarkerAlt,
	FaClock,
	FaPaperPlane,
	FaCheckCircle,
	FaFacebookF,
	FaTwitter,
	FaLinkedinIn,
	FaInstagram,
} from "react-icons/fa";
import "./ContactPage.css";

const ContactPage = () => {
	const [formData, setFormData] = useState({
		name: "",
		email: "",
		subject: "",
		message: "",
	});

	const [isSubmitting, setIsSubmitting] = useState(false);
	const [isSubmitted, setIsSubmitted] = useState(false);

	const handleChange = (e) => {
		setFormData({
			...formData,
			[e.target.name]: e.target.value,
		});
	};

	const handleSubmit = (e) => {
		e.preventDefault();
		setIsSubmitting(true);

		// Simulate form submission
		setTimeout(() => {
			setIsSubmitting(false);
			setIsSubmitted(true);
			setFormData({
				name: "",
				email: "",
				subject: "",
				message: "",
			});

			// Reset success message after 5 seconds
			setTimeout(() => {
				setIsSubmitted(false);
			}, 5000);
		}, 1500);
	};

	const contactInfo = [
		{
			icon: <FaMapMarkerAlt />,
			title: "Visit Us",
			content: "Lovely Professional University",
			subcontent: "Punjab 144411",
		},
		{
			icon: <FaEnvelope />,
			title: "Email Us",
			content: "info@edupathai.com",
			subcontent: "support@edupathai.com",
		},
		{
			icon: <FaPhone />,
			title: "Call Us",
			content: "+1 (555) 123-4567",
			subcontent: "Mon-Fri, 9AM-6PM EST",
		},
		{
			icon: <FaClock />,
			title: "Working Hours",
			content: "Monday - Friday",
			subcontent: "9:00 AM - 6:00 PM EST",
		},
	];

	return (
		<div className="contact-page">
			{/* Hero Section */}
			<section className="contact-hero">
				<div className="container">
					<div className="contact-hero-content">
						<h1 className="contact-hero-title fade-in">
							Get in
							<span className="text-gradient"> Touch</span>
						</h1>
						<p className="contact-hero-description fade-in">
							Have questions? We'd love to hear from you. Send us
							a message and we'll respond as soon as possible.
						</p>
					</div>
				</div>
			</section>

			{/* Contact Info Cards */}
			<section className="contact-info-section">
				<div className="container">
					<div className="grid grid-4">
						{contactInfo.map((info, index) => (
							<div
								key={index}
								className="contact-info-card fade-in"
								style={{ animationDelay: `${index * 0.1}s` }}
							>
								<div className="contact-info-icon">
									{info.icon}
								</div>
								<h3 className="contact-info-title">
									{info.title}
								</h3>
								<p className="contact-info-content">
									{info.content}
								</p>
								<p className="contact-info-subcontent">
									{info.subcontent}
								</p>
							</div>
						))}
					</div>
				</div>
			</section>

			{/* Main Contact Section */}
			<section className="section-lg main-contact-section">
				<div className="container">
					<div className="contact-grid">
						{/* Contact Form */}
						<div className="contact-form-container">
							<h2 className="section-title fade-in">
								Send Us a Message
							</h2>
							<p className="section-description fade-in">
								Fill out the form below and our team will get
								back to you within 24 hours.
							</p>

							{isSubmitted && (
								<div className="success-message fade-in">
									<FaCheckCircle />
									<span>
										Thank you! Your message has been sent
										successfully.
									</span>
								</div>
							)}

							<form
								className="contact-form"
								onSubmit={handleSubmit}
							>
								<div className="form-row">
									<div className="form-group">
										<label
											htmlFor="name"
											className="form-label"
										>
											Full Name *
										</label>
										<input
											type="text"
											id="name"
											name="name"
											className="form-input"
											placeholder="John Doe"
											value={formData.name}
											onChange={handleChange}
											required
										/>
									</div>

									<div className="form-group">
										<label
											htmlFor="email"
											className="form-label"
										>
											Email Address *
										</label>
										<input
											type="email"
											id="email"
											name="email"
											className="form-input"
											placeholder="john@example.com"
											value={formData.email}
											onChange={handleChange}
											required
										/>
									</div>
								</div>

								<div className="form-group">
									<label
										htmlFor="subject"
										className="form-label"
									>
										Subject *
									</label>
									<input
										type="text"
										id="subject"
										name="subject"
										className="form-input"
										placeholder="How can we help?"
										value={formData.subject}
										onChange={handleChange}
										required
									/>
								</div>

								<div className="form-group">
									<label
										htmlFor="message"
										className="form-label"
									>
										Message *
									</label>
									<textarea
										id="message"
										name="message"
										className="form-textarea"
										placeholder="Tell us more about your inquiry..."
										value={formData.message}
										onChange={handleChange}
										required
									></textarea>
								</div>

								<button
									type="submit"
									className="btn btn-primary btn-lg"
									disabled={isSubmitting}
								>
									{isSubmitting
										? "Sending..."
										: "Send Message"}
									<FaPaperPlane />
								</button>
							</form>
						</div>

						{/* Sidebar Info */}
						<div className="contact-sidebar">
							<div className="contact-sidebar-card fade-in">
								<h3>Need Immediate Help?</h3>
								<p>
									Our support team is available to answer your
									questions and help you get started with
									EduPath AI.
								</p>
								<div className="sidebar-cta">
									<a
										href="tel:+15551234567"
										className="btn btn-secondary"
									>
										<FaPhone />
										Call Now
									</a>
								</div>
							</div>

							<div className="contact-sidebar-card fade-in">
								<h3>Follow Us</h3>
								<p>
									Stay connected on social media for updates
									and tips.
								</p>
								<div className="social-links">
									<a
										href="#"
										className="social-link"
										aria-label="Facebook"
									>
										<FaFacebookF />
									</a>
									<a
										href="#"
										className="social-link"
										aria-label="Twitter"
									>
										<FaTwitter />
									</a>
									<a
										href="#"
										className="social-link"
										aria-label="LinkedIn"
									>
										<FaLinkedinIn />
									</a>
									<a
										href="#"
										className="social-link"
										aria-label="Instagram"
									>
										<FaInstagram />
									</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

			{/* Map Section */}
			<section className="map-section">
				<div className="container">
					<h2 className="section-title text-center fade-in mb-4">
						Find Us Here
					</h2>
					<div className="map-container fade-in">
						<div className="map-placeholder">
							<FaMapMarkerAlt />
							<p>
								Lovely Professional University (LPU), NH-1,
								Jalandhar-Delhi G.T. Road, Phagwara, Punjab
								144411, India
							</p>
							<span className="map-note">
								Map integration placeholder
							</span>
						</div>
					</div>
				</div>
			</section>
		</div>
	);
};

export default ContactPage;
