import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
	FaArrowLeft,
	FaCompass,
	FaCheckCircle,
	FaLightbulb,
	FaArrowRight,
	FaUserCheck,
	FaExclamationTriangle,
	FaBook,
	FaRedo,
} from "react-icons/fa";
import {
	getGuidanceTeaserAt,
	isValidGuidanceRecommendationIndex,
	loadGuidanceBundle,
	loadRecommendationDetail,
	saveGuidanceBundle,
	saveGuidanceRecommendations,
	shouldSkipGuidanceGenerateOnDetail,
} from "../lib/guidanceStorage";
import { api } from "../api/client";
import "./DashboardPage.css";
import "./DashboardGuidancePage.css";

function matchClass(match) {
	const m = String(match || "").toLowerCase();
	if (m.includes("strong")) return "guidance-match--strong";
	if (m.includes("good")) return "guidance-match--good";
	return "guidance-match--explore";
}

/** Avoid double numbering when the model includes "1." or "1)" in the string */
function normalizeStepText(raw) {
	const s = String(raw ?? "").trim();
	return s.replace(/^\d{1,2}\s*[.):\-–—]\s*/u, "").trim() || s;
}

function detailLooksPresent(d) {
	if (!d || typeof d !== "object") return false;
	if (String(d.executiveSummary || "").trim().length > 20) return true;
	const steps = d.concreteNextSteps;
	return Array.isArray(steps) && steps.some((s) => String(s).trim().length > 4);
}

const DashboardGuidanceDetailPage = () => {
	const { recIndex } = useParams();
	const navigate = useNavigate();
	const idx = parseInt(recIndex, 10);

	const validIndex = useMemo(() => isValidGuidanceRecommendationIndex(idx), [idx]);

	const [teaser, setTeaser] = useState(null);
	const [detail, setDetail] = useState(null);
	const [expandLoading, setExpandLoading] = useState(() => {
		const i = parseInt(recIndex, 10);
		if (!Number.isFinite(i) || i < 0) return false;
		if (detailLooksPresent(loadRecommendationDetail(i))) return false;
		if (shouldSkipGuidanceGenerateOnDetail(i) && getGuidanceTeaserAt(i)) return false;
		return true;
	});
	const [expandError, setExpandError] = useState("");
	const [provider, setProvider] = useState(null);
	const [fallbackFrom, setFallbackFrom] = useState(null);

	const fetchFullGuidance = useCallback(async () => {
		if (!validIndex) return;
		setExpandLoading(true);
		setExpandError("");
		setDetail(null);
		try {
			const data = await api("/api/guidance/generate", { method: "POST", body: {} });
			if (!data.success) {
				setExpandError(data.message || "Could not load guidance");
				return;
			}
			if (data.configured === false || !data.guidance) {
				setExpandError(
					data.message ||
						"AI isn’t configured on the server. Open Personalized Guidance from the dashboard after adding API keys."
				);
				return;
			}
			saveGuidanceBundle({
				guidance: data.guidance,
				recommendationDetails: data.recommendationDetails || [],
				provider: data.provider || null,
				fallbackFrom: data.fallbackFrom || null,
			});
			const recs = (data.guidance.recommendations || []).map((r) => ({
				title: r.title,
				match: r.match || "Explore",
				summary: r.summary || "",
				nextSteps: Array.isArray(r.nextSteps) ? r.nextSteps : [],
			}));
			saveGuidanceRecommendations(recs, { curatedFallback: false });
			setTeaser(recs[idx] || getGuidanceTeaserAt(idx));
			const d = Array.isArray(data.recommendationDetails) ? data.recommendationDetails[idx] : null;
			setDetail(detailLooksPresent(d) ? d : null);
			setProvider(data.provider || null);
			setFallbackFrom(data.fallbackFrom || null);
			if (!detailLooksPresent(d)) {
				setExpandError("Full detail for this card wasn’t returned. Try refreshing from Guidance.");
			}
		} catch (e) {
			setExpandError(e.message || "Could not load detailed guidance");
		} finally {
			setExpandLoading(false);
		}
	}, [validIndex, idx]);

	useEffect(() => {
		if (!validIndex) {
			setTeaser(null);
			setExpandLoading(false);
			return;
		}
		setTeaser(getGuidanceTeaserAt(idx));
		const cached = loadRecommendationDetail(idx);
		if (detailLooksPresent(cached)) {
			setDetail(cached);
			const b = loadGuidanceBundle();
			setProvider(b?.provider ?? null);
			setFallbackFrom(b?.fallbackFrom ?? null);
			setExpandError("");
			setExpandLoading(false);
			return;
		}
		if (shouldSkipGuidanceGenerateOnDetail(idx)) {
			setDetail(null);
			setExpandError("");
			setExpandLoading(false);
			return;
		}
		fetchFullGuidance();
	}, [validIndex, idx, fetchFullGuidance]);

	if (!validIndex) {
		return (
			<div className="dashboard-page guidance-detail-page">
				<div className="guidance-detail-empty">
					<FaCompass className="guidance-detail-empty-icon" aria-hidden />
					<h1>Invalid link</h1>
					<p>Use a recommendation from Personalized Guidance.</p>
					<Link to="/dashboard/guidance" className="btn btn-primary">
						Back to guidance
					</Link>
				</div>
			</div>
		);
	}

	if (!expandLoading && !detail && expandError && !teaser) {
		return (
			<div className="dashboard-page guidance-detail-page">
				<div className="guidance-detail-empty">
					<FaCompass className="guidance-detail-empty-icon" aria-hidden />
					<h1>Couldn’t load this plan</h1>
					<p>{expandError}</p>
					<div style={{ display: "flex", flexWrap: "wrap", gap: "0.65rem", justifyContent: "center" }}>
						<button type="button" className="btn btn-primary" onClick={fetchFullGuidance}>
							<FaRedo style={{ marginRight: "0.4rem" }} />
							Retry
						</button>
						<Link to="/dashboard/guidance" className="btn btn-secondary">
							Back to guidance
						</Link>
					</div>
				</div>
			</div>
		);
	}

	const headerItem = teaser || { title: "Recommendation", match: "Explore", summary: "" };

	const curatedLibrary = Boolean(!detail && shouldSkipGuidanceGenerateOnDetail(idx) && teaser);

	const tl =
		detail?.timeline &&
		typeof detail.timeline === "object" &&
		((detail.timeline.immediate?.length || 0) > 0 ||
			(detail.timeline.shortTerm?.length || 0) > 0 ||
			(detail.timeline.longTerm?.length || 0) > 0)
			? detail.timeline
			: teaser?.timeline && typeof teaser.timeline === "object"
				? teaser.timeline
				: {};

	const skills =
		Array.isArray(detail?.skillBuilding) && detail.skillBuilding.length > 0
			? detail.skillBuilding
			: Array.isArray(teaser?.skillThemes) && teaser.skillThemes.length > 0
				? teaser.skillThemes.map((s) => ({
						skill: s.skill,
						why: s.why,
						howToStart: s.howToStart,
					}))
				: [];

	const steps =
		Array.isArray(detail?.concreteNextSteps) && detail.concreteNextSteps.length > 0
			? detail.concreteNextSteps
			: Array.isArray(teaser?.nextSteps)
				? teaser.nextSteps
				: [];

	const resources =
		Array.isArray(detail?.resources) && detail.resources.length > 0
			? detail.resources
			: Array.isArray(teaser?.resourceIdeas)
				? teaser.resourceIdeas.map((r) => ({
						name: r.name,
						kind: r.kind,
						note: r.note,
					}))
				: [];

	const risks = Array.isArray(detail?.risksAndMitigations) ? detail.risksAndMitigations : [];
	const pa = detail?.profileAlignment || {};
	const whyBody = detail?.whyThisFits || teaser?.whyThisPath;

	return (
		<div className="dashboard-page guidance-detail-page guidance-detail-page--wide">
			<button type="button" className="guidance-detail-back" onClick={() => navigate(-1)}>
				<FaArrowLeft aria-hidden />
				Back
			</button>

			{expandLoading && (
				<div className="guidance-detail-loading" role="status">
					<span className="guidance-detail-spin" aria-hidden />
					Loading your personalized plan…
				</div>
			)}

			{shouldSkipGuidanceGenerateOnDetail(idx) && teaser && (
				<div className="guidance-alert guidance-alert--warn" style={{ marginBottom: "1.25rem" }}>
					<p>
						You&apos;re viewing an in-depth path from our guidance library. Live AI is off, unavailable, or
						the last model response couldn&apos;t be read. Use <strong>Refresh guidance</strong> on the main
						Guidance page when your API is healthy for a plan tuned to your profile.
					</p>
				</div>
			)}

			{expandError && (
				<div className="guidance-alert guidance-alert--err" style={{ marginBottom: "1.25rem" }}>
					<p>{expandError}</p>
					<button type="button" className="btn btn-secondary guidance-detail-retry" onClick={fetchFullGuidance}>
						<FaRedo style={{ marginRight: "0.4rem" }} />
						Try again
					</button>
				</div>
			)}

			{curatedLibrary && !expandLoading && (
				<p className="guidance-detail-provider">Expert-curated guidance · EduPath library</p>
			)}

			{provider && !expandLoading && !curatedLibrary && (
				<p className="guidance-detail-provider">
					Detailed plan via {provider === "gemini" ? "Google Gemini" : "Groq"}
					{fallbackFrom === "gemini" ? " (fallback)" : ""}
				</p>
			)}

			<header className="guidance-detail-hero">
				<div className={`guidance-detail-match ${matchClass(headerItem.match)}`}>
					{headerItem.match} match
				</div>
				<h1 className="guidance-detail-title">{headerItem.title}</h1>
				{detail?.executiveSummary ? (
					<p className="guidance-detail-prose">{detail.executiveSummary}</p>
				) : teaser?.insight ? (
					<p className="guidance-detail-prose">{teaser.insight}</p>
				) : (
					<p className="guidance-detail-lead">{headerItem.summary}</p>
				)}
				{teaser?.insight && headerItem.summary && !detail?.executiveSummary && (
					<p className="guidance-detail-lead" style={{ marginTop: "1.1rem", opacity: 0.92 }}>
						{headerItem.summary}
					</p>
				)}
			</header>

			{whyBody && (
				<section className="guidance-detail-section" aria-labelledby="why-heading">
					<h2 id="why-heading" className="guidance-detail-section-title">
						<FaLightbulb className="guidance-detail-section-icon" aria-hidden />
						{detail?.whyThisFits ? "Why this fits you" : "Why this path works"}
					</h2>
					<div className="guidance-detail-subblock">
						<p className="guidance-detail-prose guidance-detail-prose--muted" style={{ margin: 0 }}>
							{whyBody}
						</p>
					</div>
				</section>
			)}

			{(pa.strengths?.length > 0 || pa.gaps?.length > 0 || pa.learningStyleTip) && (
				<section className="guidance-detail-section" aria-labelledby="align-heading">
					<h2 id="align-heading" className="guidance-detail-section-title">
						<FaUserCheck className="guidance-detail-section-icon" aria-hidden />
						Profile alignment
					</h2>
					{pa.strengths?.length > 0 && (
						<div className="guidance-detail-subblock">
							<h3>Strengths we’re building on</h3>
							<ul className="guidance-detail-phase" style={{ listStyle: "disc", paddingLeft: "1.25rem", margin: 0 }}>
								{pa.strengths.map((s, i) => (
									<li key={i} style={{ marginBottom: "0.35rem", fontSize: "0.9rem", color: "var(--text-secondary)" }}>
										{s}
									</li>
								))}
							</ul>
						</div>
					)}
					{pa.gaps?.length > 0 && (
						<div className="guidance-detail-subblock">
							<h3>Gaps to address</h3>
							<ul className="guidance-detail-phase" style={{ listStyle: "disc", paddingLeft: "1.25rem", margin: 0 }}>
								{pa.gaps.map((g, i) => (
									<li key={i} style={{ marginBottom: "0.35rem", fontSize: "0.9rem", color: "var(--text-secondary)" }}>
										{g}
									</li>
								))}
							</ul>
						</div>
					)}
					{pa.learningStyleTip && (
						<div className="guidance-detail-subblock">
							<h3>Learning style tip</h3>
							<p className="guidance-detail-prose guidance-detail-prose--muted" style={{ margin: 0 }}>
								{pa.learningStyleTip}
							</p>
						</div>
					)}
				</section>
			)}

			{skills.length > 0 && (
				<section className="guidance-detail-section" aria-labelledby="skills-heading">
					<h2 id="skills-heading" className="guidance-detail-section-title">
						<FaCheckCircle className="guidance-detail-section-icon" aria-hidden />
						Skills to build
					</h2>
					<div className="guidance-detail-skill-grid">
						{skills.map((s, i) => (
							<div key={i} className="guidance-detail-skill-card">
								<strong>{s.skill || "Skill"}</strong>
								{s.why && <p>{s.why}</p>}
								{s.howToStart && (
									<p>
										<strong style={{ fontSize: "0.7rem", textTransform: "uppercase", color: "var(--text-tertiary)" }}>
											Start here:{" "}
										</strong>
										{s.howToStart}
									</p>
								)}
							</div>
						))}
					</div>
				</section>
			)}

			{(tl.immediate?.length > 0 || tl.shortTerm?.length > 0 || tl.longTerm?.length > 0) && (
				<section className="guidance-detail-section" aria-labelledby="time-heading">
					<h2 id="time-heading" className="guidance-detail-section-title">
						Timeline
					</h2>
					<div className="guidance-detail-timeline">
						<div className="guidance-detail-phase">
							<h4>Next ~2 weeks</h4>
							<ul>
								{(tl.immediate || []).map((x, i) => (
									<li key={i}>{x}</li>
								))}
							</ul>
						</div>
						<div className="guidance-detail-phase">
							<h4>1–3 months</h4>
							<ul>
								{(tl.shortTerm || []).map((x, i) => (
									<li key={i}>{x}</li>
								))}
							</ul>
						</div>
						<div className="guidance-detail-phase">
							<h4>6–12 months</h4>
							<ul>
								{(tl.longTerm || []).map((x, i) => (
									<li key={i}>{x}</li>
								))}
							</ul>
						</div>
					</div>
				</section>
			)}

			{steps.length > 0 && (
				<section className="guidance-detail-section" aria-labelledby="steps-heading">
					<h2 id="steps-heading" className="guidance-detail-section-title">
						<FaLightbulb className="guidance-detail-section-icon" aria-hidden />
						Concrete next steps
					</h2>
					<ol className="guidance-steps-list" aria-label="Action steps">
						{steps.map((step, i) => (
							<li key={i} className="guidance-steps-list__item">
								<span className="guidance-steps-list__index" aria-hidden>
									{i + 1}
								</span>
								<p className="guidance-steps-list__text">{normalizeStepText(step)}</p>
							</li>
						))}
					</ol>
				</section>
			)}

			{resources.length > 0 && (
				<section className="guidance-detail-section" aria-labelledby="res-heading">
					<h2 id="res-heading" className="guidance-detail-section-title">
						<FaBook className="guidance-detail-section-icon" aria-hidden />
						Resources & ideas
					</h2>
					<div className="guidance-detail-resources">
						{resources.map((r, i) => (
							<div key={i} className="guidance-detail-resource">
								<span className="guidance-detail-resource-kind">{r.kind || "tip"}</span>
								<div className="guidance-detail-resource-body">
									<strong>{r.name || "Resource"}</strong>
									{r.note && <p>{r.note}</p>}
								</div>
							</div>
						))}
					</div>
				</section>
			)}

			{risks.length > 0 && (
				<section className="guidance-detail-section" aria-labelledby="risk-heading">
					<h2 id="risk-heading" className="guidance-detail-section-title">
						<FaExclamationTriangle className="guidance-detail-section-icon" aria-hidden />
						Risks & how to handle them
					</h2>
					<div className="guidance-detail-subblock">
						<dl style={{ margin: 0 }}>
							{risks.map((r, i) => (
								<div key={i} className="guidance-detail-risk">
									<dt>{r.risk || "Risk"}</dt>
									<dd>{r.mitigation || ""}</dd>
								</div>
							))}
						</dl>
					</div>
				</section>
			)}

			{(detail?.encouragement || (curatedLibrary && teaser?.encouragement)) && (
				<div className="guidance-detail-encourage">
					{detail?.encouragement || teaser?.encouragement}
				</div>
			)}

			{!detail && !expandLoading && teaser?.nextSteps?.length > 0 && steps.length === 0 && (
				<section className="guidance-detail-section" aria-labelledby="fallback-steps">
					<h2 id="fallback-steps" className="guidance-detail-section-title">
						<FaLightbulb className="guidance-detail-section-icon" aria-hidden />
						Quick steps (overview)
					</h2>
					<ol className="guidance-detail-steps">
						{teaser.nextSteps.map((step, i) => (
							<li key={i} className="guidance-detail-step">
								<span className="guidance-detail-step-num">{i + 1}</span>
								<div className="guidance-detail-step-body">
									<FaCheckCircle className="guidance-detail-step-check" aria-hidden />
									<p>{step}</p>
								</div>
							</li>
						))}
					</ol>
				</section>
			)}

			<section className="guidance-detail-cta-panel">
				<h2 className="guidance-detail-cta-title">Keep building your path</h2>
				<p className="guidance-detail-cta-desc">
					Refine your profile for sharper AI output next time, or jump into curated external courses.
				</p>
				<div className="guidance-detail-cta-actions">
					<Link to="/dashboard/settings" className="btn btn-primary">
						Edit profile
						<FaArrowRight style={{ marginLeft: "0.45rem" }} />
					</Link>
					<Link to="/dashboard/courses" className="btn btn-secondary">
						Expert courses
					</Link>
					<Link to="/dashboard/guidance" className="guidance-detail-text-link">
						All recommendations
					</Link>
				</div>
			</section>
		</div>
	);
};

export default DashboardGuidanceDetailPage;
