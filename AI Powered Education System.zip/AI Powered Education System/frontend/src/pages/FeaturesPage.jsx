import React from "react";
import { Link } from "react-router-dom";
import {
	FaCompass,
	FaRocket,
	FaGraduationCap,
	FaBrain,
	FaChartLine,
	FaUsers,
	FaRobot,
	FaVideo,
	FaQuestionCircle,
	FaBriefcase,
	FaBell,
	FaTrophy,
	FaCheckCircle,
	FaArrowRight,
	FaStar,
} from "react-icons/fa";
import "./FeaturesPage.css";

const FeaturesPage = () => {
	const coreFeatures = [
		{
			icon: <FaCompass />,
			title: "Personalized Guidance",
			description:
				"Get tailored career recommendations based on your interests, skills, and academic background.",
			benefits: [
				"Interest-based career matching",
				"Skill assessment integration",
				"Academic context awareness",
				"Multiple career suggestions",
			],
		},
		{
			icon: <FaRocket />,
			title: "Career Roadmap",
			description:
				"Step-by-step plans with courses, exams, skills, and timelines for your dream career.",
			benefits: [
				"Milestone-based planning",
				"Exams and certifications on the path",
				"Required skills and courses",
				"Realistic timelines",
			],
		},
		{
			icon: <FaGraduationCap />,
			title: "Education Paths",
			description:
				"Smart recommendations for higher education, universities, and courses suited for you.",
			benefits: [
				"University and program matches",
				"Course curriculum insights",
				"Admission and eligibility cues",
				"Scholarship opportunities",
			],
		},
		{
			icon: <FaBrain />,
			title: "Skill-Based Mapping",
			description:
				"Discover careers and certifications that match your existing skills and talents.",
			benefits: [
				"Skill-to-career matching",
				"Certification recommendations",
				"Gap analysis for growth",
				"Upskilling suggestions",
			],
		},
		{
			icon: <FaUsers />,
			title: "Expert Courses",
			description:
				"Access quality courses uploaded by educators across various skill areas.",
			benefits: [
				"Educator-authored content",
				"Broad skill-area coverage",
				"Structured lessons and materials",
				"Learn at your own pace",
			],
		},
	];

	const advancedFeatures = [
		{
			icon: <FaVideo />,
			title: "Educator Course Uploads",
			description:
				"Educators can upload video or text-based courses, creating a rich learning ecosystem for students to explore various skill areas.",
			color: "#6366f1",
		},
		{
			icon: <FaQuestionCircle />,
			title: "Automatic MCQ Generation",
			description:
				"Our AI automatically generates quizzes and MCQs from uploaded course content using advanced question generation models.",
			color: "#8b5cf6",
		},
		{
			icon: <FaChartLine />,
			title: "Performance Evaluation",
			description:
				"Get automatic evaluation of quiz performance with detailed feedback to identify weak areas and track improvement.",
			color: "#ec4899",
		},
		{
			icon: <FaRobot />,
			title: "AI Learning Assistant",
			description:
				"Chat with our intelligent assistant for real-time answers about careers, courses, skills, and learning strategies.",
			color: "#3b82f6",
		},
		{
			icon: <FaBriefcase />,
			title: "Internship & Job Matching",
			description:
				"Get matched with relevant internships and entry-level jobs based on your completed courses and assessed skills.",
			color: "#f59e0b",
		},
		{
			icon: <FaBell />,
			title: "Smart Notifications",
			description:
				"Receive timely alerts about upcoming exams, new courses, scholarships, and job openings relevant to your chosen path.",
			color: "#ef4444",
		},
		{
			icon: <FaTrophy />,
			title: "Gamified Learning",
			description:
				"Earn badges, points, and achievements for completing lessons, quizzes, and milestones to stay motivated.",
			color: "#f59e0b",
		},
	];

	const howItWorks = [
		{
			step: "01",
			title: "Create Your Profile",
			description:
				"Sign up and tell us about your interests, academic background, and career aspirations.",
		},
		{
			step: "02",
			title: "Get Personalized Recommendations",
			description:
				"Our AI analyzes your profile and provides tailored career paths and educational recommendations.",
		},
		{
			step: "03",
			title: "Follow Your Roadmap",
			description:
				"Access detailed roadmaps with courses, exams, and skills needed for your chosen career.",
		},
		{
			step: "04",
			title: "Learn & Grow",
			description:
				"Take courses, complete assessments, and build skills as you advance toward your goals.",
		},
	];

	return (
		<div className="features-page">
			{/* Hero Section */}
			<section className="features-hero">
				<div className="container">
					<div className="features-hero-content">
						<div className="badge fade-in">
							<FaStar />
							<span>Comprehensive Features</span>
						</div>
						<h1 className="features-hero-title fade-in">
							Everything You Need to
							<span className="text-gradient"> Succeed</span>
						</h1>
						<p className="features-hero-description fade-in">
							Comprehensive tools and features designed to guide
							you from confusion to clarity
						</p>
					</div>
				</div>
			</section>

			{/* Core Features */}
			<section className="section-lg">
				<div className="container">
					<div className="section-header text-center">
						<h2 className="section-title fade-in">
							Core
							<span className="text-gradient"> Features</span>
						</h2>
						<p className="section-description fade-in">
							Everything you need to succeed—from guidance and
							roadmaps to courses and personalized picks
						</p>
					</div>

					<div className="core-features-list">
						{coreFeatures.map((feature, index) => (
							<div
								key={index}
								className="core-feature-card fade-in"
								style={{ animationDelay: `${index * 0.1}s` }}
							>
								<div className="core-feature-header">
									<div className="core-feature-icon">
										{feature.icon}
									</div>
									<div className="core-feature-title-section">
										<h3 className="core-feature-title">
											{feature.title}
										</h3>
										<p className="core-feature-description">
											{feature.description}
										</p>
									</div>
								</div>
								<ul className="core-feature-benefits">
									{feature.benefits.map((benefit, idx) => (
										<li key={idx}>
											<FaCheckCircle />
											<span>{benefit}</span>
										</li>
									))}
								</ul>
							</div>
						))}
					</div>
				</div>
			</section>

			{/* Advanced Features */}
			<section className="section-lg advanced-features-section">
				<div className="container">
					<div className="section-header text-center">
						<h2 className="section-title fade-in">
							Advanced
							<span className="text-gradient"> Features</span>
						</h2>
						<p className="section-description fade-in">
							Cutting-edge tools powered by artificial
							intelligence for enhanced learning
						</p>
					</div>

					<div className="grid grid-4">
						{advancedFeatures.map((feature, index) => (
							<div
								key={index}
								className="advanced-feature-card fade-in"
								style={{ animationDelay: `${index * 0.1}s` }}
							>
								<div
									className="advanced-feature-icon"
									style={{
										background: `linear-gradient(135deg, ${feature.color}, ${feature.color}dd)`,
									}}
								>
									{feature.icon}
								</div>
								<h3 className="advanced-feature-title">
									{feature.title}
								</h3>
								<p className="advanced-feature-description">
									{feature.description}
								</p>
							</div>
						))}
					</div>
				</div>
			</section>

			{/* How It Works */}
			<section className="section-lg how-it-works-section">
				<div className="container">
					<div className="section-header text-center">
						<h2 className="section-title fade-in">
							How It
							<span className="text-gradient"> Works</span>
						</h2>
						<p className="section-description fade-in">
							Get started with EduPath AI in four simple steps
						</p>
					</div>

					<div className="how-it-works-grid">
						{howItWorks.map((item, index) => (
							<div
								key={index}
								className="how-it-works-card fade-in"
								style={{ animationDelay: `${index * 0.1}s` }}
							>
								<div className="step-number">{item.step}</div>
								<h3 className="step-title">{item.title}</h3>
								<p className="step-description">
									{item.description}
								</p>
								{index < howItWorks.length - 1 && (
									<div className="step-connector">
										<FaArrowRight />
									</div>
								)}
							</div>
						))}
					</div>
				</div>
			</section>

			{/* Benefits Highlight */}
			<section className="section-lg benefits-highlight-section">
				<div className="container">
					<div className="benefits-highlight-grid">
						<div className="benefits-highlight-content">
							<h2 className="section-title fade-in">
								Why Students Love
								<span className="text-gradient">
									{" "}
									EduPath AI
								</span>
							</h2>
							<div className="benefits-highlight-list">
								<div className="benefit-highlight-item fade-in">
									<div className="benefit-highlight-icon">
										<FaCheckCircle />
									</div>
									<div>
										<h4>Personalized Experience</h4>
										<p>
											Every recommendation is tailored to
											your unique profile and goals
										</p>
									</div>
								</div>
								<div className="benefit-highlight-item fade-in">
									<div className="benefit-highlight-icon">
										<FaCheckCircle />
									</div>
									<div>
										<h4>Expert-Backed Content</h4>
										<p>
											All courses and guidance are created
											by industry professionals
										</p>
									</div>
								</div>
								<div className="benefit-highlight-item fade-in">
									<div className="benefit-highlight-icon">
										<FaCheckCircle />
									</div>
									<div>
										<h4>Comprehensive Support</h4>
										<p>
											From career discovery to job
											placement, we're with you every step
										</p>
									</div>
								</div>
								<div className="benefit-highlight-item fade-in">
									<div className="benefit-highlight-icon">
										<FaCheckCircle />
									</div>
									<div>
										<h4>Continuous Updates</h4>
										<p>
											Stay current with the latest
											industry trends and opportunities
										</p>
									</div>
								</div>
							</div>
						</div>
						<div className="benefits-highlight-visual">
							<div className="benefits-illustration">
								<div className="illustration-bg"></div>
								<div className="illustration-icon">💡</div>
							</div>
						</div>
					</div>
				</div>
			</section>

			{/* CTA Section */}
			<section className="section-lg features-cta-section">
				<div className="container">
					<div className="features-cta-content">
						<h2 className="cta-title fade-in">
							Ready to Discover Your Perfect Career Path?
						</h2>
						<p className="cta-description fade-in">
							Join thousands of students who have found clarity
							and direction with EduPath AI
						</p>
						<div className="cta-actions fade-in">
							<Link
								to="/signup"
								className="btn btn-primary btn-lg"
							>
								Get Started Free
								<FaArrowRight />
							</Link>
							<Link
								to="/contact"
								className="btn btn-secondary btn-lg"
							>
								Contact Us
							</Link>
						</div>
					</div>
				</div>
			</section>
		</div>
	);
};

export default FeaturesPage;
