import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
	FaEnvelope,
	FaLock,
	FaEye,
	FaEyeSlash,
} from "react-icons/fa";
import { useAuth } from "../context/AuthContext";
import "./AuthPages.css";

const LoginPage = () => {
	const { login, loginWithGoogle } = useAuth();
	const navigate = useNavigate();
	const [formData, setFormData] = useState({
		email: "",
		password: "",
	});
	const [showPassword, setShowPassword] = useState(false);
	const [rememberMe, setRememberMe] = useState(false);
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(false);

	const handleChange = (e) => {
		setFormData({ ...formData, [e.target.name]: e.target.value });
		setError("");
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		setError("");
		setLoading(true);
		try {
			await login(formData.email, formData.password);
			navigate("/dashboard");
		} catch (err) {
			setError(err.message || "Invalid email or password");
		} finally {
			setLoading(false);
		}
	};

	const handleGoogleLogin = () => {
		loginWithGoogle();
	};

	return (
		<div className="auth-page">
			<div className="auth-container">
				<div className="auth-grid">
					<div className="auth-form-section">
						<div className="auth-form-wrapper">
							<div className="auth-header">
								<h1 className="auth-title fade-in">Welcome Back!</h1>
								<p className="auth-subtitle fade-in">
									Log in to continue your learning journey
								</p>
							</div>

							<div className="social-login fade-in">
								<button
									type="button"
									className="social-btn"
									onClick={handleGoogleLogin}
									disabled={loading}
								>
									<svg width="20" height="20" viewBox="0 0 24 24">
										<path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
										<path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
										<path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
										<path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
									</svg>
									<span>Continue with Google</span>
								</button>
							</div>

							<div className="divider fade-in">
								<span>Or continue with email</span>
							</div>

							{error && (
								<div className="auth-error fade-in" role="alert">
									{error}
								</div>
							)}

							<form className="auth-form fade-in" onSubmit={handleSubmit}>
								<div className="form-group">
									<label htmlFor="email" className="form-label">Email Address</label>
									<div className="input-with-icon">
										<FaEnvelope className="input-icon" />
										<input
											type="email"
											id="email"
											name="email"
											className="form-input"
											placeholder="you@example.com"
											value={formData.email}
											onChange={handleChange}
											required
										/>
									</div>
								</div>

								<div className="form-group">
									<label htmlFor="password" className="form-label">Password</label>
									<div className="input-with-icon">
										<FaLock className="input-icon" />
										<input
											type={showPassword ? "text" : "password"}
											id="password"
											name="password"
											className="form-input"
											placeholder="Enter your password"
											value={formData.password}
											onChange={handleChange}
											required
										/>
										<button
											type="button"
											className="password-toggle"
											onClick={() => setShowPassword(!showPassword)}
											aria-label="Toggle password visibility"
										>
											{showPassword ? <FaEyeSlash /> : <FaEye />}
										</button>
									</div>
								</div>

								<div className="form-options">
									<label className="checkbox-label">
										<input
											type="checkbox"
											checked={rememberMe}
											onChange={(e) => setRememberMe(e.target.checked)}
										/>
										<span>Remember me</span>
									</label>
									<Link to="/forgot-password" className="forgot-link">
										Forgot password?
									</Link>
								</div>

								<button
									type="submit"
									className="btn btn-primary btn-lg auth-submit"
									disabled={loading}
								>
									{loading ? "Signing in…" : "Log In"}
								</button>
							</form>

							<p className="auth-footer-text fade-in">
								Don't have an account?{" "}
								<Link to="/signup" className="auth-link">Sign up for free</Link>
							</p>
						</div>
					</div>

					<div className="auth-visual-section">
						<div className="auth-visual-content">
							<div className="visual-icon fade-in">🎓</div>
							<h2 className="visual-title fade-in">Start Your Journey Today</h2>
							<p className="visual-description fade-in">
								Join thousands of students who have discovered their perfect career path with EduPath AI.
							</p>
							<div className="visual-stats fade-in">
								<div className="visual-stat">
									<div className="stat-number">50K+</div>
									<div className="stat-label">Active Students</div>
								</div>
								<div className="visual-stat">
									<div className="stat-number">1000+</div>
									<div className="stat-label">Career Paths</div>
								</div>
								<div className="visual-stat">
									<div className="stat-number">98%</div>
									<div className="stat-label">Success Rate</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};

export default LoginPage;
