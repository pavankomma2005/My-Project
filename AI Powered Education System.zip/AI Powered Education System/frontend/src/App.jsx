import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import HomePage from "./pages/HomePage";
import FeaturesPage from "./pages/FeaturesPage";
import ContactPage from "./pages/ContactPage";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";
import DashboardPage from "./pages/DashboardPage";
import DashboardGuidancePage from "./pages/DashboardGuidancePage";
import DashboardGuidanceDetailPage from "./pages/DashboardGuidanceDetailPage";
import DashboardRoadmapPage from "./pages/DashboardRoadmapPage";
import DashboardEducationPage from "./pages/DashboardEducationPage";
import DashboardSkillsPage from "./pages/DashboardSkillsPage";
import DashboardCoursesPage from "./pages/DashboardCoursesPage";
import DashboardSettingsPage from "./pages/DashboardSettingsPage";
import ScrollToTop from "./components/ScrollToTop";
import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import DashboardLayout from "./components/DashboardLayout";

function PublicLayout() {
	return (
		<div className="app">
			<Header />
			<main className="main-content">
				<Routes>
					<Route path="/" element={<HomePage />} />
					<Route path="/features" element={<FeaturesPage />} />
					<Route path="/contact" element={<ContactPage />} />
					<Route path="/login" element={<LoginPage />} />
					<Route path="/signup" element={<SignupPage />} />
				</Routes>
			</main>
			<Footer />
		</div>
	);
}

function App() {
	return (
		<Router>
			<ScrollToTop />
			<AuthProvider>
				<Routes>
					<Route path="/dashboard" element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
						<Route index element={<DashboardPage />} />
						<Route path="guidance/recommendation/:recIndex" element={<DashboardGuidanceDetailPage />} />
						<Route path="guidance" element={<DashboardGuidancePage />} />
						<Route path="roadmap" element={<DashboardRoadmapPage />} />
						<Route path="education" element={<DashboardEducationPage />} />
						<Route path="skills" element={<DashboardSkillsPage />} />
						<Route path="courses" element={<DashboardCoursesPage />} />
						<Route path="settings" element={<DashboardSettingsPage />} />
					</Route>
					<Route path="*" element={<PublicLayout />} />
				</Routes>
			</AuthProvider>
		</Router>
	);
}

export default App;
